<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-03 | Category: restaurant (Fine dining) | Source: Eleven Madison Park https://www.elevenmadisonpark.com/ -->
# Fidelity notes: Marlowe Hall ↔ Eleven Madison Park

**Original:** https://elevenmadisonpark.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Marlowe Hall. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured) | Replica |
|---|---|---|
| Background and text | White `#FFFFFF`, black text | White, near-black `#111111` |
| Body type | EB Garamond 16px | **EB Garamond** (OFL), 18px |
| Navigation type | "nobel", light (300), uppercase, letter-spaced | **Inter Tight** uppercase with 0.12em spacing (no 300 weight bundled, so 400) |
| Accent | Navy `#15325C` (skip link, Sign Up button) | Same navy for primary buttons, focus ring and links on hover (12.8:1) |
| Booking button | "Book on Resy" `#FC4837`, 6.4px radius, white text (3.4:1) | "Book a table" `#D93A2A`, 6px radius (white text 4.6:1) |
| Header | Absolute, transparent, hamburger "Open Menu" | Transparent overlay on the home hero (solid white when scrolled), hamburger opening a full-screen menu |
| Overall | Very minimal: big image, address, booking, newsletter (first name, last name, email) | Same: minimal hero panel with address and CTAs, short intro, three teasers, newsletter with first and last name |

## Mirrored structure
- **Menu groups:** Reservations; About (About Us, Team, Farm, Events, Stories); Shop (Gift Cards, Home goods, Wine Club); sister bar; Contact.
- **Footer links:** Wine List, FAQs, Gift Cards, sister bar, Press & Accolades, Careers, Contact, Wine Club, Accessibility Statement, and a membership line.
- **Content:** two tasting formats (Full and Bar), FAQ accordions, gift cards including a Braille option, and an accessibility statement.
- **Newsletter:** first name, last name and email.

## Adapted, added or left out
- **Resy integration replaced** by an on-site booking widget with 15-minute slots, a confirmation dialog and an `.ics` download, plus a waitlist form.
- **Added:** dietary filters on the tasting menu, a filterable and sortable wine list (the original links a PDF), Stories with categories and pagination, a careers application, site search and a 404 page.
- **Overlay menu:** groups render as labeled lists instead of nested folders, so every page is reachable in one view.

## Observations on the original that were not copied
1. On first paint the home page renders blank white while assets load (seen in the screenshot taken 3 seconds after navigation), with no loading text.
2. White on `#FC4837` for the booking button: 3.4:1, below 4.5:1 for normal-size text.
3. The page has no `h1`, `h2` or `h3` elements in the rendered home page (measured: all null).


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | About Us | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `bar.html` | The Linden Bar | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `careers.html` | Careers | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `events.html` | Events | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `farm.html` | The Farm | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `gift-cards.html` | Gift Cards | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Marlowe Hall | Eleven Madison Park home page |
| `menu.html` | Tasting Menus | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `press.html` | Press & Accolades | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `reservations.html` | Reservations | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `shop.html` | Home & Pantry | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `stories-a-new-season-menu.html` | Writing a new season's menu | Article detail page (child of `stories.html`); article content is original |
| `stories-rooftop-hives.html` | Notes from the rooftop hives | Article detail page (child of `stories.html`); article content is original |
| `stories-ten-years-of-service.html` | Ten years of service | Article detail page (child of `stories.html`); article content is original |
| `stories-the-farm-in-autumn.html` | The farm in autumn | Article detail page (child of `stories.html`); article content is original |
| `stories-zero-proof-pairings.html` | Building a zero-proof pairing | Article detail page (child of `stories.html`); article content is original |
| `stories.html` | Stories | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `team.html` | Team | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `wine-club.html` | Wine Club | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `wine-list.html` | Wine List | Mirrors a Eleven Madison Park page or section from the approved source inventory; added features are listed in fidelity-notes.md |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
