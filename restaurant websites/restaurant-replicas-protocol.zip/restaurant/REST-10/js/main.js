/* Morrow Bakery (REST-10): site data first, then all behavior. Vanilla JS; Bootstrap's bundle (assets/vendor/bootstrap/) is loaded before this file. */
/* ===== from data.js ===== */
/* Morrow Bakery site data (generated, fictional). Read by main.js. */
window.SITE_DATA = {
 "site": {
  "key": "morrow",
  "name": "Morrow Bakery",
  "tz": "America/Los_Angeles",
  "codePrefix": "MB",
  "address": "600 Guerrero Way, San Francisco, CA 94110"
 },
 "hours": {
  "mission": {
   "label": "Morrow Mission",
   "days": {
    "0": [
     [
      450,
      1080
     ]
    ],
    "1": [
     [
      450,
      1080
     ]
    ],
    "2": [
     [
      450,
      1080
     ]
    ],
    "3": [
     [
      450,
      1080
     ]
    ],
    "4": [
     [
      450,
      1080
     ]
    ],
    "5": [
     [
      450,
      1080
     ]
    ],
    "6": [
     [
      450,
      1080
     ]
    ]
   },
   "tz": "America/Los_Angeles"
  },
  "sunset": {
   "label": "Morrow Inner Sunset",
   "days": {
    "0": [
     [
      420,
      960
     ]
    ],
    "1": [
     [
      420,
      960
     ]
    ],
    "2": [
     [
      420,
      960
     ]
    ],
    "3": [
     [
      420,
      960
     ]
    ],
    "4": [
     [
      420,
      960
     ]
    ],
    "5": [
     [
      420,
      960
     ]
    ],
    "6": [
     [
      420,
      960
     ]
    ]
   },
   "tz": "America/Los_Angeles"
  },
  "berkeley": {
   "label": "Morrow Berkeley",
   "days": {
    "0": [
     [
      450,
      900
     ]
    ],
    "1": [],
    "2": [
     [
      450,
      900
     ]
    ],
    "3": [
     [
      450,
      900
     ]
    ],
    "4": [
     [
      450,
      900
     ]
    ],
    "5": [
     [
      450,
      900
     ]
    ],
    "6": [
     [
      450,
      900
     ]
    ]
   },
   "tz": "America/Los_Angeles"
  },
  "silver-lake": {
   "label": "Morrow Silver Lake",
   "days": {
    "0": [
     [
      420,
      1020
     ]
    ],
    "1": [
     [
      420,
      1020
     ]
    ],
    "2": [
     [
      420,
      1020
     ]
    ],
    "3": [
     [
      420,
      1020
     ]
    ],
    "4": [
     [
      420,
      1020
     ]
    ],
    "5": [
     [
      420,
      1020
     ]
    ],
    "6": [
     [
      420,
      1020
     ]
    ]
   },
   "tz": "America/Los_Angeles"
  },
  "arts-district": {
   "label": "Morrow Arts District",
   "days": {
    "0": [
     [
      480,
      1140
     ]
    ],
    "1": [
     [
      480,
      1140
     ]
    ],
    "2": [
     [
      480,
      1140
     ]
    ],
    "3": [
     [
      480,
      1140
     ]
    ],
    "4": [
     [
      480,
      1140
     ]
    ],
    "5": [
     [
      480,
      1140
     ]
    ],
    "6": [
     [
      480,
      1140
     ]
    ]
   },
   "tz": "America/Los_Angeles"
  },
  "hannam": {
   "label": "Morrow Hannam",
   "days": {
    "0": [
     [
      480,
      1260
     ]
    ],
    "1": [
     [
      480,
      1260
     ]
    ],
    "2": [
     [
      480,
      1260
     ]
    ],
    "3": [
     [
      480,
      1260
     ]
    ],
    "4": [
     [
      480,
      1260
     ]
    ],
    "5": [
     [
      480,
      1260
     ]
    ],
    "6": [
     [
      480,
      1260
     ]
    ]
   },
   "tz": "Asia/Seoul"
  },
  "seongsu": {
   "label": "Morrow Seongsu",
   "days": {
    "0": [
     [
      540,
      1260
     ]
    ],
    "1": [
     [
      540,
      1260
     ]
    ],
    "2": [
     [
      540,
      1260
     ]
    ],
    "3": [
     [
      540,
      1260
     ]
    ],
    "4": [
     [
      540,
      1260
     ]
    ],
    "5": [
     [
      540,
      1260
     ]
    ],
    "6": [
     [
      540,
      1260
     ]
    ]
   },
   "tz": "Asia/Seoul"
  }
 },
 "taxRate": 0.08625,
 "demoGiftCards": {
  "123456789012": 75.0,
  "000011112222": 0.0
 },
 "searchIndex": [
  {
   "t": "Morrow Bakery",
   "u": "index.html",
   "x": "Morrow Bakery: a fictional bakery and café in the Bay Area, Los Angeles and Seoul.",
   "k": "Page"
  },
  {
   "t": "Locations",
   "u": "locations.html",
   "x": "Morrow bakeries in the Bay Area, Los Angeles and Seoul.",
   "k": "Page"
  },
  {
   "t": "Morrow Mission",
   "u": "location-mission.html",
   "x": "Morrow Mission: hours, menu, ordering and cakes.",
   "k": "Page"
  },
  {
   "t": "Morrow Inner Sunset",
   "u": "location-sunset.html",
   "x": "Morrow Inner Sunset: hours, menu, ordering and cakes.",
   "k": "Page"
  },
  {
   "t": "Morrow Berkeley",
   "u": "location-berkeley.html",
   "x": "Morrow Berkeley: hours, menu, ordering and cakes.",
   "k": "Page"
  },
  {
   "t": "Morrow Silver Lake",
   "u": "location-silver-lake.html",
   "x": "Morrow Silver Lake: hours, menu, ordering and cakes.",
   "k": "Page"
  },
  {
   "t": "Morrow Arts District",
   "u": "location-arts-district.html",
   "x": "Morrow Arts District: hours, menu, ordering and cakes.",
   "k": "Page"
  },
  {
   "t": "Morrow Hannam",
   "u": "location-hannam.html",
   "x": "Morrow Hannam: hours, menu, ordering and cakes.",
   "k": "Page"
  },
  {
   "t": "Morrow Seongsu",
   "u": "location-seongsu.html",
   "x": "Morrow Seongsu: hours, menu, ordering and cakes.",
   "k": "Page"
  },
  {
   "t": "Country Loaf",
   "u": "menu.html#item-country",
   "x": "Naturally leavened, dark crust. Bread, $14.",
   "k": "Dish"
  },
  {
   "t": "Seeded Rye",
   "u": "menu.html#item-seeded",
   "x": "Rye, sunflower, flax, sesame. Bread, $15.",
   "k": "Dish"
  },
  {
   "t": "Baguette",
   "u": "menu.html#item-baguette",
   "x": "Morning bake. Bread, $6.",
   "k": "Dish"
  },
  {
   "t": "Morning Bun",
   "u": "menu.html#item-morning-bun",
   "x": "Orange zest, cinnamon sugar. Pastries, $6.50.",
   "k": "Dish"
  },
  {
   "t": "Croissant",
   "u": "menu.html#item-croissant",
   "x": "Cultured butter. Pastries, $5.75.",
   "k": "Dish"
  },
  {
   "t": "Frangipane Croissant",
   "u": "menu.html#item-frangipane",
   "x": "Almond cream, sliced almonds. Pastries, $7.",
   "k": "Dish"
  },
  {
   "t": "Chocolate Rye Cookie",
   "u": "menu.html#item-gf-cookie",
   "x": "Made without wheat. Pastries, $4.50.",
   "k": "Dish"
  },
  {
   "t": "Lemon Cream Cake",
   "u": "menu.html#item-lemon-slice",
   "x": "Chiffon, lemon curd, cream. By the slice, $9.",
   "k": "Dish"
  },
  {
   "t": "Devil's Food Cake",
   "u": "menu.html#item-choc-slice",
   "x": "Dark chocolate, ganache. By the slice, $9.",
   "k": "Dish"
  },
  {
   "t": "Croque Monsieur",
   "u": "menu.html#item-croque",
   "x": "Ham, gruyère, béchamel. Sandwiches, $16.",
   "k": "Dish"
  },
  {
   "t": "Market Vegetable Sandwich",
   "u": "menu.html#item-veg-sandwich",
   "x": "Roasted vegetables, herb aioli. Sandwiches, $14.",
   "k": "Dish"
  },
  {
   "t": "Latte",
   "u": "menu.html#item-latte",
   "x": "Oat or whole milk. Coffee & tea, $5.50.",
   "k": "Dish"
  },
  {
   "t": "Drip Coffee",
   "u": "menu.html#item-drip",
   "x": "Rotating single origin. Coffee & tea, $4.",
   "k": "Dish"
  },
  {
   "t": "Menu",
   "u": "menu.html",
   "x": "Morrow Bakery menu with dietary filters.",
   "k": "Page"
  },
  {
   "t": "Order for Pickup",
   "u": "order.html",
   "x": "Order Morrow Bakery for pickup.",
   "k": "Page"
  },
  {
   "t": "Special Cakes",
   "u": "cakes.html",
   "x": "Order a special cake from Morrow with 7 days notice.",
   "k": "Page"
  },
  {
   "t": "Holiday Pre-Order",
   "u": "holiday.html",
   "x": "Morrow holiday pre-orders.",
   "k": "Page"
  },
  {
   "t": "Catering",
   "u": "catering.html",
   "x": "Morrow catering.",
   "k": "Page"
  },
  {
   "t": "Our Story",
   "u": "our-story.html",
   "x": "The story of Morrow Bakery.",
   "k": "Page"
  },
  {
   "t": "Our Bread",
   "u": "our-bread.html",
   "x": "How Morrow bread is made.",
   "k": "Page"
  },
  {
   "t": "Press",
   "u": "press.html",
   "x": "Morrow press coverage.",
   "k": "Page"
  },
  {
   "t": "Baker",
   "u": "careers.html",
   "x": "Mix, shape and bake bread.",
   "k": "Job"
  },
  {
   "t": "Barista",
   "u": "careers.html",
   "x": "Make coffee and serve guests.",
   "k": "Job"
  },
  {
   "t": "Pastry Cook",
   "u": "careers.html",
   "x": "Laminate dough and finish pastries.",
   "k": "Job"
  },
  {
   "t": "Join Morrow",
   "u": "careers.html",
   "x": "Jobs at Morrow Bakery.",
   "k": "Page"
  },
  {
   "t": "Gift Cards",
   "u": "gift-cards.html",
   "x": "Morrow gift cards.",
   "k": "Page"
  },
  {
   "t": "Chocolate Olive Oil Cake, Shipped",
   "u": "shipping.html",
   "x": "Keeps for a week. $58.",
   "k": "Product"
  },
  {
   "t": "Morrow Granola, 2 Bags",
   "u": "shipping.html",
   "x": "Oats, almonds, honey. $26.",
   "k": "Product"
  },
  {
   "t": "Morrow: The Book",
   "u": "shipping.html",
   "x": "Our bread and pastry book. $40.",
   "k": "Product"
  },
  {
   "t": "Dried Sourdough Starter",
   "u": "shipping.html",
   "x": "A pinch of our 2002 culture. $15.",
   "k": "Product"
  },
  {
   "t": "Order Nationwide",
   "u": "shipping.html",
   "x": "Morrow nationwide shipping.",
   "k": "Page"
  },
  {
   "t": "Contact",
   "u": "contact.html",
   "x": "Contact Morrow Bakery.",
   "k": "Page"
  },
  {
   "t": "Stories",
   "u": "stories.html",
   "x": "Recipes, happenings and news.",
   "k": "Page"
  },
  {
   "t": "Holiday pre-orders are open",
   "u": "story-holiday-preorders.html",
   "x": "Pies, stollen and bûche de Noël, for pickup December 21 to 24.",
   "k": "Post"
  },
  {
   "t": "Recipe: our country loaf at home",
   "u": "story-country-loaf-recipe.html",
   "x": "A three-day loaf you can bake in a Dutch oven.",
   "k": "Post"
  },
  {
   "t": "One year in Seoul",
   "u": "story-seoul-one-year.html",
   "x": "What we learned baking 9,000 km from home.",
   "k": "Post"
  },
  {
   "t": "Recipe: morning buns",
   "u": "story-morning-bun-recipe.html",
   "x": "Laminated dough, orange zest and a lot of cinnamon sugar.",
   "k": "Post"
  },
  {
   "t": "We're hiring bakers in Los Angeles",
   "u": "story-join-our-team.html",
   "x": "Early mornings, good bread, a great team.",
   "k": "Post"
  },
  {
   "t": "Can I order ahead?",
   "u": "faq.html#faq-ordering",
   "x": "Yes. Choose your region when you click Order, then pick a bakery and time.",
   "k": "FAQ"
  },
  {
   "t": "How far ahead do I order a cake?",
   "u": "faq.html#faq-ordering",
   "x": "At least 7 days for whole cakes.",
   "k": "FAQ"
  },
  {
   "t": "Do you have gluten-free items?",
   "u": "faq.html#faq-diet",
   "x": "A few, like our chocolate rye cookie made without wheat. Our bakeries handle wheat flour throughout.",
   "k": "FAQ"
  },
  {
   "t": "Are pastries made with nuts?",
   "u": "faq.html#faq-diet",
   "x": "Some are. Use the nut-free filter on our menu.",
   "k": "FAQ"
  },
  {
   "t": "Do you ship nationwide?",
   "u": "faq.html#faq-ship",
   "x": "Yes, selected cakes and pantry items ship within the US, Tuesday to Thursday.",
   "k": "FAQ"
  },
  {
   "t": "FAQ",
   "u": "faq.html",
   "x": "Ordering, dietary needs and shipping.",
   "k": "Page"
  },
  {
   "t": "Privacy",
   "u": "privacy.html",
   "x": "Privacy policy for the Morrow Bakery demonstration site.",
   "k": "Page"
  },
  {
   "t": "Accessibility",
   "u": "accessibility.html",
   "x": "Accessibility statement for the Morrow Bakery website.",
   "k": "Page"
  }
 ]
};
;
/* ===== from main.js ===== */
/* =====================================================================
   Restaurant replica kit: front-end behavior (vanilla JS + Bootstrap 5)
   Shared by every fictional replica site. No backend: submissions are
   simulated in memory (cart/bag also use sessionStorage when available).
   Every behavior is attached through data-component / data-* hooks.
   Site-specific values come from window.SITE_DATA (assets/js/data.js).
   ===================================================================== */
(function () {
  'use strict';

  var D = window.SITE_DATA || {};
  var S = D.site || { key: 'site', name: 'Restaurant', codePrefix: 'RX' };
  var BS = window.bootstrap;
  function $(s, c) { return (c || document).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (ch) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]; }); }
  function money(n) { return '$' + Number(n).toFixed(2); }
  function code(prefix) { var c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', s = ''; for (var i = 0; i < 5; i++) s += c[Math.floor(Math.random() * c.length)]; return (S.codePrefix || 'RX') + '-' + (prefix || '') + s; }
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- announcements ---------- */
  function announce(msg) { var r = $('#sr-status'); if (!r) return; r.textContent = ''; setTimeout(function () { r.textContent = msg; }, 60); }
  function toast(msg) {
    var t = $('#site-toast');
    if (!t || !BS) { announce(msg); return; }
    $('[data-toast-body]', t).textContent = msg;
    BS.Toast.getOrCreateInstance(t, { delay: 4000 }).show();
  }

  /* ---------- storage (session, falls back to memory) ---------- */
  var Store = (function () {
    var mem = {}, ss = null;
    try { ss = window.sessionStorage; ss.setItem('__t', '1'); ss.removeItem('__t'); } catch (e) { ss = null; }
    return {
      get: function (k, d) { try { if (ss) { var v = ss.getItem(k); return v ? JSON.parse(v) : d; } } catch (e) { } return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : d; },
      set: function (k, v) { mem[k] = v; try { if (ss) ss.setItem(k, JSON.stringify(v)); } catch (e) { } }
    };
  })();
  function K(name) { return S.key + '-' + name; }

  /* ---------- time in the restaurant's time zone ---------- */
  var DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  function nowParts(tz) {
    var p = new URLSearchParams(location.search).get('demo-time');
    var m = p && p.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
    if (m) { var dt = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])); return { day: dt.getUTCDay(), min: (+m[4]) * 60 + (+m[5]), y: +m[1], mo: +m[2], d: +m[3] }; }
    try {
      var parts = new Intl.DateTimeFormat('en-US', { timeZone: tz || S.tz || 'America/New_York', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date());
      var g = function (t) { for (var i = 0; i < parts.length; i++) if (parts[i].type === t) return parts[i].value; return ''; };
      return { day: { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[g('weekday')], min: (+g('hour') % 24) * 60 + (+g('minute')), y: +g('year'), mo: +g('month'), d: +g('day') };
    } catch (e) { var n = new Date(); return { day: n.getDay(), min: n.getHours() * 60 + n.getMinutes(), y: n.getFullYear(), mo: n.getMonth() + 1, d: n.getDate() }; }
  }
  function isoFromToday(off) { var n = nowParts(); return new Date(Date.UTC(n.y, n.mo - 1, n.d + (off || 0))).toISOString().slice(0, 10); }
  function fmtMin(m) {
    if (m === 1440) return 'midnight';
    m = ((m % 1440) + 1440) % 1440;
    var h = Math.floor(m / 60), mm = m % 60, ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
    return h + (mm ? ':' + String(mm).padStart(2, '0') : '') + ' ' + ap;
  }
  function fmtDate(iso) { var p = iso.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'UTC' }); }

  /* ---------- open / closed status ---------- */
  function locStatus(key, np) {
    var loc = D.hours && D.hours[key]; if (!loc) return null;
    var days = loc.days, i, r;
    var y = days[String((np.day + 6) % 7)] || [];
    for (i = 0; i < y.length; i++) { r = y[i]; if (r[1] > 1440 && np.min < r[1] - 1440) return { open: true, closes: r[1] - 1440, left: r[1] - 1440 - np.min }; }
    var t = days[String(np.day)] || [];
    for (i = 0; i < t.length; i++) { r = t[i]; if (np.min >= r[0] && np.min < r[1]) return { open: true, closes: r[1], left: r[1] - np.min }; }
    for (var k = 0; k < 8; k++) {
      var list = days[String((np.day + k) % 7)] || [];
      for (i = 0; i < list.length; i++) { if (k === 0 && list[i][0] <= np.min) continue; return { open: false, inDays: k, opens: list[i][0], dayIndex: (np.day + k) % 7 }; }
    }
    return { open: false };
  }
  function statusText(s, loc) {
    if (s.open) {
      if (loc && loc.closeLabel) return (s.left <= 60 ? 'Closing soon, open until ' : 'Open now until ') + loc.closeLabel;
      return (s.left <= 60 ? 'Closing soon, open until ' : 'Open now until ') + fmtMin(s.closes);
    }
    if (s.opens === undefined) return 'Closed';
    var when = s.inDays === 0 ? 'today' : s.inDays === 1 ? 'tomorrow' : DAYS[s.dayIndex];
    return 'Closed now, opens ' + when + ' at ' + fmtMin(s.opens);
  }
  function initOpenStatus() {
    var np0 = nowParts();
    function npFor(key) { var L = D.hours && D.hours[key]; return L && L.tz ? nowParts(L.tz) : np0; }
    $$('[data-component="open-status"]').forEach(function (el) {
      var key = el.getAttribute('data-location'), s = locStatus(key, npFor(key)); if (!s) return;
      el.classList.remove('is-open', 'is-soon', 'is-closed');
      el.classList.add(s.open ? (s.left <= 60 ? 'is-soon' : 'is-open') : 'is-closed');
      el.textContent = statusText(s, D.hours[key]);
      var card = el.closest('[data-open-state]'); if (card) card.setAttribute('data-open-state', s.open ? 'open' : 'closed');
    });
    $$('[data-component="hours-week"]').forEach(function (ul) {
      var loc = D.hours && D.hours[ul.getAttribute('data-location')]; if (!loc) return;
      var np = npFor(ul.getAttribute('data-location'));
      ul.innerHTML = [1, 2, 3, 4, 5, 6, 0].map(function (d) {
        var rs = loc.days[String(d)] || [];
        var txt = rs.length ? rs.map(function (r) { return fmtMin(r[0]) + ' – ' + (loc.closeLabel || fmtMin(r[1])); }).join(', ') : 'Closed';
        var today = d === np.day;
        return '<li class="' + (today ? 'is-today' : '') + '"><span>' + DAYS[d] + (today ? ' (today)' : '') + '</span><span>' + txt + '</span></li>';
      }).join('');
    });
  }

  /* ---------- sticky header: [data-scroll-away] parts scroll off, the rest sticks ---------- */
  function initStickyHeader() {
    var h = $('.site-header'); if (!h) return;
    function update() {
      var hide = 0;
      $$('[data-scroll-away]', h).forEach(function (el) {
        var bp = el.getAttribute('data-scroll-away');
        if (!bp || window.matchMedia('(min-width: ' + bp + 'px)').matches) hide += el.offsetHeight;
      });
      if (h.classList.contains('header-overlay')) hide = 0;
      h.style.top = (-hide) + 'px';
      document.documentElement.style.setProperty('--sticky-h', Math.max(0, h.offsetHeight - hide) + 'px');
    }
    update(); window.addEventListener('resize', update);
    document.addEventListener('layout:change', update);
    $$('.collapse', h).forEach(function (c) { ['shown.bs.collapse', 'hidden.bs.collapse'].forEach(function (ev) { c.addEventListener(ev, update); }); });
    var panel = $('#site-search-panel');
    if (panel) {
      panel.addEventListener('shown.bs.collapse', function () { var i = $('input', panel); if (i) i.focus(); });
      panel.addEventListener('keydown', function (e) { if (e.key === 'Escape') { BS.Collapse.getOrCreateInstance(panel).hide(); var t = $('[data-component="search-toggle"]'); if (t) t.focus(); } });
    }
    var on = function () { h.classList.toggle('is-scrolled', window.scrollY > 40); };
    window.addEventListener('scroll', on, { passive: true }); on();
  }

  /* ---------- announcement bar (dismissable) ---------- */
  function initAnnouncement() {
    $$('[data-component="announcement-bar"]').forEach(function (bar) {
      var id = K('announce-' + (bar.getAttribute('data-id') || '1'));
      if (Store.get(id, false)) { bar.hidden = true; document.dispatchEvent(new Event('layout:change')); return; }
      var b = $('[data-dismiss-announcement]', bar);
      if (b) b.addEventListener('click', function () {
        bar.hidden = true; Store.set(id, true); document.dispatchEvent(new Event('layout:change'));
        var target = $('.site-header a, .site-header button'); if (target) target.focus();
      });
    });
  }

  /* ---------- cookie consent banner (non-modal; body padded so it never hides focus) ---------- */
  function initCookies() {
    var bar = $('[data-component="cookie-banner"]'); if (!bar) return;
    var choice = Store.get(K('cookies'), null);
    function pad() { document.body.style.paddingBottom = bar.hidden ? '' : bar.offsetHeight + 'px'; }
    if (!choice) { bar.hidden = false; pad(); window.addEventListener('resize', pad); }
    function done(v, msg) { Store.set(K('cookies'), v); bar.hidden = true; pad(); toast(msg); }
    $$('[data-cookie]', document).forEach(function (b) {
      b.addEventListener('click', function () {
        var v = b.getAttribute('data-cookie');
        if (v === 'accept') done('all', 'All cookies accepted. (Demo: no cookies are set.)');
        if (v === 'reject') done('essential', 'Non-essential cookies rejected.');
        if (v === 'save') {
          var prefs = $$('[data-cookie-pref]').filter(function (c) { return c.checked; }).map(function (c) { return c.value; });
          var m = $('#cookie-modal'); if (m && BS) BS.Modal.getOrCreateInstance(m).hide();
          done(prefs.join(',') || 'essential', 'Cookie preferences saved.');
        }
      });
    });
    var reopen = $('[data-cookie-reopen]');
    if (reopen) reopen.addEventListener('click', function () { bar.hidden = false; pad(); var f = $('button', bar); if (f) f.focus(); });
  }

  /* ---------- age gate (modal dialog, focus contained by Bootstrap) ---------- */
  function initAgeGate() {
    var m = $('#age-gate'); if (!m || !BS) return;
    var forced = new URLSearchParams(location.search).get('age-gate') === 'show';
    if (Store.get(K('age-ok'), false) && !forced) return;
    var modal = BS.Modal.getOrCreateInstance(m, { backdrop: 'static', keyboard: false });
    document.documentElement.classList.add('age-gate-open');
    modal.show();
    $('[data-age="yes"]', m).addEventListener('click', function () {
      Store.set(K('age-ok'), true); document.documentElement.classList.remove('age-gate-open'); modal.hide();
    });
    $('[data-age="no"]', m).addEventListener('click', function () {
      $('[data-age-question]', m).hidden = true;
      var d = $('[data-age-denied]', m); d.hidden = false; d.focus();
    });
  }

  /* ---------- back to top ---------- */
  function initBackToTop() {
    var b = $('[data-component="back-to-top"]'); if (!b) return;
    window.addEventListener('scroll', function () { b.hidden = window.scrollY < 700; }, { passive: true });
    b.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }); var f = $('.site-header .brand'); if (f) f.focus({ preventScroll: true }); });
  }

  /* ---------- in-page nav highlight (anchor nav / sticky subnav) ---------- */
  function initAnchorNav() {
    $$('[data-component="anchor-nav"]').forEach(function (nav) {
      if (!('IntersectionObserver' in window)) return;
      var links = $$('a[href^="#"]', nav);
      var io = new IntersectionObserver(function (en) {
        en.forEach(function (x) {
          if (!x.isIntersecting) return;
          links.forEach(function (a) { var on = a.getAttribute('href') === '#' + x.target.id; a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current'); });
        });
      }, { rootMargin: '-40% 0px -55% 0px' });
      links.forEach(function (a) { var t = document.getElementById(a.getAttribute('href').slice(1)); if (t) io.observe(t); });
    });
  }

  /* ---------- priority+ nav: items that do not fit move into "More" ---------- */
  function initPriorityNav() {
    $$('[data-component="priority-nav"]').forEach(function (nav) {
      var list = $('[data-priority-list]', nav), more = $('[data-priority-more]', nav), moreList = $('[data-priority-more-list]', nav);
      if (!list || !more) return;
      var items = $$(':scope > li:not([data-priority-more])', list);
      function layout() {
        items.forEach(function (li) { list.insertBefore(li, more); li.classList.remove('in-more'); });
        moreList.innerHTML = ''; more.hidden = true;
        if (!window.matchMedia('(min-width: 992px)').matches) return;
        more.hidden = false;
        var avail = nav.clientWidth - more.offsetWidth - 8, used = 0, overflow = [];
        items.forEach(function (li) { used += li.offsetWidth; if (used > avail) overflow.push(li); });
        if (!overflow.length) { more.hidden = true; return; }
        overflow.forEach(function (li) {
          var a = $('a', li); var n = document.createElement('li');
          n.innerHTML = '<a class="dropdown-item" href="' + a.getAttribute('href') + '"' + (a.getAttribute('aria-current') ? ' aria-current="page"' : '') + '>' + a.innerHTML + '</a>';
          moreList.appendChild(n); li.hidden = true; li.classList.add('in-more');
        });
      }
      function reset() { items.forEach(function (li) { li.hidden = false; }); layout(); }
      reset(); window.addEventListener('resize', reset);
    });
  }

  /* ---------- carousels with pause / play (WCAG 2.2.2) ---------- */
  function initCarousels() {
    if (!BS) return;
    $$('[data-component="carousel"]').forEach(function (el) {
      var auto = el.getAttribute('data-autoplay') !== 'false';
      var c = BS.Carousel.getOrCreateInstance(el, { interval: +el.getAttribute('data-bs-interval') || 6000, ride: false, pause: false, touch: true, keyboard: true });
      var inner = $('.carousel-inner', el), btn = $('[data-carousel="#' + el.id + '"]');
      var playing = auto && !reduceMotion;
      function sync() { if (btn) btn.textContent = playing ? (btn.getAttribute('data-pause-label') || 'Pause slideshow') : (btn.getAttribute('data-play-label') || 'Play slideshow'); if (inner) inner.setAttribute('aria-live', playing ? 'off' : 'polite'); }
      if (playing) c.cycle(); else c.pause(); sync();
      if (btn) btn.addEventListener('click', function () { playing = !playing; if (playing) c.cycle(); else c.pause(); sync(); });
      el.addEventListener('focusin', function () { c.pause(); });
      el.addEventListener('mouseenter', function () { c.pause(); });
      el.addEventListener('mouseleave', function () { if (playing) c.cycle(); });
      el.addEventListener('focusout', function (e) { if (playing && !el.contains(e.relatedTarget)) c.cycle(); });
      el.addEventListener('slid.bs.carousel', function () { $$('.carousel-indicators button', el).forEach(function (b) { if (b.classList.contains('active')) b.setAttribute('aria-current', 'true'); else b.removeAttribute('aria-current'); }); });
    });
  }

  /* ---------- ticker / marquee with pause ---------- */
  function initTickers() {
    $$('[data-component="ticker"]').forEach(function (t) {
      var btn = $('[data-ticker-toggle]', t);
      if (reduceMotion) t.classList.add('is-paused');
      function sync() { var p = t.classList.contains('is-paused'); if (btn) btn.textContent = p ? 'Play ticker' : 'Pause ticker'; }
      sync();
      if (btn) btn.addEventListener('click', function () { t.classList.toggle('is-paused'); sync(); });
    });
  }

  /* ---------- horizontal card slider ---------- */
  function initCardSliders() {
    $$('[data-slider-prev],[data-slider-next]').forEach(function (b) {
      var track = $(b.getAttribute('data-slider-prev') || b.getAttribute('data-slider-next')); if (!track) return;
      var dir = b.hasAttribute('data-slider-prev') ? -1 : 1;
      b.addEventListener('click', function () { var it = track.firstElementChild; var step = it ? it.getBoundingClientRect().width + 24 : track.clientWidth * .8; track.scrollBy({ left: dir * step, behavior: reduceMotion ? 'auto' : 'smooth' }); });
    });
  }

  /* =====================================================================
     GENERIC LIST FILTER
     scope: [data-component="list-filter"]  (optionally data-per-page)
     items: [data-filter-item] with data-search, data-tags, data-<key>
     controls: [data-filter="text"], select[data-filter="key"],
               input[type=checkbox][data-filter-tag] (value "x" requires, "!x" excludes),
               button[data-filter-btn="key"][data-value], select[data-sort]
     outputs: [data-filter-count] (data-noun), [data-filter-empty], [data-filter-pages]
     ===================================================================== */
  function initListFilters() {
    $$('[data-component="list-filter"]').forEach(function (scope) {
      var items = $$('[data-filter-item]', scope);
      var text = $$('[data-filter="text"]', scope);
      var selects = $$('select[data-filter]', scope);
      var tags = $$('[data-filter-tag]', scope);
      var btnGroups = {};
      $$('[data-filter-btn]', scope).forEach(function (b) { var k = b.getAttribute('data-filter-btn'); (btnGroups[k] = btnGroups[k] || []).push(b); });
      var btnVal = {}; Object.keys(btnGroups).forEach(function (k) { btnVal[k] = 'all'; });
      var sortSel = $('[data-sort]', scope);
      var count = $('[data-filter-count]', scope), noun = count ? count.getAttribute('data-noun') || 'items' : '';
      var pager = $('[data-filter-pages]', scope), per = +scope.getAttribute('data-per-page') || 0, page = 1;
      var grid = $('[data-filter-grid]', scope);
      var timer;
      var params = new URLSearchParams(location.search);
      if (params.get('q') && text[0]) text[0].value = params.get('q');
      selects.forEach(function (s) { var v = params.get(s.getAttribute('data-filter')); if (v && $('option[value="' + CSS.escape(v) + '"]', s)) s.value = v; });
      Object.keys(btnGroups).forEach(function (k) { var v = params.get(k); if (v && btnGroups[k].some(function (b) { return b.getAttribute('data-value') === v; })) btnVal[k] = v; });

      function matches(it) {
        var term = text.length ? text[0].value.trim().toLowerCase() : '';
        if (term) {
          var hay = (it.getAttribute('data-search') || it.textContent).toLowerCase();
          var near = it.getAttribute('data-zip');
          if (!(hay.indexOf(term) > -1 || (/^\d{5}$/.test(term) && near))) return false;
        }
        var itTags = (it.getAttribute('data-tags') || '').split(/\s+/);
        for (var i = 0; i < tags.length; i++) {
          if (!tags[i].checked) continue;
          var v = tags[i].value;
          if (v.charAt(0) === '!') { if (itTags.indexOf(v.slice(1)) > -1) return false; }
          else if (itTags.indexOf(v) === -1) return false;
        }
        for (var j = 0; j < selects.length; j++) {
          var k = selects[j].getAttribute('data-filter'), val = selects[j].value;
          if (!val || val === 'all') continue;
          var iv = it.getAttribute('data-' + k) || '';
          if (/^[\d.]+-[\d.]+$/.test(val) && iv !== '' && !isNaN(+iv)) { var r = val.split('-'); if (+iv < +r[0] || +iv >= +r[1]) return false; }
          else if (iv.split(/\s+/).indexOf(val) === -1) return false;
        }
        for (var b in btnVal) { if (btnVal[b] !== 'all' && (it.getAttribute('data-' + b) || '').split(/\s+/).indexOf(btnVal[b]) === -1) return false; }
        return true;
      }
      function sortItems() {
        var term = text.length ? text[0].value.trim() : '';
        if (!grid || (!sortSel && !/^\d{5}$/.test(term) && !grid.hasAttribute('data-zip-sort'))) return;
        var mode = sortSel ? sortSel.value : 'default';
        var sorted = items.slice().sort(function (a, b) {
          if (/^\d{5}$/.test(term) && a.getAttribute('data-zip')) return Math.abs(+a.getAttribute('data-zip') - +term) - Math.abs(+b.getAttribute('data-zip') - +term);
          if (mode === 'price-asc') return a.getAttribute('data-price') - b.getAttribute('data-price');
          if (mode === 'price-desc') return b.getAttribute('data-price') - a.getAttribute('data-price');
          if (mode === 'name') return a.getAttribute('data-name').localeCompare(b.getAttribute('data-name'));
          if (mode === 'abv-desc') return b.getAttribute('data-abv') - a.getAttribute('data-abv');
          return a.getAttribute('data-order') - b.getAttribute('data-order');
        });
        sorted.forEach(function (it) { grid.appendChild(it); });
      }
      function render(opts) {
        opts = opts || {};
        sortItems();
        Object.keys(btnGroups).forEach(function (k) { btnGroups[k].forEach(function (b) { var on = b.getAttribute('data-value') === btnVal[k]; b.classList.toggle('active', on); b.setAttribute('aria-pressed', String(on)); }); });
        var panes = $$('.tab-pane', scope);
        var pool = grid ? $$('[data-filter-item]', grid) : items;
        var ok = pool.filter(matches);
        var pages = per ? Math.max(1, Math.ceil(ok.length / per)) : 1; if (page > pages) page = pages;
        pool.forEach(function (it) { it.hidden = true; });
        (per ? ok.slice((page - 1) * per, page * per) : ok).forEach(function (it) { it.hidden = false; });
        $$('[data-filter-group]', scope).forEach(function (g) { g.hidden = !$$('[data-filter-item]', g).some(function (i) { return !i.hidden; }); });
        var shown = ok.length, total = pool.length, label = '';
        if (panes.length) {
          panes.forEach(function (p) { var vis = $$('[data-filter-item]', p).filter(function (i) { return !i.hidden; }).length; var e = $('[data-filter-empty]', p); if (e) e.hidden = vis > 0; });
          var ap = $('.tab-pane.active', scope) || panes[0];
          shown = $$('[data-filter-item]', ap).filter(function (i) { return !i.hidden; }).length; total = $$('[data-filter-item]', ap).length;
          var tab = document.getElementById(ap.getAttribute('aria-labelledby')); label = tab ? ' in ' + tab.textContent.trim() : '';
        } else { var e = $('[data-filter-empty]', scope); if (e) e.hidden = ok.length > 0; }
        var msg = per && ok.length ? 'Showing ' + ((page - 1) * per + 1) + '–' + Math.min(page * per, ok.length) + ' of ' + ok.length + ' ' + noun + '.' : 'Showing ' + shown + ' of ' + total + ' ' + noun + label + '.';
        if (count) { clearTimeout(timer); if (opts.typing) timer = setTimeout(function () { count.textContent = msg; }, 450); else count.textContent = msg; }
        if (pager) {
          pager.innerHTML = '';
          if (pages > 1) {
            var mk = function (lab, p, dis, cur) {
              var li = document.createElement('li'); li.className = 'page-item' + (dis ? ' disabled' : '') + (cur ? ' active' : '');
              var b = document.createElement('button'); b.type = 'button'; b.className = 'page-link'; b.innerHTML = lab; if (cur) b.setAttribute('aria-current', 'page'); if (dis) b.disabled = true;
              b.addEventListener('click', function () { page = p; render(); if (count) { count.setAttribute('tabindex', '-1'); count.focus(); } });
              li.appendChild(b); pager.appendChild(li);
            };
            mk('Previous<span class="visually-hidden"> page</span>', page - 1, page === 1);
            for (var i = 1; i <= pages; i++) mk('<span class="visually-hidden">Page </span>' + i, i, false, i === page);
            mk('Next<span class="visually-hidden"> page</span>', page + 1, page === pages);
          }
        }
      }
      text.forEach(function (t) { t.addEventListener('input', function () { page = 1; render({ typing: true }); }); var f = t.form; if (f && f.hasAttribute('data-filter-form')) f.addEventListener('submit', function (e) { e.preventDefault(); }); });
      selects.concat(tags).forEach(function (c) { c.addEventListener('change', function () { page = 1; render(); }); });
      if (sortSel) sortSel.addEventListener('change', function () { render(); });
      Object.keys(btnGroups).forEach(function (k) { btnGroups[k].forEach(function (b) { b.addEventListener('click', function () { btnVal[k] = b.getAttribute('data-value'); page = 1; render(); }); }); });
      $$('[data-filter-reset]', scope).forEach(function (b) {
        b.addEventListener('click', function () { text.forEach(function (t) { t.value = ''; }); selects.forEach(function (s) { s.value = s.options[0].value; }); tags.forEach(function (t) { t.checked = false; }); Object.keys(btnVal).forEach(function (k) { btnVal[k] = 'all'; }); page = 1; render(); var f = text[0] || selects[0]; if (f) f.focus(); });
      });
      $$('[data-bs-toggle="tab"]', scope).forEach(function (t) { t.addEventListener('shown.bs.tab', function () { render(); }); });
      render();
    });
  }

  /* ---------- deep links into tabs (#tab-x or #item-y inside a pane) ---------- */
  function initTabDeepLinks() {
    var h = location.hash; if (!h || !BS) return;
    var el = null; try { el = document.querySelector(h); } catch (e) { return; }
    if (!el) return;
    var tab = el.getAttribute('role') === 'tab' ? el : null;
    if (!tab) { var pane = el.closest('.tab-pane'); if (pane) tab = $('[data-bs-target="#' + pane.id + '"]'); }
    if (tab) BS.Tab.getOrCreateInstance(tab).show();
    if (el.hasAttribute('data-filter-item') || el.classList.contains('menu-item')) setTimeout(function () { el.classList.add('is-highlight'); el.setAttribute('tabindex', '-1'); el.focus(); }, 250);
  }

  /* ---------- sortable tables ---------- */
  function initSortableTables() {
    $$('[data-component="sortable-table"]').forEach(function (t) {
      var ths = $$('th[data-sort-key]', t);
      ths.forEach(function (th, idx) {
        var b = $('button', th);
        b.addEventListener('click', function () {
          var dir = th.getAttribute('aria-sort') === 'ascending' ? 'descending' : 'ascending';
          ths.forEach(function (x) { x.removeAttribute('aria-sort'); });
          th.setAttribute('aria-sort', dir);
          var col = Array.prototype.indexOf.call(th.parentNode.children, th);
          var tb = $('tbody', t), rows = $$('tr', tb);
          rows.sort(function (a, c) {
            var x = a.children[col].getAttribute('data-v') || a.children[col].textContent, y = c.children[col].getAttribute('data-v') || c.children[col].textContent;
            var n = !isNaN(parseFloat(x)) && !isNaN(parseFloat(y));
            var r = n ? parseFloat(x) - parseFloat(y) : x.localeCompare(y);
            return dir === 'ascending' ? r : -r;
          }).forEach(function (r) { tb.appendChild(r); });
          announce('Sorted by ' + b.textContent.trim() + ', ' + dir + '.');
        });
      });
    });
  }

  /* =====================================================================
     CART (shop) and BAG (food order): same model, different keys
     ===================================================================== */
  function makeCart(key) {
    return {
      key: key,
      items: function () { return Store.get(K(key), []); },
      save: function (v) { Store.set(K(key), v); document.dispatchEvent(new CustomEvent('cart:change', { detail: { key: key } })); },
      add: function (it) { var l = this.items(), f = null; l.forEach(function (x) { if (x.id === it.id) f = x; }); if (f) f.qty += it.qty || 1; else l.push({ id: it.id, name: it.name, price: +it.price, qty: it.qty || 1, meta: it.meta || '' }); this.save(l); },
      setQty: function (id, q) { this.save(this.items().map(function (x) { if (x.id === id) x.qty = q; return x; }).filter(function (x) { return x.qty > 0; })); },
      clear: function () { this.save([]); },
      subtotal: function () { return this.items().reduce(function (s, x) { return s + x.price * x.qty; }, 0); },
      count: function () { return this.items().reduce(function (s, x) { return s + x.qty; }, 0); },
      find: function (id) { var r = null; this.items().forEach(function (x) { if (x.id === id) r = x; }); return r; }
    };
  }
  var Carts = { cart: makeCart('cart'), bag: makeCart('bag') };
  function lineHTML(x, k) {
    return '<li class="cart-line" data-component="cart-line"><div class="cart-line-name">' + esc(x.name) + (x.meta ? '<span class="small d-block text-body-secondary">' + esc(x.meta) + '</span>' : '') + '<span class="small d-block text-body-secondary">' + money(x.price) + ' each</span></div>' +
      '<div class="qty-stepper" role="group" aria-label="Quantity of ' + esc(x.name) + '"><button type="button" class="btn btn-sm btn-outline-primary" data-qty="dec" data-cart-key="' + k + '" data-id="' + esc(x.id) + '" aria-label="Decrease quantity of ' + esc(x.name) + '">&minus;</button><span class="qty-value">' + x.qty + '</span><button type="button" class="btn btn-sm btn-outline-primary" data-qty="inc" data-cart-key="' + k + '" data-id="' + esc(x.id) + '" aria-label="Increase quantity of ' + esc(x.name) + '">+</button></div>' +
      '<div class="cart-line-total">' + money(x.price * x.qty) + '</div><button type="button" class="btn btn-link btn-sm p-0 cart-remove" data-qty="rm" data-cart-key="' + k + '" data-id="' + esc(x.id) + '">Remove<span class="visually-hidden"> ' + esc(x.name) + '</span></button></li>';
  }
  function renderCarts() {
    ['cart', 'bag'].forEach(function (k) {
      var c = Carts[k], items = c.items(), n = c.count(), sub = c.subtotal(), tax = sub * (D.taxRate || 0);
      $$('[data-' + k + '-count]').forEach(function (el) { el.textContent = n; el.hidden = n === 0; });
      $$('[data-' + k + '-label]').forEach(function (el) { el.textContent = (el.getAttribute('data-label-noun') || 'Cart') + ', ' + n + (n === 1 ? ' item' : ' items'); });
      $$('[data-' + k + '-lines]').forEach(function (el) { el.innerHTML = items.map(function (x) { return lineHTML(x, k); }).join(''); });
      $$('[data-' + k + '-empty]').forEach(function (el) { el.hidden = items.length > 0; });
      $$('[data-' + k + '-subtotal]').forEach(function (el) { el.textContent = money(sub); });
      $$('[data-' + k + '-tax]').forEach(function (el) { el.textContent = money(tax); });
      $$('[data-' + k + '-total]').forEach(function (el) { el.textContent = money(sub + tax); });
    });
  }
  function initCarts() {
    document.addEventListener('cart:change', renderCarts);
    document.addEventListener('click', function (e) {
      var b = e.target.closest('[data-qty]'); if (!b) return;
      var c = Carts[b.getAttribute('data-cart-key')], id = b.getAttribute('data-id'), it = c.find(id); if (!it) return;
      var act = b.getAttribute('data-qty'), container = b.closest('ul');
      var q = act === 'inc' ? it.qty + 1 : act === 'dec' ? it.qty - 1 : 0;
      c.setQty(id, q);
      announce(q > 0 ? it.name + ', quantity ' + q : it.name + ' removed');
      var again = q > 0 && container && $('[data-qty="' + act + '"][data-id="' + CSS.escape(id) + '"]', container);
      if (again) again.focus(); else { var h = container && container.closest('[data-component]'); var t = h && $('h2, h3', h); if (t) { t.setAttribute('tabindex', '-1'); t.focus(); } }
    });
    $$('[data-add]').forEach(function (b) {
      b.addEventListener('click', function () {
        var k = b.getAttribute('data-add'), name = b.getAttribute('data-name');
        Carts[k].add({ id: b.getAttribute('data-id'), name: name, price: b.getAttribute('data-price'), meta: b.getAttribute('data-meta') || '' });
        var msg = 'Added ' + name + (k === 'bag' ? ' to your order. Total ' + money(Carts.bag.subtotal() * (1 + (D.taxRate || 0))) + '.' : ' to your cart.');
        if (b.hasAttribute('data-quiet')) announce(msg); else toast(msg);
      });
    });
    var qv = $('#quick-view');
    if (qv) {
      var cur = null;
      qv.addEventListener('show.bs.modal', function (e) {
        var t = e.relatedTarget; if (!t) return;
        cur = { id: t.getAttribute('data-id'), name: t.getAttribute('data-name'), price: t.getAttribute('data-price'), key: t.getAttribute('data-cart-target') || 'cart' };
        $('#qv-title').textContent = cur.name; $('[data-qv-desc]', qv).textContent = t.getAttribute('data-desc') || '';
        $('[data-qv-price]', qv).textContent = money(cur.price);
        var im = $('[data-qv-img]', qv); if (im && t.getAttribute('data-img')) im.src = t.getAttribute('data-img');
        $('#qv-qty').value = 1;
      });
      $('[data-qv-add]', qv).addEventListener('click', function () {
        var q = Math.min(10, Math.max(1, parseInt($('#qv-qty').value, 10) || 1));
        Carts[cur.key].add({ id: cur.id, name: cur.name, price: cur.price, qty: q });
        BS.Modal.getInstance(qv).hide(); toast('Added ' + q + ' × ' + cur.name + '.');
      });
    }
    renderCarts();
  }

  /* ---------- bowl / tray builder ---------- */
  function initBuilders() {
    $$('[data-component="builder"]').forEach(function (f) {
      var out = $('[data-builder-summary]', f), max = +f.getAttribute('data-max-toppings') || 99;
      function state() {
        var base = $('input[data-role="base"]:checked', f);
        var picks = $$('input[data-role="topping"]:checked', f), extras = $$('input[data-role="extra"]:checked', f);
        var all = (base ? [base] : []).concat(picks, extras, $$('input[data-role="dressing"]:checked', f));
        var price = all.reduce(function (s, i) { return s + (+i.getAttribute('data-price') || 0); }, 0) + (+f.getAttribute('data-base-price') || 0);
        var cal = all.reduce(function (s, i) { return s + (+i.getAttribute('data-cal') || 0); }, 0);
        var pro = all.reduce(function (s, i) { return s + (+i.getAttribute('data-protein') || 0); }, 0);
        return { base: base, picks: picks, all: all, price: price, cal: cal, pro: pro };
      }
      function upd() {
        var st = state();
        $$('input[data-role="topping"]', f).forEach(function (i) { i.disabled = !i.checked && st.picks.length >= max; });
        var lim = $('[data-builder-limit]', f); if (lim) lim.textContent = st.picks.length + ' of ' + max + ' toppings chosen' + (st.picks.length >= max ? '. Remove one to choose another.' : '.');
        out.innerHTML = '<p class="h4 mb-1">' + money(st.price) + '</p><p class="mb-0">' + st.cal + ' calories &middot; ' + st.pro + ' g protein</p>';
      }
      f.addEventListener('change', upd); upd();
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var st = state(), err = $('[data-builder-error]', f);
        if (!st.base) { err.textContent = f.getAttribute('data-msg-base') || 'Choose a base to continue.'; err.hidden = false; var first = $('input[data-role="base"]', f); first.focus(); return; }
        err.hidden = true;
        var nameIn = $('[data-builder-name]', f);
        var name = (nameIn && nameIn.value.trim()) || f.getAttribute('data-default-name') || 'Custom bowl';
        var meta = st.all.map(function (i) { return i.getAttribute('data-label'); }).join(', ');
        Carts[f.getAttribute('data-cart') || 'bag'].add({ id: (f.getAttribute('data-id-prefix') || 'custom-') + Date.now(), name: name, price: st.price.toFixed(2), meta: meta });
        toast('Added ' + name + ' to your order (' + money(st.price) + ').');
      });
    });
  }

  /* ---------- pickup / delivery time options ---------- */
  function timeOptions(sel) {
    var key = sel.getAttribute('data-location') || Object.keys(D.hours || {})[0];
    var locSel = sel.getAttribute('data-location-from') && document.getElementById(sel.getAttribute('data-location-from'));
    if (locSel && locSel.value) key = locSel.value;
    var loc = D.hours[key], np = nowParts(loc && loc.tz), s = locStatus(key, np), start, end, label;
    if (!s) { sel.innerHTML = '<option value="">Choose a location first</option>'; return; }
    if (s.open) { start = Math.ceil((np.min + 20) / 15) * 15; end = s.closes - 15; label = 'Today'; }
    else if (s.opens !== undefined) { start = s.opens + 30; end = ((loc.days[String(s.dayIndex)] || [[0, 0]])[0][1]) - 15; label = s.inDays === 0 ? 'Today' : s.inDays === 1 ? 'Tomorrow' : DAYS[s.dayIndex]; }
    var o = [];
    if (start !== undefined) { for (var m = start; m <= end && o.length < 40; m += 15) o.push([label + '|' + m, label + ', ' + fmtMin(m)]); }
    sel.innerHTML = '<option value="">Choose a time</option>' + o.map(function (x) { return '<option value="' + x[0] + '">' + esc(x[1]) + '</option>'; }).join('');
  }
  function initTimeSelects() {
    $$('[data-pickup-times]').forEach(function (sel) {
      timeOptions(sel);
      var from = sel.getAttribute('data-location-from'); if (from) { var l = document.getElementById(from); if (l) l.addEventListener('change', function () { timeOptions(sel); }); }
    });
  }

  /* ---------- reservation / tour time slots ---------- */
  function hashStr(s) { var h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }
  function initSlots() {
    $$('[data-component="time-slots"]').forEach(function (box) {
      var form = box.closest('form'), date = document.getElementById(box.getAttribute('data-date')), party = document.getElementById(box.getAttribute('data-party'));
      var grid = $('[data-slot-grid]', box), hint = $('[data-slot-hint]', box), name = box.getAttribute('data-name') || 'slot';
      var maxParty = +box.getAttribute('data-max-party') || 8, large = $('[data-large-party]', form);
      var start = +box.getAttribute('data-start') || 690, startWe = +box.getAttribute('data-start-weekend') || start, end = +box.getAttribute('data-end') || 1290, step = +box.getAttribute('data-slot-step') || 30;
      var closed = (box.getAttribute('data-closed-days') || '').split(',').filter(Boolean).map(Number);
      if (date) { date.min = isoFromToday(+(date.getAttribute('data-min-days') || 0)); date.max = isoFromToday(+(date.getAttribute('data-max-days') || 30)); }
      function render() {
        grid.innerHTML = '';
        var big = party && (party.value === 'large' || +party.value > maxParty);
        if (large) large.hidden = !big;
        if (!date.value || (party && !party.value) || big) { hint.textContent = big ? 'Online booking is for parties of up to ' + maxParty + '.' : 'Choose a date' + (party ? ' and party size' : '') + ' to see available times.'; return; }
        var p = date.value.split('-'), dow = /^\d{4}-\d{2}-\d{2}$/.test(date.value) ? new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).getUTCDay() : -1;
        if (closed.indexOf(dow) > -1) { hint.textContent = box.getAttribute('data-closed-msg') || ('We are closed on ' + DAYS[dow] + 's. Choose another date.'); announce(hint.textContent); return; }
        var fe = fieldError(date); if (fe) { hint.textContent = fe; return; }
        var st = (dow === 0 || dow === 6) ? startWe : start, isToday = date.value === isoFromToday(0), now = nowParts().min, n = 0;
        for (var m = st; m <= end; m += step) {
          var ok = (hashStr(date.value + ':' + m + ':' + (party ? party.value : '')) % 10) > 2 && !(isToday && m <= now + 30);
          var id = name + '-' + m, d = document.createElement('div'); d.className = 'slot';
          d.innerHTML = '<input class="btn-check" type="radio" name="' + name + '" id="' + id + '" value="' + m + '"' + (ok ? '' : ' disabled') + '><label class="btn btn-outline-primary slot-btn" for="' + id + '">' + fmtMin(m) + (ok ? '' : '<span class="slot-full">Full</span>') + '</label>';
          grid.appendChild(d); if (ok) n++;
        }
        hint.textContent = n ? n + ' times available on ' + fmtDate(date.value) + (party ? ' for ' + party.value + (party.value === '1' ? ' guest.' : ' guests.') : '.') : 'No times are available on this date. Try another date.';
        announce(hint.textContent);
      }
      date.addEventListener('change', render); if (party) party.addEventListener('change', render);
      form.addEventListener('change', function (e) { if (e.target.name === name) { var er = $('#' + name + '-error'); if (er) { er.textContent = ''; er.classList.remove('d-block'); } } });
      form.addEventListener('vv:reset', render);
      box._render = render; render();
    });
  }
  function icsFor(r) {
    var pad = function (n) { return String(n).padStart(2, '0'); };
    var dt = r.date.replace(/-/g, '') + 'T' + pad(Math.floor(r.min / 60)) + pad(r.min % 60) + '00';
    var e = r.min + (r.duration || 120), dtEnd = r.date.replace(/-/g, '') + 'T' + pad(Math.floor(e / 60) % 24) + pad(e % 60) + '00';
    return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//' + S.name + '//Demo//EN', 'BEGIN:VEVENT', 'UID:' + r.code + '@' + S.key + '.example', 'DTSTAMP:' + new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + 'Z',
      'DTSTART;TZID=' + (S.tz || 'America/New_York') + ':' + dt, 'DTEND;TZID=' + (S.tz || 'America/New_York') + ':' + dtEnd, 'SUMMARY:' + r.title, 'LOCATION:' + (S.address || '').replace(/,/g, '\\,'), 'DESCRIPTION:Confirmation ' + r.code + ' (demo)', 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
  }

  /* ---------- gift cards ---------- */
  function initGiftCards() {
    var f = $('[data-form="gift-card"]'); if (!f) return;
    var custom = $('[data-custom-amount]', f), cIn = $('[data-custom-input]', f);
    function amount() { var r = $('input[name="gc-amount"]:checked', f); if (!r) return null; return r.value === 'custom' ? (parseFloat(cIn.value) || null) : parseFloat(r.value); }
    function preview() {
      var a = amount();
      $$('[data-preview-amount]').forEach(function (el) { el.textContent = a ? money(a).replace('.00', '') : '$—'; });
      var map = { to: '#gc-to-name', from: '#gc-from', msg: '#gc-message', format: 'input[name="gc-format"]:checked' };
      Object.keys(map).forEach(function (k) { var el = $('[data-preview-' + k + ']'); var src = $(map[k], f); if (el) el.textContent = src ? (src.type === 'radio' ? src.nextElementSibling.textContent : src.value.trim()) || el.getAttribute('data-default') || '' : ''; });
    }
    $$('input[name="gc-amount"]', f).forEach(function (r) { r.addEventListener('change', function () { var c = r.value === 'custom' && r.checked; custom.hidden = !c; cIn.required = c; if (c) cIn.focus(); preview(); }); });
    f.addEventListener('input', preview); f.addEventListener('change', preview);
    var first = $('input[name="gc-amount"]', f); if (first) first.checked = true;
    var send = $('#gc-send', f); if (send) { send.min = isoFromToday(0); send.max = isoFromToday(365); }
    f._amount = amount; preview();
    f.addEventListener('vv:reset', function () { first.checked = true; custom.hidden = true; cIn.required = false; preview(); });
  }

  /* ---------- copy link, char counters ---------- */
  function initCopyLink() {
    $$('[data-copy-link]').forEach(function (b) {
      b.addEventListener('click', function () {
        var ok = function () { toast('Link copied to clipboard.'); };
        if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(location.href).then(ok, function () { toast('The link is: ' + location.href); });
        else { var t = document.createElement('textarea'); t.value = location.href; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); ok(); } catch (e) { toast('The link is: ' + location.href); } t.remove(); }
      });
    });
  }
  function initCharCounts() {
    $$('[data-component="char-count"]').forEach(function (ta) {
      var max = ta.maxLength; if (!(max > 0)) return;
      var out = document.createElement('div'); out.className = 'form-text char-count'; out.id = ta.id + '-count';
      ta.parentNode.insertBefore(out, ta.nextSibling); addDesc(ta, out.id);
      var warned = false;
      function u() { var left = max - ta.value.length; out.textContent = ta.value.length + ' of ' + max + ' characters used'; if (left <= 20 && !warned) { announce(left + ' characters remaining'); warned = true; } if (left > 20) warned = false; }
      ta.addEventListener('input', u); u();
    });
  }

  /* ---------- site search (search.html) ---------- */
  function initSearchPage() {
    var list = $('[data-search-results]'); if (!list) return;
    var q = (new URLSearchParams(location.search).get('q') || '').trim();
    var input = $('#search-page-q'), count = $('[data-search-count]'), heading = $('[data-search-heading]');
    input.value = q; if (!q) return;
    var terms = q.toLowerCase().split(/\s+/).filter(Boolean);
    var res = (D.searchIndex || []).map(function (r) {
      var t = r.t.toLowerCase(), x = r.x.toLowerCase(), s = 0;
      terms.forEach(function (w) { if (t.indexOf(w) > -1) s += 3; if (x.indexOf(w) > -1) s += 1; });
      if (t.indexOf(q.toLowerCase()) > -1) s += 4; return { r: r, s: s };
    }).filter(function (o) { return o.s > 0; }).sort(function (a, b) { return b.s - a.s; });
    document.title = 'Search results for “' + q + '” | ' + S.name;
    heading.textContent = 'Results for “' + q + '”';
    count.textContent = res.length ? res.length + (res.length === 1 ? ' result' : ' results') + ' found.' : 'No results found. Try a different word.';
    list.innerHTML = res.slice(0, 30).map(function (o) { return '<li class="search-result" data-component="search-result"><p class="small text-body-secondary mb-1">' + esc(o.r.k) + '</p><h3 class="h5 mb-1"><a href="' + esc(o.r.u) + '">' + esc(o.r.t) + '</a></h3><p class="mb-0 small">' + esc(o.r.x) + '</p></li>'; }).join('');
  }

  /* ---------- "apply for this role" & "choose this space" buttons ---------- */
  function initPrefill() {
    $$('[data-prefill]').forEach(function (b) {
      b.addEventListener('click', function () {
        var sel = document.getElementById(b.getAttribute('data-prefill')); if (!sel) return;
        sel.value = b.getAttribute('data-value'); sel.dispatchEvent(new Event('change', { bubbles: true }));
        var f = document.getElementById(b.getAttribute('data-focus') || sel.id); if (f) f.focus();
        announce((b.getAttribute('data-announce') || 'Selected') + ': ' + (sel.options ? sel.options[sel.selectedIndex].text : sel.value) + '.');
      });
    });
  }

  /* =====================================================================
     FORM VALIDATION (WCAG 3.3.1 / 3.3.3) + multi-step forms
     ===================================================================== */
  var PHONE_RE = /^\D*(?:1\D*)?(?:\d\D*){10}$/;
  function addDesc(el, id) { var v = (el.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean); if (v.indexOf(id) === -1) v.push(id); el.setAttribute('aria-describedby', v.join(' ')); }
  function removeDesc(el, id) { var v = (el.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (x) { return x && x !== id; }); if (v.length) el.setAttribute('aria-describedby', v.join(' ')); else el.removeAttribute('aria-describedby'); }
  function fieldError(c) {
    var ds = c.dataset;
    if (c.type === 'radio') { var g = $$('input[name="' + c.name + '"]', c.form); return c.required && !g.some(function (r) { return r.checked; }) ? (ds.msgRequired || 'Choose an option.') : ''; }
    if (c.type === 'checkbox') return c.required && !c.checked ? (ds.msgRequired || 'Check this box to continue.') : '';
    if (c.type === 'file') return '';
    var v = c.value.trim();
    if (c.type === 'number' && c.validity && c.validity.badInput) return ds.msgRange || 'Enter a number.';
    if (c.required && !v) return ds.msgRequired || 'This field is required.';
    if (!v) return '';
    if (c.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return ds.msgType || 'Enter an email address like name@example.com.';
    if (ds.validate === 'phone' && !PHONE_RE.test(v)) return ds.msgPattern || 'Enter a 10-digit phone number.';
    if (ds.validate === 'dob') {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return 'Enter your date of birth.';
      var n = nowParts(), b = v.split('-').map(Number), age = n.y - b[0] - ((n.mo < b[1] || (n.mo === b[1] && n.d < b[2])) ? 1 : 0);
      if (age < (+ds.minAge || 21)) return ds.msgAge || ('You must be ' + (ds.minAge || 21) + ' or older.');
    }
    if (c.getAttribute('pattern') && !new RegExp('^(?:' + c.getAttribute('pattern') + ')$').test(v)) return ds.msgPattern || 'Check the format of this field.';
    if (c.type === 'number') { var x = Number(v); if (isNaN(x) || (c.min !== '' && x < +c.min) || (c.max !== '' && x > +c.max)) return ds.msgRange || ('Enter a number between ' + c.min + ' and ' + c.max + '.'); }
    if (ds.validate === 'future-date') {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return 'Enter a date in the format YYYY-MM-DD.';
      if (v < isoFromToday(+ds.minDays || 0)) return ds.msgMin || 'Choose a later date.';
      if (ds.maxDays && v > isoFromToday(+ds.maxDays)) return ds.msgMax || 'Choose an earlier date.';
      if (ds.closedDays) { var p = v.split('-'), dw = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).getUTCDay(); if (ds.closedDays.split(',').indexOf(String(dw)) > -1) return ds.msgClosed || ('We are closed on ' + DAYS[dw] + 's.'); }
    }
    if (c.type === 'date' && ds.validate !== 'future-date' && /^\d{4}-\d{2}-\d{2}$/.test(v) && ((c.min && v < c.min) || (c.max && v > c.max))) return ds.msgRange || ('Choose a date between ' + c.min + ' and ' + c.max + '.');
    if (c.maxLength > 0 && v.length > c.maxLength) return 'Use ' + c.maxLength + ' characters or fewer.';
    return '';
  }
  function setError(c, msg) {
    var gid = c.type === 'radio' ? c.name : c.id, err = document.getElementById(gid + '-error');
    var ts = c.type === 'radio' ? $$('input[name="' + c.name + '"]', c.form) : [c];
    ts.forEach(function (t) { if (msg) { t.setAttribute('aria-invalid', 'true'); t.classList.add('is-invalid'); if (err) addDesc(t, err.id); } else { t.removeAttribute('aria-invalid'); t.classList.remove('is-invalid'); if (err) removeDesc(t, err.id); } });
    if (err) { err.textContent = msg || ''; err.classList.toggle('d-block', !!msg); }
    var fs = document.getElementById(gid + '-group'); if (fs) fs.classList.toggle('is-invalid-group', !!msg);
  }
  function controls(root) { return $$('input, select, textarea', root).filter(function (c) { return c.name && !c.disabled && c.type !== 'submit' && c.type !== 'button' && !c.closest('[hidden]') && !c.closest('[data-form-success]') && !c.hasAttribute('data-novalidate'); }); }
  function groupChecks(root) {
    var errs = [];
    $$('[data-require-one]', root).forEach(function (fs) {
      if (fs.closest('[hidden]')) return;
      var boxes = $$('input[type="checkbox"]', fs), ok = boxes.some(function (c) { return c.checked; }), er = document.getElementById(fs.id.replace(/-group$/, '') + '-error');
      if (er) { er.textContent = ok ? '' : fs.getAttribute('data-require-one'); er.classList.toggle('d-block', !ok); }
      fs.classList.toggle('is-invalid-group', !ok);
      boxes.forEach(function (c) { if (ok) { c.removeAttribute('aria-invalid'); if (er) removeDesc(c, er.id); } else { c.setAttribute('aria-invalid', 'true'); if (er) addDesc(c, er.id); } });
      if (!ok) errs.push({ id: boxes[0].id, msg: fs.getAttribute('data-require-one') });
    });
    $$('[data-component="time-slots"]', root).forEach(function (box) {
      if (box.closest('[hidden]')) return;
      var name = box.getAttribute('data-name') || 'slot', party = document.getElementById(box.getAttribute('data-party')), date = document.getElementById(box.getAttribute('data-date'));
      var max = +box.getAttribute('data-max-party') || 8;
      if (party && (party.value === 'large' || +party.value > max)) { errs.push({ id: party.id, msg: box.getAttribute('data-large-msg') || 'For larger groups, use the private events inquiry form.' }); return; }
      if (date.value && (!party || party.value) && !$('input[name="' + name + '"]:checked', root)) {
        var er = document.getElementById(name + '-error'), first = $('input[name="' + name + '"]:not(:disabled)', root);
        if (er) { er.textContent = 'Choose an available time.'; er.classList.add('d-block'); }
        errs.push({ id: first ? first.id : date.id, msg: 'Choose an available time.' });
      }
    });
    $$('[data-requires-cart]', root).forEach(function (el) {
      var k = el.getAttribute('data-requires-cart');
      if (!Carts[k].count()) errs.push({ id: el.getAttribute('data-focus-target') || el.id, msg: el.getAttribute('data-requires-msg') || 'Add at least one item first.' });
    });
    return errs;
  }
  function validate(root) {
    var errs = [], seen = {};
    controls(root).forEach(function (c) {
      var key = c.type === 'radio' ? 'r:' + c.name : c.id; if (seen[key]) return; seen[key] = 1;
      var m = fieldError(c); setError(c, m);
      if (m) errs.push({ id: (c.type === 'radio' ? $('input[name="' + c.name + '"]', c.form) : c).id, msg: m });
    });
    return errs.concat(groupChecks(root));
  }
  function showSummary(form, errs) {
    var s = $('[data-error-summary]', form); if (!s) return;
    if (!errs.length) { s.hidden = true; s.innerHTML = ''; return; }
    s.innerHTML = '<h3 class="h6 mb-2">' + (errs.length === 1 ? 'There is a problem with 1 field' : 'There are problems with ' + errs.length + ' fields') + '</h3><ul class="mb-0">' + errs.map(function (e) { return '<li><a href="#' + esc(e.id) + '">' + esc(e.msg) + '</a></li>'; }).join('') + '</ul>';
    s.hidden = false;
    $$('a', s).forEach(function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); var t = document.getElementById(a.getAttribute('href').slice(1)); if (t) { if (/^H\d$/.test(t.tagName) || t.tagName === 'SECTION') t.setAttribute('tabindex', '-1'); t.focus(); } }); });
    s.focus();
  }
  function showSuccess(form, html) {
    var ok = $('[data-form-success]', form); if (!ok) return;
    Array.prototype.forEach.call(form.children, function (ch) { if (ch !== ok) { ch.setAttribute('data-was-hidden', ch.hidden ? '1' : '0'); ch.hidden = true; } });
    if (html) { var b = $('[data-success-body]', ok); if (b) b.innerHTML = html; }
    ok.hidden = false; ok.focus();
  }
  function resetForm(form) {
    var ok = $('[data-form-success]', form); form.reset();
    Array.prototype.forEach.call(form.children, function (ch) { if (ch !== ok) ch.hidden = ch.getAttribute('data-was-hidden') === '1'; });
    $$('[data-error-summary]', form).forEach(function (s) { s.hidden = true; }); if (ok) ok.hidden = true;
    if (form._goStep) form._goStep(0, true);
    form.dispatchEvent(new Event('vv:reset')); var f = controls(form)[0]; if (f) f.focus();
  }
  function summaryList(pairs) { return '<dl class="summary-list">' + pairs.map(function (p) { return '<div><dt>' + esc(p[0]) + '</dt><dd>' + esc(p[1]) + '</dd></div>'; }).join('') + '</dl>'; }
  function val(form, sel) { var e = $(sel, form); if (!e) return ''; if (e.tagName === 'SELECT') return e.value ? e.options[e.selectedIndex].text : ''; return e.value.trim(); }
  function linesHTML(items) { return '<ul>' + items.map(function (x) { return '<li>' + x.qty + ' × ' + esc(x.name) + (x.meta ? ' (' + esc(x.meta) + ')' : '') + ': ' + money(x.price * x.qty) + '</li>'; }).join('') + '</ul>'; }

  var HANDLERS = {
    booking: function (form) {
      var box = $('[data-component="time-slots"]', form), name = box.getAttribute('data-name') || 'slot';
      var m = +$('input[name="' + name + '"]:checked', form).value, date = document.getElementById(box.getAttribute('data-date')).value;
      var party = box.getAttribute('data-party') ? document.getElementById(box.getAttribute('data-party')).value : '';
      var r = { code: code(form.getAttribute('data-code') || 'R'), date: date, min: m, party: party, title: (form.getAttribute('data-event-title') || 'Reservation at ' + S.name) + (party ? ' (party of ' + party + ')' : ''), duration: +form.getAttribute('data-duration') || 120 };
      form._last = r;
      var pairs = [['Confirmation', r.code], ['Date', fmtDate(date)], ['Time', fmtMin(m)]];
      if (party) pairs.push(['Guests', party]);
      $$('[data-summary-field]', form).forEach(function (el) { var v = el.type === 'radio' ? ($('input[name="' + el.name + '"]:checked', form) || {}).value : val(form, '#' + el.id); if (el.type === 'radio') { var ch = $('input[name="' + el.name + '"]:checked', form); v = ch ? ch.nextElementSibling.textContent : ''; } if (v && !pairs.some(function (p) { return p[0] === el.getAttribute('data-summary-field'); })) pairs.push([el.getAttribute('data-summary-field'), v]); });
      var html = summaryList(pairs) + '<p class="small mb-0">Demo only: nothing was booked and no email was sent.</p>';
      var modal = document.getElementById(form.getAttribute('data-confirm-modal') || 'booking-confirm');
      if (modal && BS) { $('[data-confirm-body]', modal).innerHTML = html; BS.Modal.getOrCreateInstance(modal).show(); }
      return html;
    },
    order: function (form) {
      var c = Carts[form.getAttribute('data-cart') || 'bag'], items = c.items(), sub = c.subtotal(), tax = sub * (D.taxRate || 0);
      var fee = 0, mode = $('input[name="fulfil"]:checked', form); if (mode && mode.value === 'delivery') fee = +form.getAttribute('data-delivery-fee') || 0;
      var pairs = [['Order number', code(form.getAttribute('data-code') || 'O')]];
      $$('[data-summary-field]', form).forEach(function (el) { var v = el.type === 'radio' ? (($('input[name="' + el.name + '"]:checked', form) || {}).nextElementSibling || {}).textContent : val(form, '#' + el.id); if (v && !pairs.some(function (p) { return p[0] === el.getAttribute('data-summary-field'); })) pairs.push([el.getAttribute('data-summary-field'), v]); });
      var html = summaryList(pairs) + linesHTML(items) + '<p class="fw-semibold">Total: ' + money(sub + tax + fee) + (fee ? ' (includes ' + money(fee) + ' delivery)' : '') + '</p><p class="small mb-0">Demo only: no payment was taken and nothing was sent to the kitchen.</p>';
      c.clear(); return html;
    },
    checkout: function (form) {
      var c = Carts.cart, items = c.items(), ship = $('input[name="ship"]:checked', form), fee = ship ? (+ship.getAttribute('data-fee') || 0) : 0, sub = c.subtotal();
      var html = '<p>Order <strong>' + code('S') + '</strong> is confirmed.</p>' + linesHTML(items) + '<p class="fw-semibold">Total: ' + money(sub + fee) + (fee ? ' including ' + money(fee) + ' shipping' : '') + '</p><p class="small mb-0">Demo only: no payment was taken and nothing will ship.</p>';
      c.clear(); return html;
    },
    'gift-card': function (form) {
      var a = form._amount(), to = val(form, '#gc-to-name');
      Carts.cart.add({ id: 'gift-' + Date.now(), name: (form.getAttribute('data-item-name') || 'Gift card') + ' for ' + to, price: a, qty: 1 });
      return '<p>A ' + money(a) + ' gift card for ' + esc(to) + ' is in your cart.</p>';
    },
    'gift-balance': function (form) {
      var raw = $('[data-balance-code]', form).value.toUpperCase().replace(/[^A-Z0-9]/g, ''), out = $('[data-balance-result]', form), bal = (D.demoGiftCards || {})[raw];
      out.innerHTML = bal === undefined ? '<p class="alert alert-warning mb-0">We could not find a gift card with that number. Check it and try again.</p>' : '<p class="alert alert-success mb-0">Card ending ' + raw.slice(-4) + ' has a balance of <strong>' + money(bal) + '</strong>.</p>';
      return false;
    },
    'store-finder': function (form) { return false; },
    generic: function (form) {
      var c = form.getAttribute('data-code');
      return c ? '<p>Reference number <strong>' + code(c) + '</strong>.</p>' : null;
    }
  };

  function initMultiStep(form) {
    var steps = $$('[data-step]', form); if (!steps.length) return;
    var prog = $('[data-step-progress]', form), idx = 0;
    function go(i, quiet) {
      idx = i; steps.forEach(function (s, j) { s.hidden = j !== i; });
      if (prog) $$('li', prog).forEach(function (li, j) { li.classList.toggle('is-current', j === i); li.classList.toggle('is-done', j < i); if (j === i) li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current'); });
      $$('[data-step-back]', form).forEach(function (b) { b.hidden = i === 0; });
      $$('[data-step-next]', form).forEach(function (b) { b.hidden = i === steps.length - 1; });
      $$('[data-step-submit]', form).forEach(function (b) { b.hidden = i !== steps.length - 1; });
      if (!quiet) { var h = $('legend, h3', steps[i]); if (h) { h.setAttribute('tabindex', '-1'); h.focus(); } announce('Step ' + (i + 1) + ' of ' + steps.length); }
    }
    form._goStep = go;
    $$('[data-step-next]', form).forEach(function (b) { b.addEventListener('click', function () { var e = validate(steps[idx]); if (e.length) { showSummary(form, e); return; } showSummary(form, []); go(idx + 1); }); });
    $$('[data-step-back]', form).forEach(function (b) { b.addEventListener('click', function () { showSummary(form, []); go(idx - 1); }); });
    go(0, true);
  }

  function initForms() {
    $$('[data-component="validated-form"]').forEach(function (form) {
      initMultiStep(form);
      form.addEventListener('focusout', function (e) { var c = e.target; if (!c.name || c.type === 'radio' || c.type === 'checkbox') return; if (c.value || c.getAttribute('aria-invalid') === 'true') setError(c, fieldError(c)); });
      form.addEventListener('change', function (e) { var c = e.target; if (!c.name) return; if (c.type === 'radio' || ((c.type === 'checkbox' || c.tagName === 'SELECT') && c.getAttribute('aria-invalid') === 'true')) setError(c, fieldError(c)); });
      form.addEventListener('input', function (e) { var c = e.target; if (c.getAttribute('aria-invalid') === 'true' && !fieldError(c)) setError(c, ''); });
      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var errs = validate(form), s = $('[data-error-summary]', form);
        if (errs.length) { if (!s || form.getAttribute('data-form') === 'newsletter') { var f = document.getElementById(errs[0].id); if (f) f.focus(); } else showSummary(form, errs); return; }
        showSummary(form, []);
        var h = HANDLERS[form.getAttribute('data-form')] || HANDLERS.generic, r = h(form);
        if (r === false) return; showSuccess(form, r);
      });
      $$('[data-form-reset]', form).forEach(function (b) { b.addEventListener('click', function () { resetForm(form); }); });
      $$('[data-ics-download]', form).forEach(function (b) {
        b.addEventListener('click', function () {
          if (!form._last) return;
          var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([icsFor(form._last)], { type: 'text/calendar' })); a.download = S.key + '-booking.ics';
          document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); toast('Calendar file downloaded.');
        });
      });
      form.addEventListener('vv:reset', function () { $$('[data-pickup-times]', form).forEach(timeOptions); });
    });
    // show/hide dependent fields: [data-show-when="name=value"]
    $$('[data-show-when]').forEach(function (el) {
      var parts = el.getAttribute('data-show-when').split('='), form = el.closest('form') || document;
      function upd() { var c = $('[name="' + parts[0] + '"]:checked', form) || $('select[name="' + parts[0] + '"]', form); var on = c && c.value === parts[1]; el.hidden = !on; $$('[data-required-when-shown]', el).forEach(function (i) { i.required = !!on; }); }
      form.addEventListener('change', upd); upd();
    });
  }

  function boot() {
    initAnnouncement(); initOpenStatus(); setInterval(initOpenStatus, 60000); initStickyHeader(); initPriorityNav();
    initBackToTop(); initAnchorNav(); initCarousels(); initTickers(); initCardSliders(); initListFilters(); initTabDeepLinks();
    initSortableTables(); initCarts(); initBuilders(); initTimeSelects(); initSlots(); initGiftCards(); initCopyLink(); initCharCounts();
    initSearchPage(); initPrefill(); initForms(); initCookies(); initAgeGate();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* Morrow: ?location= preselects a bakery on the order page; ?region= limits the list */
(function () {
  var p = new URLSearchParams(location.search), r = p.get('region'), sel = document.getElementById('o-location'), note = document.querySelector('[data-region-note]');
  var map = { bay: ['mission', 'sunset', 'berkeley'], la: ['silver-lake', 'arts-district'] }, names = { bay: 'Bay Area', la: 'Los Angeles' };
  var lk = p.get('location');
  if (sel && lk && sel.querySelector('option[value="' + lk + '"]')) { sel.value = lk; sel.dispatchEvent(new Event('change', { bubbles: true })); if (note) note.innerHTML = 'Picking up at <strong>' + sel.options[sel.selectedIndex].text + '</strong>. <button type="button" class="btn btn-link p-0 align-baseline" data-bs-toggle="modal" data-bs-target="#region-chooser">Change bakery</button>'; }
  var od = document.getElementById('o-date');
  function cakeLead() { var bag = []; try { bag = JSON.parse(sessionStorage.getItem('morrow-bag') || '[]'); } catch (e) {} var hasCake = (bag.items || bag).some && (bag.items || bag).some(function (i) { return /^cake-/.test(i.id); }); if (od) { od.setAttribute('data-min-days', hasCake ? '7' : '0'); od.setAttribute('data-msg-min', hasCake ? 'Your order includes a whole cake. Choose a date at least 7 days from today.' : 'Choose today or a later date.'); } }
  if (od) { cakeLead(); document.addEventListener('cart:change', cakeLead); }
  if (sel && map[r]) {
    Array.prototype.slice.call(sel.options).forEach(function (o) { if (o.value && map[r].indexOf(o.value) === -1) o.remove(); });
    if (note) note.innerHTML = 'Showing ' + names[r] + ' bakeries. <button type="button" class="btn btn-link p-0 align-baseline" data-bs-toggle="modal" data-bs-target="#region-chooser">Change region</button>';
  }
})();
;
