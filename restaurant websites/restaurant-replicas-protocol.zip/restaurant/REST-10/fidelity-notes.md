<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-10 | Category: restaurant (Café / bakery) | Source: Tartine https://tartinebakery.com/ -->
# Fidelity notes: Morrow Bakery ↔ Tartine

**Original:** https://tartinebakery.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Morrow Bakery. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured in a browser) | Replica |
|---|---|---|
| Background | White, with `#F6F4F4` off-white bands (Who We Are, press quote) | Same |
| Type | PitchSans, a monospace face, everywhere. Headings weight 500 to 600; h2 letter-spaced 1.12px | **IBM Plex Mono** (OFL) for headings, navigation, buttons and links. Body paragraphs use **IBM Plex Sans** because long passages in a monospace face are harder to read |
| Ink | `#231F20`; secondary text `#4A494A` | Same |
| Header | Promo bar ("Click here to pre-order…"), then a menu button on the left, the letter-spaced wordmark centered, and "NATIONAL SHIPPING" plus a solid amber **ORDER** button on the right. About 188px tall and sticky | Same layout (kit `split` variant). The promo bar scrolls away, so only the main bar sticks |
| Navigation | Left drawer (Bootstrap offcanvas, white, 400px) with Locations by region and About | Same left drawer, 400px |
| Primary button | Solid amber `#C87E1E` with `#231F20` text (5.0:1), square corners | Same |
| Outline buttons | 1px amber border, `#413941` text, 16px by 40px padding ("JOIN TARTINE", "ORDER NATIONWIDE") | Same (text 11.1:1; the amber border reaches 3.25:1) |
| Hero | Full-bleed dark photo with a white h1 "Welcome to…" and a monospace lede at bottom left, no panel | Same, on a dark placeholder with a gradient scrim so the white text keeps contrast |
| Home sections | Stacked: large photo, uppercase title, one line of copy, then a full-width uppercase "CLICK HERE TO… →" link over a thin amber rule | Same pattern (`arrow-link` component) for Special Order Cakes, Holiday Pre-Order and Gift Cards |
| Press quote | Large monospace pull quote in `#4A494A`, source name centered | Same, with a fictional publication |
| Footer | White, centered dark-red tagline (`#973A31`), wordmark and legal links bottom right, a large thin circle drawn behind | Same; the tagline is original text |
| Order dialog | "ORDERING FOR" dialog: Bay Area and LA tabs, a button per bakery, Cancel | "Ordering for" dialog: bakeries grouped under region headings, Cancel; Seoul is in-store only |

## Mirrored structure
- **Navigation:** Locations by region; About (Our Story, Our Bread, Join); Order; Press; Stories.
- **Utility links:** "Join" and "Order Nationwide" appear as outline buttons and links.
- **Promo bar:** a holiday pre-order banner.
- **Location pages:** a sticky in-page sub-navigation (About, Dining, Order, Cakes, Gift Cards, Location).
- **Special cakes** with 7 days notice; catering; Stories with recipes.

## Adapted, added or left out
- **Added:** region tabs with search on Locations, per-location time zones (Seoul), a cake builder with live price, a holiday pre-order date window, menu dietary filters, a nationwide checkout, FAQ, site search and a 404 page.
- **Menus:** the original links PDF menus; the replica uses accessible HTML menus.
- **Header:** the original's sticky header is about 188px tall; here the promo bar scrolls away and only the main bar sticks.
- **Locations:** the original lists about 20 bakeries (8 in Korea); the replica has 7 across the same three regions.
- **Order dialog:** the original groups bakeries under Bay Area and LA tabs; the replica lists them under region headings, which needs no extra keyboard pattern.

## Observations on the original that were not copied
Observed in a browser on the live site:

1. **Order dialog:** pressing Escape did not close it, and when the page was scrolled the backdrop covered the page while the dialog itself was out of view.
2. **Two `h1` elements** on the home page: "Home" and "Welcome to Tartine".
3. **Sticky header** about 188px tall, which can cover focused elements when tabbing down the page (WCAG 2.4.11 risk).
4. **Cookie consent** opens as a modal on first visit and blocks the page until answered.
5. **Menus** are linked as PDFs rather than HTML.
6. **Link text:** "Click here" in the promo bar, and long uppercase "CLICK HERE TO…" links.

The replica does not copy these defects: the dialog closes with Escape and stays in view, there is one `h1` per page, and only the slim main bar sticks.


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `cakes.html` | Special Cakes | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `careers.html` | Join Morrow | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `catering.html` | Catering | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `holiday.html` | Holiday Pre-Order | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Morrow Bakery | Tartine home page |
| `location-arts-district.html` | Morrow Arts District | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-berkeley.html` | Morrow Berkeley | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-hannam.html` | Morrow Hannam | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-mission.html` | Morrow Mission | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-seongsu.html` | Morrow Seongsu | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-silver-lake.html` | Morrow Silver Lake | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-sunset.html` | Morrow Inner Sunset | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `locations.html` | Locations | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `menu.html` | Menu | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `order.html` | Order for Pickup | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `our-bread.html` | Our Bread | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `our-story.html` | Our Story | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `press.html` | Press | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `shipping.html` | Order Nationwide | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `stories.html` | Stories | Mirrors a Tartine page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `story-country-loaf-recipe.html` | Recipe: our country loaf at home | Article detail page (child of `stories.html`); article content is original |
| `story-holiday-preorders.html` | Holiday pre-orders are open | Article detail page (child of `stories.html`); article content is original |
| `story-join-our-team.html` | We're hiring bakers in Los Angeles | Article detail page (child of `stories.html`); article content is original |
| `story-morning-bun-recipe.html` | Recipe: morning buns | Article detail page (child of `stories.html`); article content is original |
| `story-seoul-one-year.html` | One year in Seoul | Article detail page (child of `stories.html`); article content is original |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
