<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-05 | Category: restaurant (Multi-location restaurant group) | Source: Hogsalt https://hogsalt.com/ -->
# Fidelity notes: Copperline Hospitality ↔ Hogsalt

**Original:** https://www.hogsalt.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Copperline Hospitality. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured) | Replica |
|---|---|---|
| Page | Black `#000` background, tan text `#D6CEBA` | Same black and tan (13.4:1) |
| Headings | AW Conqueror **Didot**, uppercase, gold `#B48549`, 600 weight | **Playfair Display** (OFL, a Didot-style face), uppercase, gold `#C99A5E` on the dark surfaces (7.4:1). The original `#B48549` is kept for buttons and borders (6.4:1 on black). |
| Navigation | Open Sans 600, uppercase, letter-spaced, tan | **Open Sans** uppercase, same spacing, in a full-screen overlay menu |
| Header | Fixed, transparent, hamburger | Fixed transparent overlay on the home slider, solid black once scrolled |
| Hero | Full-bleed image slider with gold chevrons | Bootstrap carousel with gold-tinted controls and a pause button |
| Brand strip | Gold restaurant logos on black | Gold text "logos" for six fictional restaurants, each linking to its page |
| Buttons | Square, outlined tan | Square; gold fill with black text or tan outline |

## Mirrored structure
- **Top-level navigation:** Rewards, Wine Club, Restaurants, About, Private Events, Careers, Internships, Gift Cards.
- **Private events:** spaces tagged by city and capacity (for example "101–150" and "Full Buyout"), filterable, with previous/next links between space pages.
- **Restaurant portfolio:** a logo strip and per-restaurant pages.

## Adapted, added or left out
- **Added:** a three-step inquiry with a progress indicator, a restaurant directory with city and type filters, restaurant pages with live hours, the Rewards sign-up, the Journal with filters and pagination, FAQ, gift card checkout, site search and a 404 page.
- **Restaurant pages:** the original sends visitors to each restaurant's own website. The replica keeps them on-site as template pages.

## Observations on the original that were not copied
1. The "Skip to Content" link has tan text on a tan background (`#B48549` on `#D6CEBA`), which is hard to read.
2. The home page has no `h1`; the first heading is an `h2` ("Beautiful venues, exceptional hospitality").
3. The slider's previous/next arrows are images without visible text labels.
4. Restaurant logos are background images, so their names are not available as text.


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | About | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `careers.html` | Careers | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Copperline Hospitality | Hogsalt home page |
| `inquiry.html` | Event Inquiry | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `internships.html` | Internships | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `journal-burger-history.html` | The story of the double cheeseburger | Article detail page (child of `journal.html`); article content is original |
| `journal-holiday-parties.html` | Planning a holiday party with us | Article detail page (child of `journal.html`); article content is original |
| `journal-intern-program.html` | Meet this year's culinary interns | Article detail page (child of `journal.html`); article content is original |
| `journal-little-elm-rye.html` | Why our rye takes three days | Article detail page (child of `journal.html`); article content is original |
| `journal-ostranders-opens.html` | Ostrander's Oyster Bar is open in New York | Article detail page (child of `journal.html`); article content is original |
| `journal-rewards-launch.html` | Introducing Copperline Rewards | Article detail page (child of `journal.html`); article content is original |
| `journal-wine-club-fall.html` | Fall Wine Club shipment notes | Article detail page (child of `journal.html`); article content is original |
| `journal.html` | Journal | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `private-events.html` | Private Events | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-brass-fox.html` | The Brass Fox | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-juniper.html` | Juniper Steakhouse | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-ledger-room.html` | The Ledger Room | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-little-elm.html` | Little Elm Bakery | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-maison-verlaine.html` | Maison Verlaine | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-ostranders.html` | Ostrander's Oyster Bar | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurants.html` | Our Restaurants | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `rewards.html` | Rewards | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `space-brass-fox-den.html` | The Den at The Brass Fox | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-juniper-buyout.html` | Juniper Steakhouse, full buyout | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-juniper-cellar.html` | The Cellar at Juniper | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-ledger-buyout.html` | The Ledger Room, full buyout | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-ostranders-mezz.html` | The Mezzanine at Ostrander's | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-verlaine-salon.html` | Le Salon at Maison Verlaine | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `wine-club.html` | Wine Club | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
