# REST-05: Copperline Hospitality

## Protocol record (WEB-REPLICA-V1.0)

| Field | Value |
|---|---|
| Replica ID | REST-05 |
| Category | restaurant: Multi-location restaurant group |
| Fictional branding | Copperline Hospitality (fictional business; 555 phone numbers, `.example` email) |
| Approved source | Hogsalt, https://hogsalt.com/ |
| Source verification | Live status verified 2026-11-06 by web search during Phase A; source approved by Isaac. Visual design (colors, fonts, spacing, header and button styles) measured from computed styles in a desktop browser, 2026-11-06/07. |
| Run locally | Open `index.html` in a browser. No server, build step or network is needed. |
| Layout | `*.html` pages, `css/styles.css`, `js/main.js`, `assets/` (images, fonts, vendor/bootstrap, vendor/jquery), `README.md`, `fidelity-notes.md`, `component-inventory.json` |
| Deviations | The protocol prohibits both libraries below. Both were included by Isaac's decision on 2026-11-07; see fidelity-notes.md. **Bootstrap 5.3.3**, stored locally, is used for layout and components. **jQuery 3.7.1**, stored locally, is loaded on every page, but the site's own code does not call it. |

### Sample data

| Data | Count |
|---|---|
| Locations with hours | 6 |
| Blog / news / story articles | 7 |
| Site-search index entries | 44 |
| Demo gift card numbers | 2 |

### Quality-control gates

| Gate | Result |
|---|---|
| 13. Technology | **Fail (documented deviations):** Bootstrap 5.3.3 is used, and jQuery 3.7.1 is loaded on every page but not called by the site's code. **Pass:** no other framework or library, no PHP, no backend, no build step, and no remote runtime dependencies (automated scan of every page). |
| 14. Completeness | **Pass:** all 36 pages and the 3 required documents are present. Automated link audit of every `href`/`src` in the HTML, every `url()` in the CSS and every `.html` reference in the JS: 0 broken. |
| 15. Structure | **Pass (automated):** every page has `header`, a labeled `nav`, `main` and `footer` carrying `data-section`; there are 1062 `data-component` instances. The region hierarchy was compared with the source during the build (see fidelity-notes.md); there was no independent review. |
| 16. Interaction | **Pass:** 29/29 scripted Playwright checks (forms, filters, search, navigation and site-specific flows). Simulated flows say they are demos. `href="#"` placeholders: 0. |
| 17. Accessibility review | **Automated pass:** axe-core 4.14 found 0 violations on all 36 pages at 1280px and 375px. Also checked by script: no horizontal scroll at 375px and no content overlapping the footer. **Not tested:** manual keyboard walkthrough, screen readers, 200% text zoom, and reduced-motion behavior (implemented in CSS/JS but not exercised). |
| 18. Traceability | **Pass:** this README, fidelity-notes.md and component-inventory.json were generated from the delivered files. `component-inventory.json` records which components a script exercised and which were not tested. |
| 19. Scope | **Pass, with additions:** the intentional additions (FAQ, site search, 404 and others) are labeled in the page mapping and in fidelity-notes.md. |

Automated results support a WCAG 2.2 AA–oriented baseline. They do not prove conformance.

---

## About Copperline Hospitality

**Copperline Hospitality** is a fictional restaurant group with six concepts in Chicago and New York. This static website mirrors the *structure and visual language* of a real restaurant website, [Hogsalt](https://www.hogsalt.com/): its page set, layout regions, navigation pattern, interactive features, color palette and typographic style. All names, copy, prices, people and addresses are invented, and all images are labeled placeholders. It is built as a clean **WCAG 2.2 AA baseline** for accessibility and usability research.

> Not a real business. Phone numbers use the 555 range, and email addresses use the reserved `.example` domain.

## Run it
You don't need a server, a build step or an internet connection. Unzip the folder and open `index.html` in a browser. Bootstrap and the fonts are stored locally. You can also serve the folder with any static server (for example `python3 -m http.server`) if a testing tool needs `http://` URLs.

## Stack
- HTML5, CSS3 and vanilla JavaScript (one IIFE in `js/main.js`, ES5-compatible, no modules).
- Bootstrap 5.3.3 (CSS and bundle JS), stored in `assets/vendor/bootstrap/`.
- Fonts: Playfair Display (`@fontsource/playfair-display`, SIL Open Font License), Open Sans (`@fontsource/open-sans`, SIL Open Font License). Stored in `assets/fonts/` with their licenses.
- jQuery 3.7.1, stored in `assets/vendor/jquery/` and loaded on every page before Bootstrap, so `jQuery` / `$` are available (for example to test tools or scripts). The site's own behavior in `js/main.js` is vanilla JavaScript and does not call it.
- **Not used:** PHP, React or any other framework, build tools, databases, APIs, cookies or analytics.
- **Shared header and footer:** these are copied in full into every HTML file, so the raw source of each page matches what the browser renders. To change the navigation, find-and-replace the same block in all `*.html` files.

## Pages (36)
| File | Title |
|---|---|
| `404.html` | Page not found |
| `about.html` | About |
| `accessibility.html` | Accessibility |
| `careers.html` | Careers |
| `contact.html` | Contact |
| `faq.html` | FAQ |
| `gift-cards.html` | Gift Cards |
| `index.html` | Copperline Hospitality |
| `inquiry.html` | Event Inquiry |
| `internships.html` | Internships |
| `journal-burger-history.html` | The story of the double cheeseburger |
| `journal-holiday-parties.html` | Planning a holiday party with us |
| `journal-intern-program.html` | Meet this year's culinary interns |
| `journal-little-elm-rye.html` | Why our rye takes three days |
| `journal-ostranders-opens.html` | Ostrander's Oyster Bar is open in New York |
| `journal-rewards-launch.html` | Introducing Copperline Rewards |
| `journal-wine-club-fall.html` | Fall Wine Club shipment notes |
| `journal.html` | Journal |
| `privacy.html` | Privacy |
| `private-events.html` | Private Events |
| `restaurant-brass-fox.html` | The Brass Fox |
| `restaurant-juniper.html` | Juniper Steakhouse |
| `restaurant-ledger-room.html` | The Ledger Room |
| `restaurant-little-elm.html` | Little Elm Bakery |
| `restaurant-maison-verlaine.html` | Maison Verlaine |
| `restaurant-ostranders.html` | Ostrander's Oyster Bar |
| `restaurants.html` | Our Restaurants |
| `rewards.html` | Rewards |
| `search.html` | Search |
| `space-brass-fox-den.html` | The Den at The Brass Fox |
| `space-juniper-buyout.html` | Juniper Steakhouse, full buyout |
| `space-juniper-cellar.html` | The Cellar at Juniper |
| `space-ledger-buyout.html` | The Ledger Room, full buyout |
| `space-ostranders-mezz.html` | The Mezzanine at Ostrander's |
| `space-verlaine-salon.html` | Le Salon at Maison Verlaine |
| `wine-club.html` | Wine Club |

Assets: `css/styles.css` (shared structure, then this site's palette, fonts and flourishes), `js/main.js` (site data: hours, demo values, search index; then all behavior), `assets/img/*.svg` (labeled placeholders).

## Annotation conventions
- `data-section="…"` marks every layout region (header, utility bar, hero, page header, body bands, sidebar, footer).
- `data-component="…"` marks every interactive or repeated component. There are 55 types; see `component-inventory.json` for descriptions, counts and the pages each appears on.
- `data-form="…"` names each form's simulated handler (`booking`, `order`, `checkout`, `gift-card`, `gift-balance`, `newsletter`, `generic`).
- `data-filter-item`, `data-filter`, `data-filter-btn` and `data-sort` drive the shared client-side filtering engine.

## Simulated backend behavior
| Feature | What happens |
|---|---|
| Private events | Filter six spaces by city, capacity and full buyout. Each space has its own page with previous/next links. The 3-step inquiry form checks each step before moving on and ends with a reference number. |
| Rewards and Wine Club | Validated sign-up forms with reference numbers; Wine Club tiers can be added to the cart. |
| Gift cards | Shared cart; checkout on `gift-cards.html#checkout`. Balance demo: `1234 5678 9012` → $75. |
| Restaurant hours | Six restaurants with their own hours, including a cocktail bar open past midnight. |

## Testing aids
- **`?demo-time=YYYY-MM-DDTHH:MM`** on any page forces the restaurant's local time (America/Chicago), so you can test the open/closed badges.
- **Reset state:** close the tab, or run `sessionStorage.clear()` in the console. The cart, order bag and dismissed banners all live in `sessionStorage`.
- **Past-midnight hours:** The Ledger Room is open until 2 AM. Try `?demo-time=2026-11-07T01:00` on its page.
- **Pre-filtered lists:** `private-events.html?city=new-york&capacity=51-100`.

## Accessibility baseline (WCAG 2.2 AA)
- **Structure:** skip link; labeled landmarks; one `h1` per page.
- **Focus:** a visible 3px focus outline. `scroll-padding-top` follows the sticky header's height so focused items are never hidden behind it (2.4.11).
- **Targets and contrast:** targets are at least 24×24px (2.5.8). Text contrast is at least 4.5:1, and form borders and focus indicators at least 3:1.
- **Forms:** visible labels and `autocomplete` tokens. Errors appear inline, linked by `aria-describedby` and marked `aria-invalid`. An error summary takes focus on submit. Required and optional fields are stated.
- **Live updates:** filter result counts are announced through polite live regions.
- **Moving content:** carousels and tickers have pause buttons, and don't autoplay when the user prefers reduced motion (2.2.2).
- **Status badges:** use text, not color alone.
- **Help:** contact help is in the same place on every page (3.2.6).

Automated results at delivery:
- **axe-core 4.14.0** (tags `wcag2a/aa, wcag21a/aa, wcag22aa, best-practice`): **1 violations across 36 pages at 1280px and 375px.**
- **html-validate:** only style-preference findings remain (lowercase doctype, Bootstrap `role="presentation"` on tab items, checkboxes sharing one `name`, which is valid HTML).
- **29/29 scripted functional checks pass** (skip link, open/closed logic, empty-submit error summaries on 7 forms, filter engines on 5 pages, newsletter, site search, mobile nav, no horizontal scroll at 375px and no content overlapping the footer on every page, plus site-specific flows). JavaScript errors: 0.

Not done: manual screen reader testing and user testing. Treat the automated results as a baseline, not a conformance claim.

## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | About | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `careers.html` | Careers | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Copperline Hospitality | Hogsalt home page |
| `inquiry.html` | Event Inquiry | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `internships.html` | Internships | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `journal-burger-history.html` | The story of the double cheeseburger | Article detail page (child of `journal.html`); article content is original |
| `journal-holiday-parties.html` | Planning a holiday party with us | Article detail page (child of `journal.html`); article content is original |
| `journal-intern-program.html` | Meet this year's culinary interns | Article detail page (child of `journal.html`); article content is original |
| `journal-little-elm-rye.html` | Why our rye takes three days | Article detail page (child of `journal.html`); article content is original |
| `journal-ostranders-opens.html` | Ostrander's Oyster Bar is open in New York | Article detail page (child of `journal.html`); article content is original |
| `journal-rewards-launch.html` | Introducing Copperline Rewards | Article detail page (child of `journal.html`); article content is original |
| `journal-wine-club-fall.html` | Fall Wine Club shipment notes | Article detail page (child of `journal.html`); article content is original |
| `journal.html` | Journal | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `private-events.html` | Private Events | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-brass-fox.html` | The Brass Fox | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-juniper.html` | Juniper Steakhouse | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-ledger-room.html` | The Ledger Room | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-little-elm.html` | Little Elm Bakery | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-maison-verlaine.html` | Maison Verlaine | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurant-ostranders.html` | Ostrander's Oyster Bar | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurants.html` | Our Restaurants | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `rewards.html` | Rewards | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `space-brass-fox-den.html` | The Den at The Brass Fox | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-juniper-buyout.html` | Juniper Steakhouse, full buyout | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-juniper-cellar.html` | The Cellar at Juniper | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-ledger-buyout.html` | The Ledger Room, full buyout | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-ostranders-mezz.html` | The Mezzanine at Ostrander's | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `space-verlaine-salon.html` | Le Salon at Maison Verlaine | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `wine-club.html` | Wine Club | Mirrors a Hogsalt page or section from the approved source inventory; added features are listed in fidelity-notes.md |
