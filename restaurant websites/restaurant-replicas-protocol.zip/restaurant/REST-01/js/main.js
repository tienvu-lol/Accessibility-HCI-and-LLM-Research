/* Vicolo Verde (REST-01): site data first, then all behavior. Vanilla JS; Bootstrap's bundle (assets/vendor/bootstrap/) is loaded before this file. */
/* ===== from data.js ===== */
/* Vicolo Verde site data (generated, fictional). Read by main.js. */
window.VV_DATA = {
 "timeZone": "America/New_York",
 "hours": {
  "vicolo": {
   "label": "Vicolo Verde",
   "days": {
    "0": [
     [
      540,
      1380
     ]
    ],
    "1": [
     [
      600,
      1380
     ]
    ],
    "2": [
     [
      600,
      1380
     ]
    ],
    "3": [
     [
      600,
      1380
     ]
    ],
    "4": [
     [
      600,
      1380
     ]
    ],
    "5": [
     [
      600,
      1440
     ]
    ],
    "6": [
     [
      540,
      1440
     ]
    ]
   }
  },
  "larkin": {
   "label": "The Larkin Inn",
   "days": {
    "0": [
     [
      660,
      1320
     ]
    ],
    "1": [],
    "2": [
     [
      1020,
      1380
     ]
    ],
    "3": [
     [
      1020,
      1380
     ]
    ],
    "4": [
     [
      1020,
      1380
     ]
    ],
    "5": [
     [
      1020,
      1440
     ]
    ],
    "6": [
     [
      660,
      1440
     ]
    ]
   }
  },
  "pettirosso": {
   "label": "Bar Pettirosso",
   "days": {
    "0": [
     [
      960,
      1440
     ]
    ],
    "1": [
     [
      960,
      1500
     ]
    ],
    "2": [
     [
      960,
      1500
     ]
    ],
    "3": [
     [
      960,
      1500
     ]
    ],
    "4": [
     [
      960,
      1560
     ]
    ],
    "5": [
     [
      960,
      1560
     ]
    ],
    "6": [
     [
      960,
      1560
     ]
    ]
   }
  },
  "odile": {
   "label": "Café Odile",
   "days": {
    "0": [
     [
      450,
      960
     ]
    ],
    "1": [
     [
      450,
      960
     ]
    ],
    "2": [
     [
      450,
      960
     ]
    ],
    "3": [
     [
      450,
      960
     ]
    ],
    "4": [
     [
      450,
      960
     ]
    ],
    "5": [
     [
      450,
      960
     ]
    ],
    "6": [
     [
      450,
      960
     ]
    ]
   }
  },
  "sorelle": {
   "label": "Sorelle",
   "days": {
    "0": [
     [
      1020,
      1320
     ]
    ],
    "1": [],
    "2": [],
    "3": [
     [
      1050,
      1380
     ]
    ],
    "4": [
     [
      1050,
      1380
     ]
    ],
    "5": [
     [
      1050,
      1410
     ]
    ],
    "6": [
     [
      1050,
      1410
     ]
    ]
   }
  }
 },
 "taxRate": 0.08875,
 "demoGiftCards": {
  "VV12345678": 75.0,
  "VV00001111": 0,
  "VV24682468": 150.0
 },
 "searchIndex": [
  {
   "t": "Home",
   "u": "index.html",
   "x": "Neighborhood trattoria on Bedford Row with hand-cut pasta and walk-ins welcome.",
   "k": "Page"
  },
  {
   "t": "Menu",
   "u": "menu.html",
   "x": "Lunch, dinner, brunch, desserts and drinks with dietary filters.",
   "k": "Page"
  },
  {
   "t": "Craft Cocktails",
   "u": "cocktails.html",
   "x": "Aperitivo cocktails and zero-proof drinks.",
   "k": "Page"
  },
  {
   "t": "Bea & Lorenzo (Our Story)",
   "u": "about.html",
   "x": "Our founders, milestones and team.",
   "k": "Page"
  },
  {
   "t": "Gatherings",
   "u": "gatherings.html",
   "x": "Private dining, event packages and catering inquiries.",
   "k": "Page"
  },
  {
   "t": "Reservations",
   "u": "reservations.html",
   "x": "Book a table for one to eight guests.",
   "k": "Page"
  },
  {
   "t": "Take Out",
   "u": "takeout.html",
   "x": "Order dishes for pickup.",
   "k": "Page"
  },
  {
   "t": "Shop",
   "u": "shop.html",
   "x": "Olive oil, pasta, cookbook and goods.",
   "k": "Page"
  },
  {
   "t": "Gift Cards",
   "u": "gift-cards.html",
   "x": "Buy an eGift card or check a balance.",
   "k": "Page"
  },
  {
   "t": "Press",
   "u": "press.html",
   "x": "Press coverage and press kit.",
   "k": "Page"
  },
  {
   "t": "Community",
   "u": "community.html",
   "x": "Stories from our kitchen and neighbors.",
   "k": "Page"
  },
  {
   "t": "Careers",
   "u": "careers.html",
   "x": "Open jobs in the kitchen and dining room.",
   "k": "Page"
  },
  {
   "t": "Contact & Directions",
   "u": "contact.html",
   "x": "Address, hours, directions and contact form.",
   "k": "Page"
  },
  {
   "t": "FAQ",
   "u": "faq.html",
   "x": "Answers about reservations, dietary needs, events and accessibility.",
   "k": "Page"
  },
  {
   "t": "Accessibility statement",
   "u": "accessibility.html",
   "x": "WCAG 2.2 AA conformance target and feedback contact.",
   "k": "Page"
  },
  {
   "t": "Privacy policy",
   "u": "privacy.html",
   "x": "How this demonstration site handles information.",
   "k": "Page"
  },
  {
   "t": "Carciofi fritti",
   "u": "menu.html#item-carciofi",
   "x": "Crisp baby artichokes, lemon, flaky salt. Antipasti, $16.",
   "k": "Dish"
  },
  {
   "t": "Burrata",
   "u": "menu.html#item-burrata",
   "x": "Roasted grapes, saba, grilled country bread. Antipasti, $19.",
   "k": "Dish"
  },
  {
   "t": "Insalata verde",
   "u": "menu.html#item-insalata-verde",
   "x": "Tender lettuces, shallot and white wine vinaigrette. Antipasti, $14.",
   "k": "Dish"
  },
  {
   "t": "Polpette di ricotta",
   "u": "menu.html#item-polpette-ricotta",
   "x": "Ricotta dumplings, slow tomato, basil. Antipasti, $17.",
   "k": "Dish"
  },
  {
   "t": "Crudo di ricciola",
   "u": "menu.html#item-crudo",
   "x": "Amberjack, blood orange, Calabrian chili. Antipasti, $22.",
   "k": "Dish"
  },
  {
   "t": "Panzanella invernale",
   "u": "menu.html#item-panzanella",
   "x": "Roasted squash, torn bread, pickled red onion. Antipasti, $16.",
   "k": "Dish"
  },
  {
   "t": "Cavolo nero",
   "u": "menu.html#item-cavolo-nero",
   "x": "Braised with pine nuts and golden raisins. Verdure, $13.",
   "k": "Dish"
  },
  {
   "t": "Patate al forno",
   "u": "menu.html#item-patate",
   "x": "Rosemary roasted potatoes, garlic. Verdure, $11.",
   "k": "Dish"
  },
  {
   "t": "Funghi trifolati",
   "u": "menu.html#item-funghi",
   "x": "Wild mushrooms, parsley, garlic, olive oil. Verdure, $14.",
   "k": "Dish"
  },
  {
   "t": "Fagiolini",
   "u": "menu.html#item-fagiolini",
   "x": "Green beans, toasted almond salsa. Verdure, $12.",
   "k": "Dish"
  },
  {
   "t": "Tonnarelli cacio e pepe",
   "u": "menu.html#item-cacio-e-pepe",
   "x": "Hand-cut tonnarelli, pecorino, cracked black pepper. Pasta, $24.",
   "k": "Dish"
  },
  {
   "t": "Pappardelle al ragù",
   "u": "menu.html#item-pappardelle",
   "x": "Slow-braised beef and pork, parmigiano. Pasta, $28.",
   "k": "Dish"
  },
  {
   "t": "Tagliatelle ai funghi",
   "u": "menu.html#item-tagliatelle-funghi",
   "x": "Mushrooms, thyme, butter, lemon zest. Pasta, $26.",
   "k": "Dish"
  },
  {
   "t": "Gnocchi al pomodoro",
   "u": "menu.html#item-gnocchi",
   "x": "Potato gnocchi, san marzano tomato, basil. Pasta, $23.",
   "k": "Dish"
  },
  {
   "t": "Spaghetti alle vongole",
   "u": "menu.html#item-vongole",
   "x": "Littleneck clams, white wine, chili, parsley. Pasta, $29.",
   "k": "Dish"
  },
  {
   "t": "Ravioli di zucca",
   "u": "menu.html#item-ravioli-zucca",
   "x": "Squash filling, brown butter, sage, crushed amaretti. Pasta, $26.",
   "k": "Dish"
  },
  {
   "t": "Pollo al mattone",
   "u": "menu.html#item-pollo",
   "x": "Brick-pressed half chicken, salsa verde. Secondi, $34.",
   "k": "Dish"
  },
  {
   "t": "Branzino arrosto",
   "u": "menu.html#item-branzino",
   "x": "Whole roasted branzino, fennel, Castelvetrano olives. Secondi, $38.",
   "k": "Dish"
  },
  {
   "t": "Bistecca",
   "u": "menu.html#item-bistecca",
   "x": "16 oz strip steak, arugula, parmigiano, lemon. Secondi, $52.",
   "k": "Dish"
  },
  {
   "t": "Melanzane alla parmigiana",
   "u": "menu.html#item-parmigiana",
   "x": "Layered eggplant, tomato, mozzarella, basil. Secondi, $27.",
   "k": "Dish"
  },
  {
   "t": "Uova in purgatorio",
   "u": "menu.html#item-uova-purgatorio",
   "x": "Eggs baked in spicy tomato, grilled bread. Brunch, $18.",
   "k": "Dish"
  },
  {
   "t": "Frittata del giorno",
   "u": "menu.html#item-frittata",
   "x": "Daily frittata, little green salad. Brunch, $17.",
   "k": "Dish"
  },
  {
   "t": "Ricotta pancakes",
   "u": "menu.html#item-pancakes",
   "x": "Lemon curd, wildflower honey. Brunch, $16.",
   "k": "Dish"
  },
  {
   "t": "Bruschetta con uovo",
   "u": "menu.html#item-bruschetta-uovo",
   "x": "Soft egg, bitter greens, pecorino. Brunch, $15.",
   "k": "Dish"
  },
  {
   "t": "Panino di porchetta",
   "u": "menu.html#item-porchetta",
   "x": "Roast pork, salsa verde, ciabatta. Brunch, $19.",
   "k": "Dish"
  },
  {
   "t": "Yogurt e granola",
   "u": "menu.html#item-yogurt",
   "x": "Sheep's milk yogurt, honey granola, figs. Brunch, $12.",
   "k": "Dish"
  },
  {
   "t": "Tiramisù",
   "u": "menu.html#item-tiramisu",
   "x": "Espresso-soaked savoiardi, mascarpone, cocoa. Dolci, $13.",
   "k": "Dish"
  },
  {
   "t": "Torta all'olio d'oliva",
   "u": "menu.html#item-torta-olio",
   "x": "Olive oil cake, candied citrus. Dolci, $12.",
   "k": "Dish"
  },
  {
   "t": "Panna cotta",
   "u": "menu.html#item-panna-cotta",
   "x": "Vanilla bean, seasonal fruit. Dolci, $12.",
   "k": "Dish"
  },
  {
   "t": "Affogato",
   "u": "menu.html#item-affogato",
   "x": "Fior di latte gelato, hot espresso. Dolci, $10.",
   "k": "Dish"
  },
  {
   "t": "Sorbetto",
   "u": "menu.html#item-sorbetto",
   "x": "Two scoops of today's sorbet. Dolci, $9.",
   "k": "Dish"
  },
  {
   "t": "Espresso",
   "u": "menu.html#item-espresso",
   "x": "Single origin, pulled short. Caffè & Soft Drinks, $4.",
   "k": "Dish"
  },
  {
   "t": "Cappuccino",
   "u": "menu.html#item-cappuccino",
   "x": "Oat milk available at no charge. Caffè & Soft Drinks, $5.50.",
   "k": "Dish"
  },
  {
   "t": "Aranciata rossa",
   "u": "menu.html#item-aranciata",
   "x": "House blood-orange soda. Caffè & Soft Drinks, $7.",
   "k": "Dish"
  },
  {
   "t": "Vino rosso della casa",
   "u": "menu.html#item-rosso",
   "x": "Glass of our house Montepulciano. Vino, $15.",
   "k": "Dish"
  },
  {
   "t": "Vino bianco della casa",
   "u": "menu.html#item-bianco",
   "x": "Glass of our house Verdicchio. Vino, $15.",
   "k": "Dish"
  },
  {
   "t": "Negroni Verde",
   "u": "cocktails.html",
   "x": "Gin, bianco vermouth, gentian, lemon oil. $17.",
   "k": "Cocktail"
  },
  {
   "t": "Spritz al Rabarbaro",
   "u": "cocktails.html",
   "x": "Rhubarb amaro, prosecco, soda. $15.",
   "k": "Cocktail"
  },
  {
   "t": "Bicicletta",
   "u": "cocktails.html",
   "x": "Dry white wine, bitter aperitivo, soda. $14.",
   "k": "Cocktail"
  },
  {
   "t": "Americano",
   "u": "cocktails.html",
   "x": "Sweet vermouth, bitter aperitivo, soda. $15.",
   "k": "Cocktail"
  },
  {
   "t": "Fico Old Fashioned",
   "u": "cocktails.html",
   "x": "Fig-infused rye, demerara, orange bitters. $18.",
   "k": "Cocktail"
  },
  {
   "t": "Limoncello Sour",
   "u": "cocktails.html",
   "x": "House limoncello, lemon, egg white. $16.",
   "k": "Cocktail"
  },
  {
   "t": "Rosmarino Fizz",
   "u": "cocktails.html",
   "x": "Rosemary, grapefruit, tonic (zero-proof). $9.",
   "k": "Cocktail"
  },
  {
   "t": "Chinotto & Tonic",
   "u": "cocktails.html",
   "x": "Bittersweet chinotto, tonic, orange (zero-proof). $8.",
   "k": "Cocktail"
  },
  {
   "t": "Ten years on Bedford Row",
   "u": "community-ten-years-on-bedford-row.html",
   "x": "A decade ago we opened with nine tables and a borrowed espresso machine. Here is what we learned.",
   "k": "Story"
  },
  {
   "t": "Olive harvest notes from Umbria",
   "u": "community-olive-harvest-notes.html",
   "x": "Our oil comes from one family grove. This year's harvest arrived two weeks early.",
   "k": "Story"
  },
  {
   "t": "Winter hours and holiday closures",
   "u": "community-winter-hours-holiday-closures.html",
   "x": "Our holiday schedule, plus how to book the back room for December gatherings.",
   "k": "Story"
  },
  {
   "t": "A short guide to aperitivo hour",
   "u": "community-guide-to-aperitivo.html",
   "x": "Bitter, bubbly and low in alcohol: how to order a drink before dinner like a regular.",
   "k": "Story"
  },
  {
   "t": "How we make tonnarelli by hand",
   "u": "community-how-we-make-tonnarelli.html",
   "x": "Eggs, flour and a wooden guitar: the morning routine behind our most ordered pasta.",
   "k": "Story"
  },
  {
   "t": "Cooking with the Bedford Row Food Pantry",
   "u": "community-bedford-row-food-pantry.html",
   "x": "Every Monday our kitchen team cooks two hundred meals for neighbors in need.",
   "k": "Story"
  },
  {
   "t": "The first ramps of spring",
   "u": "community-first-ramps-of-spring.html",
   "x": "Wild ramps are here for about three weeks. Here is where to find them on our menu.",
   "k": "Story"
  },
  {
   "t": "Meet our farmers: Two Brooks Farm",
   "u": "community-meet-two-brooks-farm.html",
   "x": "The Hudson Valley farm that grows most of our lettuces, herbs and summer squash.",
   "k": "Story"
  },
  {
   "t": "Do you take reservations?",
   "u": "faq.html#faq-reservations",
   "x": "Yes. We hold a limited number of reservations each day for parties of one to eight, and we keep most of the dining room for walk-ins. Book up to 30 days ahead on our Reservations page.",
   "k": "FAQ"
  },
  {
   "t": "How does the walk-in list work?",
   "u": "faq.html#faq-reservations",
   "x": "Visit the host stand and leave a mobile number. We will text you when your table is ready. Waits are shortest before 6:00 PM and after 9:30 PM.",
   "k": "FAQ"
  },
  {
   "t": "Can I book for a large group?",
   "u": "faq.html#faq-reservations",
   "x": "Parties of nine or more should send an inquiry through our Gatherings page so our events team can plan the room for you.",
   "k": "FAQ"
  },
  {
   "t": "Do you have gluten-free pasta?",
   "u": "faq.html#faq-dietary",
   "x": "Yes. Any pasta can be made with gluten-free pasta for $3. It is cooked in a separate pot, but our kitchen does handle wheat flour.",
   "k": "FAQ"
  },
  {
   "t": "Is the menu labeled for allergies?",
   "u": "faq.html#faq-dietary",
   "x": "Our online menu marks vegetarian, vegan, gluten-free and nut-containing dishes. Please tell your server about any allergy so the kitchen can help.",
   "k": "FAQ"
  },
  {
   "t": "What spaces can I book?",
   "u": "faq.html#faq-events",
   "x": "You can book the Back Room (up to 24 seated), the Courtyard (up to 30 seated or 40 standing) or the full restaurant (up to 70 seated).",
   "k": "FAQ"
  },
  {
   "t": "How far ahead should I plan?",
   "u": "faq.html#faq-events",
   "x": "We recommend at least three weeks for weekday events and six weeks for weekends and December.",
   "k": "FAQ"
  },
  {
   "t": "Do you offer take out?",
   "u": "faq.html#faq-takeout",
   "x": "Yes. Order on our Take Out page and pick up at the host stand. We do not currently offer delivery.",
   "k": "FAQ"
  },
  {
   "t": "How long does a pickup order take?",
   "u": "faq.html#faq-takeout",
   "x": "Most orders are ready in 20 to 30 minutes. You can also schedule a pickup time later in the day.",
   "k": "FAQ"
  },
  {
   "t": "Do gift cards expire?",
   "u": "faq.html#faq-shop",
   "x": "No. Our gift cards never expire and can be used for dining, take out and the shop.",
   "k": "FAQ"
  },
  {
   "t": "How do I check my gift card balance?",
   "u": "faq.html#faq-shop",
   "x": "Use the balance checker on our Gift Cards page. You will need the code printed on your card or in your email.",
   "k": "FAQ"
  },
  {
   "t": "Is the restaurant wheelchair accessible?",
   "u": "faq.html#faq-access",
   "x": "Our dining room and courtyard have step-free entry from Bedford Row, and we have an accessible restroom. The Back Room has two steps; a portable ramp is available on request.",
   "k": "FAQ"
  },
  {
   "t": "Do you have large-print menus?",
   "u": "faq.html#faq-access",
   "x": "Yes. Large-print and high-contrast printed menus are available at the host stand, and this website's menu works with screen readers and text zoom.",
   "k": "FAQ"
  },
  {
   "t": "Vicolo Extra-Virgin Olive Oil",
   "u": "shop.html",
   "x": "500 ml tin of early-harvest Umbrian oil we cook with every day. $28.",
   "k": "Product"
  },
  {
   "t": "Bronze-Cut Tonnarelli, 2 Pack",
   "u": "shop.html",
   "x": "The same square-edged noodle as our cacio e pepe. $14.",
   "k": "Product"
  },
  {
   "t": "Calabrian Chili Crisp",
   "u": "shop.html",
   "x": "Crunchy, smoky and only a little dangerous. $12.",
   "k": "Product"
  },
  {
   "t": "Vicolo Verde: Recipes from the Lane",
   "u": "shop.html",
   "x": "Our 240-page cookbook with 90 recipes. $35.",
   "k": "Product"
  },
  {
   "t": "Canvas Market Tote",
   "u": "shop.html",
   "x": "Heavy cotton tote with our lane-and-ivy print. $24.",
   "k": "Product"
  },
  {
   "t": "Linen Kitchen Apron",
   "u": "shop.html",
   "x": "Stonewashed linen with an adjustable neck strap. $48.",
   "k": "Product"
  },
  {
   "t": "Hand-Dipped Taper Candles",
   "u": "shop.html",
   "x": "Set of four beeswax tapers, like the ones on our tables. $22.",
   "k": "Product"
  }
 ]
};
;
/* ===== from main.js ===== */
/* =====================================================================
   Vicolo Verde — front-end behavior (vanilla JavaScript + Bootstrap 5)
   Fictional research replica. No backend: every "submission" is simulated
   in memory (cart and take-out bag also use sessionStorage when available).
   Components are initialised by their data-component / data-* hooks.
   ===================================================================== */
(function () {
  'use strict';

  var D = window.VV_DATA || {};
  var BS = window.bootstrap;
  function $(s, c) { return (c || document).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (ch) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]; }); }
  function money(n) { return '$' + Number(n).toFixed(2); }
  function randCode(prefix) { var c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', s = ''; for (var i = 0; i < 5; i++) s += c[Math.floor(Math.random() * c.length)]; return prefix + s; }

  /* ---------- live announcements & toasts ---------- */
  function announce(msg) {
    var r = $('#sr-status'); if (!r) return;
    r.textContent = '';
    window.setTimeout(function () { r.textContent = msg; }, 60);
  }
  function toast(msg) {
    var t = $('#site-toast');
    if (!t || !BS) { announce(msg); return; }
    $('[data-toast-body]', t).textContent = msg;
    BS.Toast.getOrCreateInstance(t, { delay: 4000 }).show();
  }

  /* ---------- storage: sessionStorage with in-memory fallback ---------- */
  var Store = (function () {
    var mem = {}, ss = null;
    try { ss = window.sessionStorage; ss.setItem('__vv', '1'); ss.removeItem('__vv'); } catch (e) { ss = null; }
    return {
      get: function (k, def) {
        try { if (ss) { var v = ss.getItem(k); return v ? JSON.parse(v) : def; } } catch (e) { /* fall through */ }
        return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : def;
      },
      set: function (k, v) { mem[k] = v; try { if (ss) ss.setItem(k, JSON.stringify(v)); } catch (e) { /* memory only */ } }
    };
  })();

  /* ---------- time in the restaurant's time zone ---------- */
  var DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  function nowParts() {
    // ?demo-time=2026-11-07T23:30 forces a local restaurant time (for testing open/closed states).
    var p = new URLSearchParams(location.search).get('demo-time');
    var m = p && p.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
    if (m) {
      var dt = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
      return { day: dt.getUTCDay(), min: (+m[4]) * 60 + (+m[5]), y: +m[1], mo: +m[2], d: +m[3] };
    }
    try {
      var parts = new Intl.DateTimeFormat('en-US', { timeZone: D.timeZone || 'America/New_York', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date());
      var g = function (t) { for (var i = 0; i < parts.length; i++) if (parts[i].type === t) return parts[i].value; return ''; };
      var days = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
      return { day: days[g('weekday')], min: (+g('hour') % 24) * 60 + (+g('minute')), y: +g('year'), mo: +g('month'), d: +g('day') };
    } catch (e) {
      var n = new Date();
      return { day: n.getDay(), min: n.getHours() * 60 + n.getMinutes(), y: n.getFullYear(), mo: n.getMonth() + 1, d: n.getDate() };
    }
  }
  function isoFromToday(offsetDays) {
    var n = nowParts();
    return new Date(Date.UTC(n.y, n.mo - 1, n.d + (offsetDays || 0))).toISOString().slice(0, 10);
  }
  function fmtMin(m) {
    if (m === 1440) return 'midnight';
    m = ((m % 1440) + 1440) % 1440;
    var h = Math.floor(m / 60), mm = m % 60, ap = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return h + (mm ? ':' + String(mm).padStart(2, '0') : '') + ' ' + ap;
  }
  function fmtDate(iso) {
    var p = iso.split('-');
    var d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2]));
    return d.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'UTC' });
  }

  /* ---------- open / closed status ---------- */
  function locStatus(key, np) {
    var loc = D.hours && D.hours[key]; if (!loc) return null;
    var days = loc.days, day = np.day, min = np.min, i, r;
    var yest = days[String((day + 6) % 7)] || [];
    for (i = 0; i < yest.length; i++) { r = yest[i]; if (r[1] > 1440 && min < r[1] - 1440) return { open: true, closes: r[1] - 1440 }; }
    var today = days[String(day)] || [];
    for (i = 0; i < today.length; i++) { r = today[i]; if (min >= r[0] && min < r[1]) return { open: true, closes: r[1], left: r[1] - min }; }
    for (var k = 0; k < 8; k++) {
      var list = days[String((day + k) % 7)] || [];
      for (i = 0; i < list.length; i++) {
        if (k === 0 && list[i][0] <= min) continue;
        return { open: false, inDays: k, opens: list[i][0], dayIndex: (day + k) % 7 };
      }
    }
    return { open: false };
  }
  function statusText(s) {
    if (!s) return '';
    if (s.open) {
      var until = fmtMin(s.closes); // fmtMin wraps past-midnight values and returns "midnight" for 1440
      return (s.left !== undefined && s.left <= 60 ? 'Closing soon, open until ' : 'Open now until ') + until;
    }
    if (s.opens === undefined) return 'Closed';
    var when = s.inDays === 0 ? 'today' : s.inDays === 1 ? 'tomorrow' : DAY_NAMES[s.dayIndex];
    return 'Closed now, opens ' + when + ' at ' + fmtMin(s.opens);
  }
  function initOpenStatus() {
    var np = nowParts();
    $$('[data-component="open-status"]').forEach(function (el) {
      var s = locStatus(el.getAttribute('data-location'), np); if (!s) return;
      el.classList.remove('is-open', 'is-soon', 'is-closed');
      el.classList.add(s.open ? (s.left !== undefined && s.left <= 60 ? 'is-soon' : 'is-open') : 'is-closed');
      el.textContent = statusText(s);
    });
    $$('[data-component="hours-week"]').forEach(function (ul) {
      var loc = D.hours && D.hours[ul.getAttribute('data-location')]; if (!loc) return;
      var order = [1, 2, 3, 4, 5, 6, 0], html = '';
      order.forEach(function (d) {
        var ranges = loc.days[String(d)] || [];
        var txt = ranges.length ? ranges.map(function (r) { return fmtMin(r[0]) + ' – ' + (r[1] >= 1440 ? (r[1] === 1440 ? 'midnight' : fmtMin(r[1] - 1440)) : fmtMin(r[1])); }).join(', ') : 'Closed';
        var today = d === np.day;
        html += '<li class="' + (today ? 'is-today' : '') + '"><span>' + DAY_NAMES[d] + (today ? ' (today)' : '') + '</span><span>' + txt + '</span></li>';
      });
      ul.innerHTML = html;
    });
  }

  /* ---------- sticky header (only the primary nav row sticks on desktop) ---------- */
  function initStickyHeader() {
    var h = $('.site-header'); if (!h) return;
    var util = $('.utility-bar', h), logo = $('.logo-bar', h);
    var lg = window.matchMedia('(min-width: 992px)');
    function update() {
      var hide = util.offsetHeight + (lg.matches ? logo.offsetHeight : 0);
      h.style.top = (-hide) + 'px';
      document.documentElement.style.setProperty('--sticky-h', Math.max(0, h.offsetHeight - hide) + 'px');
    }
    update();
    window.addEventListener('resize', update);
    var panel = $('#site-search-panel');
    if (panel) {
      ['shown.bs.collapse', 'hidden.bs.collapse'].forEach(function (ev) { panel.addEventListener(ev, update); });
      panel.addEventListener('shown.bs.collapse', function () { var i = $('input', panel); if (i) i.focus(); });
      panel.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { BS.Collapse.getOrCreateInstance(panel).hide(); var t = $('[data-component="search-toggle"]'); if (t) t.focus(); }
      });
    }
    var onScroll = function () { h.classList.toggle('is-scrolled', window.scrollY > 40); };
    window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
  }

  /* ---------- back to top ---------- */
  function initBackToTop() {
    var b = $('[data-component="back-to-top"]'); if (!b) return;
    window.addEventListener('scroll', function () { b.hidden = window.scrollY < 700; }, { passive: true });
    b.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
      var brand = $('.site-header .brand'); if (brand) brand.focus({ preventScroll: true });
    });
  }

  /* ---------- in-page anchor nav highlight ---------- */
  function initAnchorNav() {
    var nav = $('[data-component="anchor-nav"]'); if (!nav || !('IntersectionObserver' in window)) return;
    var links = $$('a[href^="#"]', nav);
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        links.forEach(function (a) {
          var on = a.getAttribute('href') === '#' + en.target.id;
          a.classList.toggle('active', on);
          if (on) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    links.forEach(function (a) { var t = $(a.getAttribute('href')); if (t) io.observe(t); });
  }

  /* ---------- carousel with pause / play (WCAG 2.2.2) ---------- */
  function initCarousels() {
    if (!BS) return;
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    $$('[data-component="carousel"]').forEach(function (el) {
      var c = BS.Carousel.getOrCreateInstance(el, { interval: +el.getAttribute('data-bs-interval') || 6000, ride: false, pause: false, touch: true, keyboard: true });
      var inner = $('.carousel-inner', el);
      var btn = $('[data-carousel="#' + el.id + '"]');
      var playing = !reduce;
      function sync() {
        if (btn) btn.textContent = playing ? 'Pause slideshow' : 'Play slideshow';
        if (inner) inner.setAttribute('aria-live', playing ? 'off' : 'polite');
      }
      if (playing) c.cycle(); else c.pause();
      sync();
      if (btn) btn.addEventListener('click', function () { playing = !playing; if (playing) c.cycle(); else c.pause(); sync(); });
      el.addEventListener('focusin', function () { c.pause(); });
      el.addEventListener('mouseenter', function () { c.pause(); });
      el.addEventListener('mouseleave', function () { if (playing) c.cycle(); });
      el.addEventListener('focusout', function (e) { if (playing && !el.contains(e.relatedTarget)) c.cycle(); });
      el.addEventListener('slid.bs.carousel', function () {
        $$('.carousel-indicators button', el).forEach(function (b) {
          if (b.classList.contains('active')) b.setAttribute('aria-current', 'true'); else b.removeAttribute('aria-current');
        });
      });
    });
  }

  /* ---------- horizontal card slider ---------- */
  function initCardSliders() {
    $$('[data-slider-prev],[data-slider-next]').forEach(function (b) {
      var sel = b.getAttribute('data-slider-prev') || b.getAttribute('data-slider-next');
      var track = $(sel); if (!track) return;
      var dir = b.hasAttribute('data-slider-prev') ? -1 : 1;
      b.addEventListener('click', function () {
        var item = $('.slider-item', track);
        var step = item ? item.getBoundingClientRect().width + 24 : track.clientWidth * 0.8;
        track.scrollBy({ left: dir * step, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
      });
    });
  }

  /* ---------- generic toggle-button filter groups ---------- */
  function initButtonFilter(groupSel, attr, itemSel, noun, scope) {
    var group = $(groupSel, scope); if (!group) return;
    var buttons = $$('[data-' + attr + ']', group);
    var items = $$(itemSel, scope);
    var count = $('[data-result-count]', scope);
    function apply(val) {
      var shown = 0;
      buttons.forEach(function (b) { var on = b.getAttribute('data-' + attr) === val; b.classList.toggle('active', on); b.setAttribute('aria-pressed', String(on)); });
      items.forEach(function (it) { var ok = val === 'all' || it.getAttribute('data-' + attr) === val; it.hidden = !ok; if (ok) shown++; });
      if (count) count.textContent = 'Showing ' + shown + ' of ' + items.length + ' ' + noun + '.';
    }
    buttons.forEach(function (b) { b.addEventListener('click', function () { apply(b.getAttribute('data-' + attr)); }); });
    apply('all');
    return apply;
  }

  /* ---------- menu tabs + dietary filters + search ---------- */
  function initMenu() {
    var form = $('[data-component="menu-filter"]'); if (!form) return;
    var q = $('#menu-search', form), boxes = $$('[data-component="diet-filter"] input', form), count = $('[data-result-count]', form);
    var timer;
    function apply(quiet) {
      var term = q.value.trim().toLowerCase();
      var req = boxes.filter(function (b) { return b.checked; }).map(function (b) { return b.value; });
      $$('.tab-pane').forEach(function (p) {
        var shown = 0, items = $$('[data-component="menu-item"]', p);
        items.forEach(function (li) {
          var tags = (li.getAttribute('data-diet') || '').split(' ');
          var ok = !term || li.getAttribute('data-search').indexOf(term) > -1;
          req.forEach(function (r) { if (r === 'nutfree') { if (tags.indexOf('nuts') > -1) ok = false; } else if (tags.indexOf(r) === -1) ok = false; });
          li.hidden = !ok; if (ok) shown++;
        });
        $$('[data-component="menu-section"]', p).forEach(function (s) { s.hidden = !$$('[data-component="menu-item"]', s).some(function (li) { return !li.hidden; }); });
        var es = $('[data-empty-state]', p); if (es) es.hidden = shown > 0;
        p.setAttribute('data-shown', shown); p.setAttribute('data-total', items.length);
      });
      var ap = $('.tab-pane.active');
      if (ap && count) {
        var label = $('#' + ap.getAttribute('aria-labelledby')).textContent.trim();
        var msg = 'Showing ' + ap.getAttribute('data-shown') + ' of ' + ap.getAttribute('data-total') + ' dishes in ' + label + '.';
        clearTimeout(timer);
        timer = setTimeout(function () { count.textContent = msg; }, quiet ? 0 : 400);
      }
    }
    form.addEventListener('input', function () { apply(false); });
    form.addEventListener('submit', function (e) { e.preventDefault(); });
    $$('[data-filter-reset]').forEach(function (b) { b.addEventListener('click', function () { q.value = ''; boxes.forEach(function (x) { x.checked = false; }); apply(true); q.focus(); }); });
    $$('[data-bs-toggle="tab"]').forEach(function (t) { t.addEventListener('shown.bs.tab', function () { apply(true); }); });
    // Deep links: menu.html#tab-brunch or menu.html#item-tiramisu
    var h = location.hash;
    if (h && BS) {
      var el = null; try { el = $(h); } catch (e) { el = null; }
      var tab = null;
      if (el && el.getAttribute('role') === 'tab') tab = el;
      else if (el) { var pane = el.closest('.tab-pane'); if (pane) tab = $('[data-bs-target="#' + pane.id + '"]'); }
      if (tab) BS.Tab.getOrCreateInstance(tab).show();
      if (el && el.classList.contains('menu-item')) {
        setTimeout(function () { el.classList.add('is-highlight'); el.setAttribute('tabindex', '-1'); el.focus(); }, 250);
      }
    }
    apply(true);
  }

  /* ---------- shared cart model (shop cart + take-out bag) ---------- */
  function makeCart(key) {
    return {
      items: function () { return Store.get(key, []); },
      save: function (v) { Store.set(key, v); document.dispatchEvent(new CustomEvent('cart:change', { detail: { key: key } })); },
      add: function (it) {
        var list = this.items(), found = null;
        list.forEach(function (x) { if (x.id === it.id) found = x; });
        if (found) found.qty += it.qty || 1; else list.push({ id: it.id, name: it.name, price: +it.price, qty: it.qty || 1 });
        this.save(list);
      },
      setQty: function (id, qty) { var list = this.items().map(function (x) { if (x.id === id) x.qty = qty; return x; }).filter(function (x) { return x.qty > 0; }); this.save(list); },
      clear: function () { this.save([]); },
      subtotal: function () { return this.items().reduce(function (s, x) { return s + x.price * x.qty; }, 0); },
      count: function () { return this.items().reduce(function (s, x) { return s + x.qty; }, 0); }
    };
  }
  var Cart = makeCart('vv-cart');
  var Bag = makeCart('vv-bag');

  function lineHTML(x, prefix) {
    return '<li class="cart-line" data-component="cart-line">' +
      '<div class="cart-line-name">' + esc(x.name) + '<span class="small d-block text-body-secondary">' + money(x.price) + ' each</span></div>' +
      '<div class="qty-stepper" role="group" aria-label="Quantity of ' + esc(x.name) + '">' +
      '<button type="button" class="btn btn-sm btn-outline-primary" data-' + prefix + '-dec="' + esc(x.id) + '" aria-label="Decrease quantity of ' + esc(x.name) + '">&minus;</button>' +
      '<span class="qty-value" aria-live="off">' + x.qty + '</span>' +
      '<button type="button" class="btn btn-sm btn-outline-primary" data-' + prefix + '-inc="' + esc(x.id) + '" aria-label="Increase quantity of ' + esc(x.name) + '">+</button>' +
      '</div>' +
      '<div class="cart-line-total">' + money(x.price * x.qty) + '</div>' +
      '<button type="button" class="btn btn-link btn-sm p-0 cart-remove" data-' + prefix + '-rm="' + esc(x.id) + '">Remove<span class="visually-hidden"> ' + esc(x.name) + '</span></button>' +
      '</li>';
  }
  function bindStepper(container, model, prefix) {
    container.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var id, it;
      var find = function (i) { var r = null; model.items().forEach(function (x) { if (x.id === i) r = x; }); return r; };
      if ((id = b.getAttribute('data-' + prefix + '-inc'))) { it = find(id); model.setQty(id, it.qty + 1); announce(it.name + ', quantity ' + (it.qty + 1)); }
      else if ((id = b.getAttribute('data-' + prefix + '-dec'))) { it = find(id); model.setQty(id, it.qty - 1); announce(it.qty - 1 > 0 ? it.name + ', quantity ' + (it.qty - 1) : it.name + ' removed'); }
      else if ((id = b.getAttribute('data-' + prefix + '-rm'))) { it = find(id); model.setQty(id, 0); announce(it.name + ' removed'); }
      else return;
      var again = id && $('[data-' + prefix + '-inc="' + id + '"]', container);
      if (again && b.hasAttribute('data-' + prefix + '-inc')) again.focus();
      else if (again && b.hasAttribute('data-' + prefix + '-dec')) { var d = $('[data-' + prefix + '-dec="' + id + '"]', container); if (d) d.focus(); }
      else { var head = container.closest('[data-component]'); var focusT = head && $('h2', head); if (focusT) { focusT.setAttribute('tabindex', '-1'); focusT.focus(); } }
    });
  }

  function renderCart() {
    var items = Cart.items(), n = Cart.count(), sub = Cart.subtotal();
    $$('[data-cart-count]').forEach(function (el) { el.textContent = n; el.hidden = n === 0; });
    $$('[data-cart-label]').forEach(function (el) { el.textContent = 'Cart, ' + n + (n === 1 ? ' item' : ' items'); });
    var lines = $('[data-cart-lines]'), empty = $('[data-cart-empty]');
    if (lines) lines.innerHTML = items.map(function (x) { return lineHTML(x, 'cart'); }).join('');
    if (empty) empty.hidden = items.length > 0;
    $$('[data-cart-subtotal]').forEach(function (el) { el.textContent = money(sub); });
    var sl = $('[data-summary-lines]'), se = $('[data-summary-empty]');
    if (sl) sl.innerHTML = items.map(function (x) { return lineHTML(x, 'cart'); }).join('');
    if (se) se.hidden = items.length > 0;
    $$('[data-summary-subtotal]').forEach(function (el) { el.textContent = money(sub); });
  }
  function initCart() {
    var lines = $('[data-cart-lines]'); if (lines) bindStepper(lines, Cart, 'cart');
    var sl = $('[data-summary-lines]'); if (sl) bindStepper(sl, Cart, 'cart');
    document.addEventListener('cart:change', function (e) { if (e.detail.key === 'vv-cart') renderCart(); else renderBag(); });
    $$('[data-add-cart]').forEach(function (b) {
      b.addEventListener('click', function () {
        Cart.add({ id: b.getAttribute('data-id'), name: b.getAttribute('data-name'), price: b.getAttribute('data-price') });
        toast('Added ' + b.getAttribute('data-name') + ' to your cart.');
      });
    });
    renderCart();
  }

  /* ---------- shop: filter, sort, quick view ---------- */
  function initShop() {
    var grid = $('[data-product-grid]'); if (!grid) return;
    var cat = $('#p-cat'), sort = $('#p-sort'), count = $('[data-component="product-filter"] [data-result-count]');
    var cards = $$('[data-component="product-card-wrap"]', grid);
    function apply() {
      var shown = 0;
      var sorted = cards.slice().sort(function (a, b) {
        if (sort.value === 'price-asc') return a.getAttribute('data-price') - b.getAttribute('data-price');
        if (sort.value === 'price-desc') return b.getAttribute('data-price') - a.getAttribute('data-price');
        return a.getAttribute('data-order') - b.getAttribute('data-order');
      });
      sorted.forEach(function (c) { grid.appendChild(c); var ok = cat.value === 'all' || c.getAttribute('data-category') === cat.value; c.hidden = !ok; if (ok) shown++; });
      count.textContent = 'Showing ' + shown + ' of ' + cards.length + ' products.';
    }
    cat.addEventListener('change', apply); sort.addEventListener('change', apply); apply();
    var qv = $('#quick-view');
    if (qv) {
      var current = null;
      qv.addEventListener('show.bs.modal', function (e) {
        var t = e.relatedTarget; if (!t) return;
        current = { id: t.getAttribute('data-id'), name: t.getAttribute('data-name'), price: t.getAttribute('data-price') };
        $('#qv-title').textContent = current.name;
        $('[data-qv-desc]', qv).textContent = t.getAttribute('data-desc');
        $('[data-qv-price]', qv).textContent = money(current.price);
        var im = $('[data-qv-img]', qv); im.src = 'assets/img/' + t.getAttribute('data-img') + '.svg'; im.alt = '';
        $('#qv-qty').value = 1;
      });
      $('[data-qv-add]', qv).addEventListener('click', function () {
        var qty = Math.min(10, Math.max(1, parseInt($('#qv-qty').value, 10) || 1));
        Cart.add({ id: current.id, name: current.name, price: current.price, qty: qty });
        BS.Modal.getInstance(qv).hide();
        toast('Added ' + qty + ' × ' + current.name + ' to your cart.');
      });
    }
  }

  /* ---------- take-out bag ---------- */
  function renderBag() {
    var root = $('[data-component="order-bag"]'); if (!root) return;
    var items = Bag.items(), sub = Bag.subtotal(), tax = sub * (D.taxRate || 0);
    $('[data-bag-lines]', root).innerHTML = items.map(function (x) { return lineHTML(x, 'bag'); }).join('');
    $('[data-bag-empty]', root).hidden = items.length > 0;
    $('[data-bag-subtotal]', root).textContent = money(sub);
    $('[data-bag-tax]', root).textContent = money(tax);
    $('[data-bag-total]', root).textContent = money(sub + tax);
  }
  function pickupOptions(sel) {
    var np = nowParts(), s = locStatus('vicolo', np), opts = [];
    var loc = D.hours.vicolo, day, start, end, label;
    if (s && s.open) { day = np.day; start = Math.ceil((np.min + 20) / 15) * 15; end = s.closes - 30; label = 'Today'; }
    else if (s && s.opens !== undefined) { day = s.dayIndex; start = s.opens + 30; end = (loc.days[String(day)][0] || [0, 0])[1] - 30; label = s.inDays === 0 ? 'Today' : s.inDays === 1 ? 'Tomorrow' : DAY_NAMES[day]; }
    if (start !== undefined) {
      opts.push(['asap-' + start, (label === 'Today' && s.open ? 'As soon as possible (about 20 minutes)' : label + ', ' + fmtMin(start) + ' (first pickup)')]);
      for (var m = start + 15; m <= end && opts.length < 40; m += 15) opts.push([String(m), label + ', ' + fmtMin(m)]);
    }
    sel.innerHTML = '<option value="">Choose a pickup time</option>' + opts.map(function (o) { return '<option value="' + o[0] + '">' + esc(o[1]) + '</option>'; }).join('');
  }
  function initTakeout() {
    var root = $('[data-component="order-bag"]'); if (!root) return;
    bindStepper($('[data-bag-lines]', root), Bag, 'bag');
    $$('[data-add-order]').forEach(function (b) {
      b.addEventListener('click', function () {
        Bag.add({ id: b.getAttribute('data-id'), name: b.getAttribute('data-name'), price: b.getAttribute('data-price') });
        announce('Added ' + b.getAttribute('data-name') + '. Order total ' + money(Bag.subtotal() * (1 + (D.taxRate || 0))) + '.');
      });
    });
    var sel = $('[data-pickup-times]'); if (sel) pickupOptions(sel);
    renderBag();
  }

  /* ---------- reservations: time slots ---------- */
  function hashStr(s) { var h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }
  function initReservations() {
    var form = $('[data-form="reservation"]'); if (!form) return;
    var date = $('#r-date'), party = $('#r-party'), grid = $('[data-slot-grid]', form), hint = $('[data-slot-hint]', form), large = $('[data-large-party]', form);
    date.min = isoFromToday(0); date.max = isoFromToday(30);
    function render() {
      grid.innerHTML = '';
      large.hidden = party.value !== '9+';
      if (!date.value || !party.value || party.value === '9+' || fieldError(date)) {
        hint.textContent = party.value === '9+' ? 'Online booking is for parties of up to 8 guests.' : 'Choose a date and party size to see available times.';
        return;
      }
      var p = date.value.split('-'); var dow = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).getUTCDay();
      var start = (dow === 0 || dow === 6) ? 570 : 690, end = 1290;
      var isToday = date.value === isoFromToday(0), nowMin = nowParts().min, n = 0;
      for (var m = start; m <= end; m += 30) {
        var avail = (hashStr(date.value + ':' + m + ':' + party.value) % 10) > 2 && !(isToday && m <= nowMin + 30);
        var id = 'r-time-' + m;
        var div = document.createElement('div');
        div.className = 'slot';
        div.innerHTML = '<input class="btn-check" type="radio" name="r-time" id="' + id + '" value="' + m + '"' + (avail ? '' : ' disabled') + '>' +
          '<label class="btn btn-outline-primary slot-btn" for="' + id + '">' + fmtMin(m) + (avail ? '' : '<span class="slot-full">Full</span>') + '</label>';
        grid.appendChild(div);
        if (avail) n++;
      }
      hint.textContent = n ? n + ' times available on ' + fmtDate(date.value) + ' for ' + party.value + (party.value === '1' ? ' guest.' : ' guests.') : 'No times are available on this date. Try another date or walk in.';
      announce(hint.textContent);
    }
    date.addEventListener('change', render); party.addEventListener('change', render);
    render();
  }
  function icsFor(r) {
    var dt = r.date.replace(/-/g, '') + 'T' + String(Math.floor(r.min / 60)).padStart(2, '0') + String(r.min % 60).padStart(2, '0') + '00';
    var endMin = r.min + 120;
    var dtEnd = r.date.replace(/-/g, '') + 'T' + String(Math.floor(endMin / 60) % 24).padStart(2, '0') + String(endMin % 60).padStart(2, '0') + '00';
    return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Vicolo Verde//Demo//EN', 'BEGIN:VEVENT', 'UID:' + r.code + '@vicoloverde.example',
      'DTSTAMP:' + new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + 'Z', 'DTSTART;TZID=America/New_York:' + dt, 'DTEND;TZID=America/New_York:' + dtEnd,
      'SUMMARY:Dinner at Vicolo Verde (party of ' + r.party + ')', 'LOCATION:212 Bedford Row\\, New York\\, NY 10014', 'DESCRIPTION:Confirmation ' + r.code + ' (demo)', 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
  }

  /* ---------- gift cards ---------- */
  function initGiftCards() {
    var form = $('[data-form="gift-card"]'); if (!form) return;
    var custom = $('[data-custom-amount]', form), cInput = $('#gc-custom');
    var send = $('#gc-send'); send.min = isoFromToday(0); send.max = isoFromToday(365);
    function amount() {
      var r = $('input[name="gc-amount"]:checked', form); if (!r) return null;
      if (r.value === 'custom') return parseFloat(cInput.value) || null;
      return parseFloat(r.value);
    }
    function preview() {
      var a = amount();
      $('[data-preview-amount]').textContent = a ? money(a).replace('.00', '') : '$—';
      $('[data-preview-to]').textContent = $('#gc-to-name').value.trim() || 'your recipient';
      $('[data-preview-from]').textContent = $('#gc-from').value.trim() || 'you';
      $('[data-preview-msg]').textContent = $('#gc-message').value.trim();
    }
    $$('input[name="gc-amount"]', form).forEach(function (r) {
      r.addEventListener('change', function () {
        var isC = r.value === 'custom' && r.checked;
        custom.hidden = !isC; cInput.required = isC;
        if (isC) cInput.focus();
        preview();
      });
    });
    form.addEventListener('input', preview);
    var first = $('input[name="gc-amount"]', form); if (first) first.checked = true;
    preview();
    form._amount = amount;
  }

  /* ---------- FAQ search ---------- */
  function initFaq() {
    var q = $('#faq-q'); if (!q) return;
    var items = $$('[data-component="faq-item"]'), groups = $$('[data-component="faq-group"]'), count = $('[data-component="faq-search"] [data-result-count]'), empty = $('[data-section="faq-content"] > [data-empty-state]');
    var t;
    q.addEventListener('input', function () {
      var term = q.value.trim().toLowerCase(), shown = 0;
      items.forEach(function (it) { var ok = !term || it.getAttribute('data-search').indexOf(term) > -1; it.hidden = !ok; if (ok) shown++; });
      groups.forEach(function (g) { g.hidden = !$$('[data-component="faq-item"]', g).some(function (i) { return !i.hidden; }); });
      empty.hidden = shown > 0;
      clearTimeout(t); t = setTimeout(function () { count.textContent = term ? shown + ' of ' + items.length + ' questions match.' : ''; }, 400);
    });
  }

  /* ---------- community (blog) listing: search + category + pagination ---------- */
  function initBlogList() {
    var root = $('[data-component="blog-list"]'); if (!root) return;
    var items = $$('[data-component="post-card-wrap"]', root), q = $('#blog-filter-q');
    var chips = $$('[data-component="filter-buttons"] [data-category]', root);
    var count = $('[data-result-count]', root), pag = $('[data-pagination]', root), empty = $('[data-empty-state]', root);
    var per = 6, page = 1, cat = 'all', t;
    var params = new URLSearchParams(location.search);
    if (params.get('q')) q.value = params.get('q');
    if (params.get('category') && chips.some(function (c) { return c.getAttribute('data-category') === params.get('category'); })) cat = params.get('category');
    function setChips() { chips.forEach(function (c) { var on = c.getAttribute('data-category') === cat; c.classList.toggle('active', on); c.setAttribute('aria-pressed', String(on)); }); }
    function mk(label, p, disabled, current) {
      var li = document.createElement('li');
      li.className = 'page-item' + (disabled ? ' disabled' : '') + (current ? ' active' : '');
      var b = document.createElement('button'); b.type = 'button'; b.className = 'page-link'; b.innerHTML = label;
      if (current) b.setAttribute('aria-current', 'page');
      if (disabled) b.disabled = true;
      b.addEventListener('click', function () { page = p; render(true); });
      li.appendChild(b); pag.appendChild(li);
    }
    function render(focusTop, delay) {
      var term = q.value.trim().toLowerCase();
      var matches = items.filter(function (it) { return (cat === 'all' || it.getAttribute('data-category') === cat) && (!term || it.getAttribute('data-search').indexOf(term) > -1); });
      var pages = Math.max(1, Math.ceil(matches.length / per)); if (page > pages) page = pages;
      items.forEach(function (it) { it.hidden = true; });
      matches.slice((page - 1) * per, page * per).forEach(function (it) { it.hidden = false; });
      empty.hidden = matches.length > 0;
      var msg = matches.length ? 'Showing ' + ((page - 1) * per + 1) + '–' + Math.min(page * per, matches.length) + ' of ' + matches.length + ' stories' + (cat !== 'all' ? ' in ' + cat : '') + '.' : 'No stories found.';
      clearTimeout(t); t = setTimeout(function () { count.textContent = msg; }, delay || 0);
      pag.innerHTML = '';
      if (pages > 1) {
        mk('Previous<span class="visually-hidden"> page</span>', page - 1, page === 1);
        for (var i = 1; i <= pages; i++) mk('<span class="visually-hidden">Page </span>' + i, i, false, i === page);
        mk('Next<span class="visually-hidden"> page</span>', page + 1, page === pages);
      }
      if (focusTop) { count.textContent = msg; count.setAttribute('tabindex', '-1'); count.focus(); }
    }
    q.addEventListener('input', function () { page = 1; render(false, 400); });
    chips.forEach(function (c) { c.addEventListener('click', function () { cat = c.getAttribute('data-category'); page = 1; setChips(); render(); }); });
    $$('[data-filter-reset]', root).forEach(function (b) { b.addEventListener('click', function () { cat = 'all'; q.value = ''; page = 1; setChips(); render(); q.focus(); }); });
    setChips(); render();
  }

  /* ---------- careers ---------- */
  function initCareers() {
    var scope = $('[data-section="job-list"]'); if (!scope) return;
    initButtonFilter('[data-component="filter-buttons"]', 'team', '[data-component="job-item"]', 'roles', scope);
    $$('[data-apply]').forEach(function (b) {
      b.addEventListener('click', function () {
        var sel = $('#a-role'); sel.value = b.getAttribute('data-apply');
        var name = $('#a-name'); name.focus();
        announce('Applying for ' + sel.options[sel.selectedIndex].text + '. Role selected in the application form.');
      });
    });
  }

  /* ---------- press year filter ---------- */
  function initPress() {
    var sel = $('#press-year'); if (!sel) return;
    var items = $$('[data-component="press-item"]'), count = $('[data-component="press-filter"] [data-result-count]');
    function apply() { var n = 0; items.forEach(function (it) { var ok = sel.value === 'all' || it.getAttribute('data-year') === sel.value; it.hidden = !ok; if (ok) n++; }); count.textContent = 'Showing ' + n + ' of ' + items.length + ' articles.'; }
    sel.addEventListener('change', apply); apply();
  }

  /* ---------- site search (search.html) ---------- */
  function initSearchPage() {
    var list = $('[data-search-results]'); if (!list) return;
    var q = (new URLSearchParams(location.search).get('q') || '').trim();
    var input = $('#search-page-q'), count = $('[data-search-count]'), heading = $('[data-search-heading]');
    input.value = q;
    if (!q) return;
    var terms = q.toLowerCase().split(/\s+/).filter(Boolean);
    var results = (D.searchIndex || []).map(function (r) {
      var t = r.t.toLowerCase(), x = r.x.toLowerCase(), score = 0;
      terms.forEach(function (w) { if (t.indexOf(w) > -1) score += 3; if (x.indexOf(w) > -1) score += 1; });
      if (t.indexOf(q.toLowerCase()) > -1) score += 4;
      return { r: r, s: score };
    }).filter(function (o) { return o.s > 0; }).sort(function (a, b) { return b.s - a.s; });
    document.title = 'Search results for “' + q + '” | Vicolo Verde';
    heading.textContent = 'Results for “' + q + '”';
    count.textContent = results.length ? results.length + (results.length === 1 ? ' result' : ' results') + ' found.' : 'No results found. Try a different word, or browse the menu.';
    list.innerHTML = results.slice(0, 30).map(function (o) {
      return '<li class="search-result" data-component="search-result"><p class="small text-body-secondary mb-1">' + esc(o.r.k) + '</p><h3 class="h5 mb-1"><a href="' + esc(o.r.u) + '">' + esc(o.r.t) + '</a></h3><p class="mb-0 small">' + esc(o.r.x) + '</p></li>';
    }).join('');
  }

  /* ---------- character counters ---------- */
  function initCharCounts() {
    $$('[data-component="char-count"]').forEach(function (ta) {
      var max = ta.maxLength; if (!(max > 0)) return;
      var out = document.createElement('div');
      out.className = 'form-text char-count'; out.id = ta.id + '-count';
      ta.parentNode.insertBefore(out, ta.nextSibling);
      addDesc(ta, out.id);
      var warned = false;
      function upd() {
        var left = max - ta.value.length;
        out.textContent = ta.value.length + ' of ' + max + ' characters used';
        if (left <= 20 && !warned) { announce(left + ' characters remaining'); warned = true; }
        if (left > 20) warned = false;
      }
      ta.addEventListener('input', upd); upd();
    });
  }

  /* ---------- copy link ---------- */
  function initCopyLink() {
    $$('[data-copy-link]').forEach(function (b) {
      b.addEventListener('click', function () {
        var done = function () { toast('Link copied to clipboard.'); };
        if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(location.href).then(done, function () { toast('Copy failed. The link is: ' + location.href); });
        else {
          var ta = document.createElement('textarea'); ta.value = location.href; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
          document.body.appendChild(ta); ta.select();
          try { document.execCommand('copy'); done(); } catch (e) { toast('The link is: ' + location.href); }
          document.body.removeChild(ta);
        }
      });
    });
  }

  /* =====================================================================
     FORM VALIDATION (WCAG 3.3.1, 3.3.3: identify + describe errors)
     ===================================================================== */
  var PHONE_RE = /^\D*(?:1\D*)?(?:\d\D*){10}$/;
  function addDesc(el, id) { var v = (el.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean); if (v.indexOf(id) === -1) v.push(id); el.setAttribute('aria-describedby', v.join(' ')); }
  function removeDesc(el, id) { var v = (el.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (x) { return x && x !== id; }); if (v.length) el.setAttribute('aria-describedby', v.join(' ')); else el.removeAttribute('aria-describedby'); }

  function fieldError(ctl) {
    var ds = ctl.dataset;
    if (ctl.type === 'radio') {
      var grp = $$('input[name="' + ctl.name + '"]', ctl.form);
      if (ctl.required && !grp.some(function (r) { return r.checked; })) return ds.msgRequired || 'Choose an option.';
      return '';
    }
    if (ctl.type === 'checkbox') return ctl.required && !ctl.checked ? (ds.msgRequired || 'Check this box to continue.') : '';
    if (ctl.type === 'file') return '';
    var v = ctl.value.trim();
    if (ctl.type === 'number' && ctl.validity && ctl.validity.badInput) return ds.msgRange || 'Enter a number.';
    if (ctl.required && !v) return ds.msgRequired || 'This field is required.';
    if (!v) return '';
    if (ctl.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return ds.msgType || 'Enter a valid email address.';
    if (ds.validate === 'phone' && !PHONE_RE.test(v)) return ds.msgPattern || 'Enter a valid phone number.';
    if (ctl.getAttribute('pattern') && !new RegExp('^(?:' + ctl.getAttribute('pattern') + ')$').test(v)) return ds.msgPattern || 'Check the format of this field.';
    if (ctl.type === 'number') {
      var n = Number(v);
      if (isNaN(n) || (ctl.min !== '' && n < +ctl.min) || (ctl.max !== '' && n > +ctl.max)) return ds.msgRange || ('Enter a number between ' + ctl.min + ' and ' + ctl.max + '.');
    }
    if (ds.validate === 'future-date') {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return 'Enter a date in the format YYYY-MM-DD.';
      if (v < isoFromToday(+ds.minDays || 0)) return ds.msgMin || 'Choose a later date.';
      if (ds.maxDays && v > isoFromToday(+ds.maxDays)) return ds.msgMax || 'Choose an earlier date.';
    }
    if (ctl.maxLength > 0 && v.length > ctl.maxLength) return 'Use ' + ctl.maxLength + ' characters or fewer.';
    return '';
  }
  function errorTargetId(ctl) { return ctl.type === 'radio' ? ctl.name : ctl.id; }
  function setError(ctl, msg) {
    var gid = errorTargetId(ctl), errEl = document.getElementById(gid + '-error');
    var targets = ctl.type === 'radio' ? $$('input[name="' + ctl.name + '"]', ctl.form) : [ctl];
    targets.forEach(function (t) {
      if (msg) { t.setAttribute('aria-invalid', 'true'); t.classList.add('is-invalid'); if (errEl) addDesc(t, errEl.id); }
      else { t.removeAttribute('aria-invalid'); t.classList.remove('is-invalid'); if (errEl) removeDesc(t, errEl.id); }
    });
    if (errEl) { errEl.textContent = msg || ''; errEl.classList.toggle('d-block', !!msg); }
    var fs = document.getElementById(gid + '-group'); if (fs) fs.classList.toggle('is-invalid-group', !!msg);
  }
  function controls(form) {
    return $$('input, select, textarea', form).filter(function (c) {
      return c.name && !c.disabled && c.type !== 'submit' && c.type !== 'button' && !c.closest('[hidden]') && !c.closest('[data-form-success]');
    });
  }
  var EXTRA = {
    reservation: function (form) {
      var errs = [], party = $('#r-party');
      if (party.value === '9+') errs.push({ id: 'r-party', msg: 'Online booking is for up to 8 guests. Use the Gatherings inquiry form for larger parties.', el: party });
      else if ($('#r-date').value && party.value && !$('input[name="r-time"]:checked', form)) {
        var first = $('input[name="r-time"]:not(:disabled)', form);
        var errEl = $('#r-time-error');
        errEl.textContent = 'Choose an available time.'; errEl.classList.add('d-block');
        errs.push({ id: first ? first.id : 'r-date', msg: 'Choose an available time.' });
      }
      return errs;
    },
    takeout: function () {
      return Bag.count() ? [] : [{ id: 'order-menu-title', msg: 'Add at least one dish to your order.' }];
    },
    'shop-checkout': function () {
      return Cart.count() ? [] : [{ id: 'products-title', msg: 'Your cart is empty. Add at least one product.' }];
    },
    application: function (form) {
      var fs = $('#a-days-group', form); if (!fs) return [];
      var ok = $$('input[type="checkbox"]', fs).some(function (c) { return c.checked; });
      var errEl = $('#a-days-error');
      errEl.textContent = ok ? '' : fs.getAttribute('data-require-one'); errEl.classList.toggle('d-block', !ok);
      fs.classList.toggle('is-invalid-group', !ok);
      $$('input', fs).forEach(function (c) { if (ok) { c.removeAttribute('aria-invalid'); removeDesc(c, 'a-days-error'); } else { c.setAttribute('aria-invalid', 'true'); addDesc(c, 'a-days-error'); } });
      return ok ? [] : [{ id: 'a-days-mon', msg: fs.getAttribute('data-require-one') }];
    }
  };
  function validateForm(form) {
    var errs = [], seen = {};
    controls(form).forEach(function (c) {
      var key = c.type === 'radio' ? 'r:' + c.name : c.id;
      if (seen[key]) return; seen[key] = 1;
      var msg = fieldError(c); setError(c, msg);
      if (msg) {
        var target = c.type === 'radio' ? $('input[name="' + c.name + '"]', form) : c;
        errs.push({ id: target.id, msg: msg });
      }
    });
    var ex = EXTRA[form.getAttribute('data-form')];
    if (ex) errs = errs.concat(ex(form));
    return errs;
  }
  function showSummary(form, errs) {
    var s = $('[data-error-summary]', form); if (!s) return;
    if (!errs.length) { s.hidden = true; s.innerHTML = ''; return; }
    s.innerHTML = '<h3 class="h6 mb-2">' + (errs.length === 1 ? 'There is a problem with 1 field' : 'There are problems with ' + errs.length + ' fields') + '</h3><ul class="mb-0">' +
      errs.map(function (er) { return '<li><a href="#' + esc(er.id) + '">' + esc(er.msg) + '</a></li>'; }).join('') + '</ul>';
    s.hidden = false;
    $$('a', s).forEach(function (a) {
      a.addEventListener('click', function (ev) {
        ev.preventDefault();
        var t = document.getElementById(a.getAttribute('href').slice(1));
        if (t) { if (t.tagName === 'H2' || t.tagName === 'H3') t.setAttribute('tabindex', '-1'); t.focus(); }
      });
    });
    s.focus();
  }
  function showSuccess(form, html) {
    var ok = $('[data-form-success]', form); if (!ok) return;
    Array.prototype.forEach.call(form.children, function (ch) { if (ch !== ok) { ch.setAttribute('data-was-hidden', ch.hidden ? '1' : '0'); ch.hidden = true; } });
    if (html) { var b = $('[data-success-body]', ok); if (b) b.innerHTML = html; }
    ok.hidden = false; ok.focus();
  }
  function resetForm(form) {
    var ok = $('[data-form-success]', form);
    form.reset();
    Array.prototype.forEach.call(form.children, function (ch) { if (ch !== ok) ch.hidden = ch.getAttribute('data-was-hidden') === '1'; });
    $$('[data-error-summary]', form).forEach(function (s) { s.hidden = true; });
    if (ok) ok.hidden = true;
    form.dispatchEvent(new Event('vv:reset'));
    var f = controls(form)[0]; if (f) f.focus();
  }

  var HANDLERS = {
    reservation: function (form) {
      var m = +$('input[name="r-time"]:checked', form).value;
      var r = { code: randCode('VV-R'), date: $('#r-date').value, min: m, party: $('#r-party').value, name: $('#r-first').value.trim() + ' ' + $('#r-last').value.trim(), seating: $('input[name="r-seating"]:checked', form).nextElementSibling.textContent };
      form._last = r;
      var html = '<dl class="summary-list"><div><dt>Confirmation</dt><dd>' + r.code + '</dd></div><div><dt>Date</dt><dd>' + fmtDate(r.date) + '</dd></div><div><dt>Time</dt><dd>' + fmtMin(r.min) + '</dd></div><div><dt>Party</dt><dd>' + esc(r.party) + '</dd></div><div><dt>Seating</dt><dd>' + esc(r.seating) + '</dd></div><div><dt>Name</dt><dd>' + esc(r.name) + '</dd></div></dl><p class="small mb-0">Demo only: no reservation was made and no email was sent.</p>';
      var modal = $('#res-confirm');
      if (modal && BS) { $('[data-confirm-body]', modal).innerHTML = html; BS.Modal.getOrCreateInstance(modal).show(); }
      return html;
    },
    takeout: function (form) {
      var sel = $('#t-time'), items = Bag.items(), sub = Bag.subtotal(), tax = sub * (D.taxRate || 0);
      var html = '<p>Order <strong>' + randCode('VV-T') + '</strong> for <strong>' + esc($('#t-name').value.trim()) + '</strong>.</p><p>Pickup: <strong>' + esc(sel.options[sel.selectedIndex].text) + '</strong> at the host stand, 212 Bedford Row.</p><ul>' +
        items.map(function (x) { return '<li>' + x.qty + ' × ' + esc(x.name) + ' (' + money(x.price * x.qty) + ')</li>'; }).join('') + '</ul><p class="fw-semibold">Total due at pickup: ' + money(sub + tax) + '</p><p class="small mb-0">Demo only: the kitchen has not received this order.</p>';
      Bag.clear();
      return html;
    },
    'shop-checkout': function (form) {
      var items = Cart.items(), ship = $('input[name="s-ship"]:checked', form).value === 'ground' ? 8 : 0, sub = Cart.subtotal();
      var html = '<p>Order <strong>' + randCode('VV-S') + '</strong> is confirmed.</p><ul>' + items.map(function (x) { return '<li>' + x.qty + ' × ' + esc(x.name) + ' (' + money(x.price * x.qty) + ')</li>'; }).join('') +
        '</ul><p class="fw-semibold">Total: ' + money(sub + ship) + (ship ? ' including $8.00 shipping' : ' (pickup)') + '</p><p class="small mb-0">Demo only: no payment was taken and nothing will ship.</p>';
      Cart.clear();
      return html;
    },
    'gift-card': function (form) {
      var a = form._amount(), to = $('#gc-to-name').value.trim();
      Cart.add({ id: 'gift-' + Date.now(), name: 'eGift card for ' + to, price: a, qty: 1 });
      return '<p>A ' + money(a) + ' eGift card for ' + esc(to) + ', to be emailed on ' + fmtDate($('#gc-send').value) + ', is in your cart.</p>';
    },
    'gift-balance': function (form) {
      var code = $('#gb-code').value.toUpperCase().replace(/[^A-Z0-9]/g, '');
      var out = $('[data-balance-result]', form), bal = (D.demoGiftCards || {})[code];
      if (bal === undefined) out.innerHTML = '<p class="alert alert-warning mb-0">We could not find a gift card with that code. Check the code and try again.</p>';
      else out.innerHTML = '<p class="alert alert-success mb-0">Card ending ' + code.slice(-4) + ' has a balance of <strong>' + money(bal) + '</strong>.</p>';
      return false; // stay on the form
    }
  };

  function initForms() {
    $$('[data-component="validated-form"]').forEach(function (form) {
      // Re-validate a field once the user has interacted with it.
      form.addEventListener('focusout', function (e) {
        var c = e.target; if (!c.name || !c.form || c.type === 'radio') return;
        if (c.value || c.getAttribute('aria-invalid') === 'true') { if (c.type !== 'checkbox') setError(c, fieldError(c)); }
      });
      form.addEventListener('change', function (e) {
        var c = e.target; if (!c.name) return;
        if (c.type === 'radio' || c.type === 'checkbox' || c.tagName === 'SELECT') {
          if (c.getAttribute('aria-invalid') === 'true' || c.type === 'radio') setError(c, fieldError(c));
        }
        if (c.name === 'r-time') { var er = $('#r-time-error'); er.textContent = ''; er.classList.remove('d-block'); }
      });
      form.addEventListener('input', function (e) { var c = e.target; if (c.getAttribute('aria-invalid') === 'true' && !fieldError(c)) setError(c, ''); });
      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var errs = validateForm(form);
        var summary = $('[data-error-summary]', form);
        if (errs.length) {
          if (form.getAttribute('data-form') === 'newsletter' || !summary) { var f = document.getElementById(errs[0].id); if (f) f.focus(); }
          else showSummary(form, errs);
          return;
        }
        showSummary(form, []);
        var h = HANDLERS[form.getAttribute('data-form')];
        var res = h ? h(form) : null;
        if (res === false) return;
        showSuccess(form, res);
      });
      $$('[data-form-reset]', form).forEach(function (b) { b.addEventListener('click', function () { resetForm(form); }); });
      $$('[data-ics-download]', form).forEach(function (b) {
        b.addEventListener('click', function () {
          if (!form._last) return;
          var blob = new Blob([icsFor(form._last)], { type: 'text/calendar' });
          var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'vicolo-verde-reservation.ics';
          document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
          toast('Calendar file downloaded.');
        });
      });
    });
    var res = $('[data-form="reservation"]');
    if (res) res.addEventListener('vv:reset', function () { $('#r-party').dispatchEvent(new Event('change')); });
    var to = $('[data-form="takeout"]');
    if (to) to.addEventListener('vv:reset', function () { pickupOptions($('#t-time')); });
    var gc = $('[data-form="gift-card"]');
    if (gc) gc.addEventListener('vv:reset', function () { var f = $('input[name="gc-amount"]', gc); f.checked = true; f.dispatchEvent(new Event('change', { bubbles: true })); });
  }

  /* ---------- boot ---------- */
  function boot() {
    initOpenStatus();
    setInterval(initOpenStatus, 60000);
    initStickyHeader();
    initBackToTop();
    initAnchorNav();
    initCarousels();
    initCardSliders();
    initMenu();
    var ck = $('[data-section="cocktail-list"]');
    if (ck) initButtonFilter('[data-component="filter-buttons"]', 'spirit', '[data-component="cocktail-card"]', 'drinks', ck);
    initCart();
    initShop();
    initTakeout();
    initReservations();
    initGiftCards();
    initFaq();
    initBlogList();
    initCareers();
    initPress();
    initSearchPage();
    initCharCounts();
    initCopyLink();
    initForms();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
;
