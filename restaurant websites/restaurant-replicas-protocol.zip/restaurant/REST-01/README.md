# REST-01: Vicolo Verde

## Protocol record (WEB-REPLICA-V1.0)

| Field | Value |
|---|---|
| Replica ID | REST-01 |
| Category | restaurant: Small local independent |
| Fictional branding | Vicolo Verde (fictional business; 555 phone numbers, `.example` email) |
| Approved source | Via Carota, https://www.viacarota.com/ |
| Source verification | Live status verified 2026-11-06 by web search during Phase A; source approved by Isaac. Visual design not measured in a browser (site 1 was built before browser inspection was available); structure taken from the source pages. |
| Run locally | Open `index.html` in a browser. No server, build step or network is needed. |
| Layout | `*.html` pages, `css/styles.css`, `js/main.js`, `assets/` (images, fonts, vendor/bootstrap, vendor/jquery), `README.md`, `fidelity-notes.md`, `component-inventory.json` |
| Deviations | The protocol prohibits both libraries below. Both were included by Isaac's decision on 2026-11-07; see fidelity-notes.md. **Bootstrap 5.3.3**, stored locally, is used for layout and components. **jQuery 3.7.1**, stored locally, is loaded on every page, but the site's own code does not call it. |

### Sample data

| Data | Count |
|---|---|
| Locations with hours | 5 |
| Menu items (menu pages) | 36 |
| Blog / news / story articles | 8 |
| Products | 7 |
| FAQ items | 13 |
| Site-search index entries | 88 |
| Demo gift card numbers | 3 |

### Quality-control gates

| Gate | Result |
|---|---|
| 13. Technology | **Fail (documented deviations):** Bootstrap 5.3.3 is used, and jQuery 3.7.1 is loaded on every page but not called by the site's code. **Pass:** no other framework or library, no PHP, no backend, no build step, and no remote runtime dependencies (automated scan of every page). |
| 14. Completeness | **Pass:** all 26 pages and the 3 required documents are present. Automated link audit of every `href`/`src` in the HTML, every `url()` in the CSS and every `.html` reference in the JS: 0 broken. |
| 15. Structure | **Pass (automated):** every page has `header`, a labeled `nav`, `main` and `footer` carrying `data-section`; there are 1177 `data-component` instances. The region hierarchy was compared with the source during the build (see fidelity-notes.md); there was no independent review. |
| 16. Interaction | **Pass:** 51/51 scripted Playwright checks (forms, filters, search, navigation and site-specific flows). Simulated flows say they are demos. `href="#"` placeholders: 0. |
| 17. Accessibility review | **Automated pass:** axe-core 4.14 found 0 violations on all 26 pages at 1280px and 375px. Also checked by script: no horizontal scroll at 375px and no content overlapping the footer. **Not tested:** manual keyboard walkthrough, screen readers, 200% text zoom, and reduced-motion behavior (implemented in CSS/JS but not exercised). |
| 18. Traceability | **Pass:** this README, fidelity-notes.md and component-inventory.json were generated from the delivered files. `component-inventory.json` records which components a script exercised and which were not tested. |
| 19. Scope | **Pass, with additions:** the intentional additions (FAQ, site search, 404 and others) are labeled in the page mapping and in fidelity-notes.md. |

Automated results support a WCAG 2.2 AA–oriented baseline. They do not prove conformance.

---

## About Vicolo Verde

**Vicolo Verde** is a fictional West Village trattoria. This static website copies the *structure* of a real small independent restaurant site ([Via Carota](https://www.viacarota.com/)): its page set, layout regions, navigation pattern and interactive features. All names, copy, prices, people, addresses and images are invented or placeholders. The site was built as a clean **WCAG 2.2 AA baseline** for accessibility and usability research.

> Not a real business. Phone numbers use the 555 range, and email addresses use the reserved `.example` domain.

## Run it

You don't need a server or a build step. Unzip the folder and open `index.html` in a browser. Every page works over `file://` and offline, because Bootstrap is stored locally in `assets/vendor/`.

You can also serve the folder with any static server (for example `python3 -m http.server`) if a testing tool needs `http://` URLs.

## Stack and constraints

| Used | Not used |
|---|---|
| HTML5, CSS3, vanilla JavaScript (ES5-compatible, no modules) | React or any framework |
| Bootstrap 5.3.3 (CSS + bundle JS, vendored) | PHP, server includes, `fetch()`-loaded partials |
| jQuery 3.7.1 (vendored, loaded on every page; the site's own code is vanilla JS and does not call it) | |
| `sessionStorage` with an in-memory fallback for the cart and take-out bag | Databases, APIs, build tools, cookies, analytics |

**Shared header and footer.** These are copied in full into every HTML file, so each page is complete on its own and the raw source matches what the browser renders. To change the navigation, find-and-replace the same block across all `*.html` files.

## File tree

```
REST-01/
├── index.html                 Home: hero, in-page anchor nav, about, gallery carousel, menu teasers,
│                              photo banner, press quote, community card slider, directions + newsletter
├── menu.html                  Menu tabs (Lunch & Dinner / Brunch / Desserts / Drinks) + search + dietary filters
├── cocktails.html             Cocktail list with spirit filter, aperitivo band
├── about.html                 "Bea & Lorenzo": story, timeline, team cards with bio modals
├── gatherings.html            Private events: spaces, package accordion, catering, inquiry form
├── reservations.html          3-step booking form, generated time slots, confirmation modal, .ics download
├── takeout.html               Pickup ordering: add dishes, bag with steppers/tax, pickup-time form
├── shop.html                  Product grid with filter/sort, quick-view modal, checkout form
├── gift-cards.html            eGift purchase with live preview, balance checker
├── press.html                 Coverage list with year filter, press kit, media contact
├── community.html             Blog listing: search, category chips, pagination, sidebar
├── community-*.html (8)       Blog posts: byline, share, older/newer, related, sidebar
├── careers.html               Perks, role filter + accordion, application form
├── contact.html               Location card, weekly hours, directions, contact form, sister restaurants
├── faq.html                   Topic TOC, live FAQ search, accordions
├── search.html                Client-side site search results (?q=)
├── privacy.html, accessibility.html, 404.html
├── css/styles.css             All custom styles (design tokens at the top)
├── js/main.js                 Site data (hours, tax rate, demo gift codes, search index), then all behavior in one IIFE
├── assets/img/*.svg           Labelled placeholder images
├── assets/press-kit.txt       Downloadable demo press kit
├── assets/vendor/bootstrap/   bootstrap.min.css, bootstrap.bundle.min.js, LICENSE (MIT)
├── assets/vendor/jquery/      jquery-3.7.1.min.js, LICENSE.txt (MIT)
├── component-inventory.json   Every data-component: description, count, pages; plus per-page sections/landmarks
├── fidelity-notes.md          What matches the original, what was adapted, added or left out
└── README.md
```

## Annotation conventions

- **`data-section="…"`** marks every layout region: `header`, `utility-bar`, `logo-bar`, `primary-nav`, `main`, `hero`, `page-header`, `sidebar`, `footer`, and named body bands such as `gallery` and `checkout`.
- **`data-component="…"`** marks every interactive or repeated component. There are 93 types; see `component-inventory.json`.
- **`data-form="…"`** names each form for the validator (`reservation`, `takeout`, `gathering`, `newsletter`, …).

Together these make every region and component addressable, so you can log or plant issues against a stable selector, such as `[data-component="time-slots"]`.

## Simulated backend behavior

| Feature | What happens |
|---|---|
| Newsletter, contact, gatherings, careers forms | Validated in the browser, then show a success panel. Nothing is sent. |
| Reservations | Time slots are generated deterministically from date + party size. Success shows a confirmation code, a modal and a downloadable `.ics` calendar file. |
| Take out | Bag stored in `sessionStorage` (`vv-bag`). Pickup times are computed from today's hours. Success shows an order number and clears the bag. |
| Shop and gift cards | Cart stored in `sessionStorage` (`vv-cart`) and shared across pages. Gift cards are added as cart lines. Checkout success clears the cart. |
| Gift card balance | Demo codes: `VV-1234-5678` → $75.00, `VV-0000-1111` → $0.00, `VV-2468-2468` → $150.00. |
| Open/closed badges | Computed from `data.js` hours in `America/New_York`, refreshed every minute. Handles closing past midnight. |

## Testing aids

- **`?demo-time=YYYY-MM-DDTHH:MM`** on any page forces the restaurant's local time. For example, `contact.html?demo-time=2026-11-07T23:30` shows "Closing soon". It applies to that page load only.
- **Deep links:** `menu.html#tab-brunch` opens a tab; `menu.html#item-tiramisu` opens the right tab and highlights the dish.
- **URL parameters:** `community.html?category=producers&q=farm` and `search.html?q=pasta`.
- **Reset state:** close the tab, or run `sessionStorage.clear()` in the console.

## Accessibility baseline (WCAG 2.2 AA)

What's built in:
- Skip link and landmarks (`header`, `nav` ×2–3 with labels, `main`, `aside`, `footer`).
- One `h1` per page and a logical heading order.
- `lang="en"`, with `lang="it"` on Italian phrases (3.1.2).
- Visible 3px focus outline. A sticky-header offset uses `scroll-padding-top` so focused items aren't hidden (2.4.11).
- Targets are at least 24×24 CSS px; most are 44px (2.5.8).
- Text contrast ≥ 4.5:1, and form borders and focus ≥ 3:1 (1.4.3, 1.4.11).
- Forms have visible labels, `autocomplete` tokens (1.3.5), and inline errors linked by `aria-describedby` with `aria-invalid`. An error summary appears and takes focus (3.3.1, 3.3.3), and required/optional fields are stated.
- Filter result counts announce through polite live regions (4.1.3).
- The carousel has a pause/play button, pauses on hover and focus, and doesn't autoplay with `prefers-reduced-motion` (2.2.2).
- Status badges use text, not just color (1.4.1).
- Help (phone and contact link) is in the same place on every page (3.2.6).
- No layout reflow problems at 320–375px (1.4.10).

Automated results at delivery:
- **axe-core 4.14**, tags `wcag2a/aa, wcag21a/aa, wcag22aa, best-practice`: **0 violations on all 26 pages at 1280px and 375px**.
- **html-validate:** only style-preference findings remain (lowercase `<!doctype html>`, Bootstrap's `role="presentation"` on tab `<li>`s, and multiple checkboxes sharing one `name`, which is valid HTML).
- **51 scripted functional checks pass**, covering keyboard order, forms, filters, cart, booking, search, open/closed edge cases, the mobile nav and horizontal overflow. No JavaScript errors.

Not done: manual screen reader testing (NVDA, JAWS, VoiceOver) and user testing. Treat the automated results as a baseline, not a conformance claim.

## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | Bea & Lorenzo | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `careers.html` | Careers | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `cocktails.html` | Craft Cocktails | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `community-bedford-row-food-pantry.html` | Cooking with the Bedford Row Food Pantry | Article detail page (child of `community.html`); article content is original |
| `community-first-ramps-of-spring.html` | The first ramps of spring | Article detail page (child of `community.html`); article content is original |
| `community-guide-to-aperitivo.html` | A short guide to aperitivo hour | Article detail page (child of `community.html`); article content is original |
| `community-how-we-make-tonnarelli.html` | How we make tonnarelli by hand | Article detail page (child of `community.html`); article content is original |
| `community-meet-two-brooks-farm.html` | Meet our farmers: Two Brooks Farm | Article detail page (child of `community.html`); article content is original |
| `community-olive-harvest-notes.html` | Olive harvest notes from Umbria | Article detail page (child of `community.html`); article content is original |
| `community-ten-years-on-bedford-row.html` | Ten years on Bedford Row | Article detail page (child of `community.html`); article content is original |
| `community-winter-hours-holiday-closures.html` | Winter hours and holiday closures | Article detail page (child of `community.html`); article content is original |
| `community.html` | Community | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact & Directions | Approximated: combines the source's directions section with a contact form |
| `faq.html` | FAQ | Intentional addition (see fidelity-notes.md) |
| `gatherings.html` | Gatherings | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `gift-cards.html` | Gift Cards | Intentional addition (see fidelity-notes.md) |
| `index.html` | Vicolo Verde | Via Carota home page |
| `menu.html` | Menu | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `press.html` | Press | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `reservations.html` | Reservations | Intentional addition (see fidelity-notes.md) |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `shop.html` | Shop | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `takeout.html` | Take Out | Intentional addition (see fidelity-notes.md) |
