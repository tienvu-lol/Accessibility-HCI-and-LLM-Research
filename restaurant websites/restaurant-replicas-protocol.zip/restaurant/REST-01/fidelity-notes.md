<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-01 | Category: restaurant (Small local independent) | Source: Via Carota https://www.viacarota.com/ -->
# Fidelity notes: Vicolo Verde ↔ Via Carota

**Original:** https://www.viacarota.com/ (checked live on November 6, 2026).
**Replica:** Vicolo Verde, a fictional restaurant. Only the structure is copied. No brand names, copy, images, logos or code from the original are reused.

## Mirrored from the original

| Original | Replica |
|---|---|
| Header shown as a logo bar plus a separate text menu row | `logo-bar` (search · centered wordmark · cart) plus a `primary-nav` row |
| Nav: Gatherings, Shop, Gift Cards, Craft Cocktails, Take Out, founders' names ("Rita & Jody"), cart, search | Same order: Gatherings, Shop, Gift Cards, Craft Cocktails, Take Out, **"Bea & Lorenzo"** (founders), cart, search |
| Home is a long one-pager with anchor sections (Welcome, About, Gallery, Menu, Photo Banner, Press, Community, Directions & Stay in Touch) | Same section sequence, with an "On this page" anchor nav |
| Featured carousel (~15 items with "Read more") | Two pieces: a gallery carousel (6 slides) and a community card slider (6 stories with "View our community") |
| Menu shown as images plus a link to a plain-text version | Menu built entirely as accessible HTML text (see "Adapted") |
| Pull quote with "View Press" | `testimonial-quote` with "View press" |
| Reservations on an external booking site; walk-ins welcome | Walk-in messaging in the utility bar, hero and sidebar; booking simulated on the site |
| Take Out goes to an external ordering site | Pickup ordering simulated on `takeout.html` |
| Gift Cards link anchors into the Shop page | `shop.html#gift-cards` callout kept, plus a full `gift-cards.html` |
| Email newsletter signup | Validated newsletter in the home "Stay in touch" band and the footer |
| Footer: address, email, two hours blocks, walk-in note, sister-restaurant links, award badge, logo, copyright | Same items in a 5-column footer. Sister restaurants and award are fictional. |
| Footer links: Community, Press, COVID safety, Careers, Privacy, Accessibility, Contact | Community, Press, Careers, Privacy, Accessibility, Contact |
| Separate pages: Gatherings, Shop, Craft Cocktails, Community, Press, Careers | All present |

## Adapted, to meet the research brief and a clean WCAG 2.2 AA baseline

- **Menu as text, not images.** The original shows the menu mainly as images. The replica uses structured HTML with tabs, dietary labels and filters, as the brief asks.
- **Founder dropdown.** The original's founder link is a single page. The replica makes it a disclosure dropdown (Our Story, Press, Community, Careers), so the site has the dropdown navigation the brief asks for.
- **Header search goes to a results page.** The original search behavior wasn't observable. The replica uses a collapsible panel that submits to `search.html`, which searches a client-side index of pages, dishes, cocktails, stories, FAQs and products.
- **Sticky behavior.** On desktop only the primary nav row stays fixed; on mobile the logo bar stays fixed. This keeps focused content visible (WCAG 2.4.11).
- **Carousel controls.** A pause/play button, larger indicator targets (24px) and no autoplay when the user prefers reduced motion.

## Added for test coverage (not on the original)

`reservations.html` (date → time slots → details, plus modal and `.ics`), `takeout.html` (bag and checkout), `gift-cards.html` (purchase plus balance check), `faq.html`, `search.html`, `404.html`, `contact.html` (combines the original's Directions section with a contact form), blog breadcrumbs, blog pagination and sidebar, careers application form, shop quick-view modal and checkout. There are also JS open/closed badges on every location card and in the utility bar.

## Left out

- The COVID-19 safety page. It's outdated, and the brief doesn't include it.
- The footer link to an external NYC promotions program, which carried a tracking URL.
- **Age gate:** none. The original has no age gate, and one isn't conventional for a restaurant that serves cocktails. Age gates are planned for the brewery replica (Alder Creek Brewing).
- Real third-party integrations (Resy-style booking, Toast-style ordering, Instagram embeds). These are simulated or replaced with plain links.

## Defects on the original that were deliberately not copied

These were observed on the live site on November 6, 2026. They're recorded here as reference points, for example as candidate issues to plant later.

1. The newsletter form shows a site-builder message ("needs a storage option"), so signup isn't configured.
2. Friday opening time conflicts between two places (10:00 AM in one hours block, 11:00 AM in the footer).
3. Some image alt text doesn't help (for example "dead duck" and "spoon").
4. The navigation appears twice and links are duplicated, so screen reader users hear redundant links.
5. The menu is presented mainly as images, with the text version behind a secondary link.


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | Bea & Lorenzo | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `careers.html` | Careers | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `cocktails.html` | Craft Cocktails | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `community-bedford-row-food-pantry.html` | Cooking with the Bedford Row Food Pantry | Article detail page (child of `community.html`); article content is original |
| `community-first-ramps-of-spring.html` | The first ramps of spring | Article detail page (child of `community.html`); article content is original |
| `community-guide-to-aperitivo.html` | A short guide to aperitivo hour | Article detail page (child of `community.html`); article content is original |
| `community-how-we-make-tonnarelli.html` | How we make tonnarelli by hand | Article detail page (child of `community.html`); article content is original |
| `community-meet-two-brooks-farm.html` | Meet our farmers: Two Brooks Farm | Article detail page (child of `community.html`); article content is original |
| `community-olive-harvest-notes.html` | Olive harvest notes from Umbria | Article detail page (child of `community.html`); article content is original |
| `community-ten-years-on-bedford-row.html` | Ten years on Bedford Row | Article detail page (child of `community.html`); article content is original |
| `community-winter-hours-holiday-closures.html` | Winter hours and holiday closures | Article detail page (child of `community.html`); article content is original |
| `community.html` | Community | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact & Directions | Approximated: combines the source's directions section with a contact form |
| `faq.html` | FAQ | Intentional addition (see fidelity-notes.md) |
| `gatherings.html` | Gatherings | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `gift-cards.html` | Gift Cards | Intentional addition (see fidelity-notes.md) |
| `index.html` | Vicolo Verde | Via Carota home page |
| `menu.html` | Menu | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `press.html` | Press | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `reservations.html` | Reservations | Intentional addition (see fidelity-notes.md) |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `shop.html` | Shop | Mirrors a Via Carota page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `takeout.html` | Take Out | Intentional addition (see fidelity-notes.md) |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
