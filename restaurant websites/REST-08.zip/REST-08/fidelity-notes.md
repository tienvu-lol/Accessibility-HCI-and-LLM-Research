<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-08 | Category: restaurant (Ethnic (Xi'an Chinese)) | Source: Xi'an Famous Foods https://www.xianfoods.com/ -->
# Fidelity notes: Red Lantern Noodle Co. ↔ Xi'an Famous Foods

**Original:** https://xianfoods.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Red Lantern Noodle Co.. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured) | Replica |
|---|---|---|
| Brand colors | Red `#CF0909`, dark red `#8E0808`, near-black `#231F20`, cream `#F1EEE3` | Same four colors (all pairs used pass AA, for example cream on red 4.9:1) |
| Buttons | Yellow `#FFCD15`, 2.7px dark border, 8px radius ("Our Story", "See Menu") | Same yellow, border and radius, plus a hard offset shadow |
| Type | PP Supply Sans bold uppercase headings and nav; Open Sans body; Merriweather | **Space Grotesk** (OFL) bold uppercase for headings and nav; **Open Sans** (OFL) body |
| Ticker | Scrolling SVG ticker band | Text ticker with a pause button; the text is also available to screen readers as a static sentence |
| Section dividers | Wavy red and dark SVG backgrounds | Wavy SVG divider (`assets/img/wavy-red.svg`) above the classics band |
| Video | Hero video with Pause/Play | Local placeholder MP4 with native controls, captions and a transcript; no autoplay |

## Mirrored structure
- **Two brands** (the main noodle restaurants and a hand-pulled noodle shop), each with its own locations.
- **Menu:** dish codes (A1, B1, N4 style), category grouping and spice information.
- **Story video** with playback controls; "The Classics" section; "Get to know us" story teaser with "Here's our story →".
- **Shop:** chili oil, cookbook and meal kits. Also pickup/delivery, catering, rewards, press and jobs.

## Adapted, added or left out
- **Added:** a spice-level filter, dish-code search, a brand/borough/ZIP location finder, location pages with live hours, a tray order flow, a blog with filters, FAQ, site search and a 404 page.
- **Video:** the original autoplays; the replica never autoplays, so motion and sound start only when the user chooses.

## Observations on the original that were not copied
1. The hero video autoplays. A pause button exists, but motion starts without user action.
2. The scrolling ticker is a decorative SVG with no text alternative and no pause control.
3. The page has no `header` landmark (measured: `header` element is null).


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `blog-chili-oil-how.html` | How we make our chili oil | Article detail page (child of `blog.html`); article content is original |
| `blog-dumbo-open.html` | Lantern Hand-Pulled opens in DUMBO | Article detail page (child of `blog.html`); article content is original |
| `blog-spice-levels.html` | A guide to our spice levels | Article detail page (child of `blog.html`); article content is original |
| `blog-twenty-years.html` | Twenty years since the first stall | Article detail page (child of `blog.html`); article content is original |
| `blog.html` | Blog | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `careers.html` | Jobs | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `catering.html` | Catering | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Red Lantern Noodle Co. | Xi'an Famous Foods home page |
| `location-chinatown.html` | Red Lantern Chinatown | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-flushing.html` | Red Lantern Flushing | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-hand-pulled-dumbo.html` | Lantern Hand-Pulled, DUMBO | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-hand-pulled-ev.html` | Lantern Hand-Pulled, East Village | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-midtown.html` | Red Lantern Midtown | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-williamsburg.html` | Red Lantern Williamsburg | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `locations.html` | Locations | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `menu.html` | Menu | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `order.html` | Pickup & Delivery | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `our-story.html` | Our Story | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `press.html` | Press | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `rewards.html` | Rewards | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `shop.html` | Shop | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
