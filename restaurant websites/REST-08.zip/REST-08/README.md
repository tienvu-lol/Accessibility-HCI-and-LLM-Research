# REST-08: Red Lantern Noodle Co.

## Protocol record (WEB-REPLICA-V1.0)

| Field | Value |
|---|---|
| Replica ID | REST-08 |
| Category | restaurant: Ethnic (Xi'an Chinese) |
| Fictional branding | Red Lantern Noodle Co. (fictional business; 555 phone numbers, `.example` email) |
| Approved source | Xi'an Famous Foods, https://www.xianfoods.com/ |
| Source verification | Live status verified 2026-11-06 by web search during Phase A; source approved by Isaac. Visual design (colors, fonts, spacing, header and button styles) measured from computed styles in a desktop browser, 2026-11-06/07. |
| Run locally | Open `index.html` in a browser. No server, build step or network is needed. |
| Layout | `*.html` pages, `css/styles.css`, `js/main.js`, `assets/` (images, fonts, vendor/bootstrap, vendor/jquery), `README.md`, `fidelity-notes.md`, `component-inventory.json` |
| Deviations | The protocol prohibits both libraries below. Both were included by Isaac's decision on 2026-11-07; see fidelity-notes.md. **Bootstrap 5.3.3**, stored locally, is used for layout and components. **jQuery 3.7.1**, stored locally, is loaded on every page, but the site's own code does not call it. |

### Sample data

| Data | Count |
|---|---|
| Locations with hours | 6 |
| Menu items (menu pages) | 15 |
| Blog / news / story articles | 4 |
| Products | 4 |
| Site-search index entries | 53 |
| Demo gift card numbers | 2 |

### Quality-control gates

| Gate | Result |
|---|---|
| 13. Technology | **Fail (documented deviations):** Bootstrap 5.3.3 is used, and jQuery 3.7.1 is loaded on every page but not called by the site's code. **Pass:** no other framework or library, no PHP, no backend, no build step, and no remote runtime dependencies (automated scan of every page). |
| 14. Completeness | **Pass:** all 28 pages and the 3 required documents are present. Automated link audit of every `href`/`src` in the HTML, every `url()` in the CSS and every `.html` reference in the JS: 0 broken. |
| 15. Structure | **Pass (automated):** every page has `header`, a labeled `nav`, `main` and `footer` carrying `data-section`; there are 892 `data-component` instances. The region hierarchy was compared with the source during the build (see fidelity-notes.md); there was no independent review. |
| 16. Interaction | **Pass:** 30/30 scripted Playwright checks (forms, filters, search, navigation and site-specific flows). Simulated flows say they are demos. `href="#"` placeholders: 0. |
| 17. Accessibility review | **Automated pass:** axe-core 4.14 found 0 violations on all 28 pages at 1280px and 375px. Also checked by script: no horizontal scroll at 375px and no content overlapping the footer. **Not tested:** manual keyboard walkthrough, screen readers, 200% text zoom, and reduced-motion behavior (implemented in CSS/JS but not exercised). |
| 18. Traceability | **Pass:** this README, fidelity-notes.md and component-inventory.json were generated from the delivered files. `component-inventory.json` records which components a script exercised and which were not tested. |
| 19. Scope | **Pass, with additions:** the intentional additions (FAQ, site search, 404 and others) are labeled in the page mapping and in fidelity-notes.md. |

Automated results support a WCAG 2.2 AA–oriented baseline. They do not prove conformance.

---

## About Red Lantern Noodle Co.

**Red Lantern Noodle Co.** is a fictional Xi'an-style Chinese noodle chain with two brands. This static website mirrors the *structure and visual language* of a real restaurant website, [Xi'an Famous Foods](https://xianfoods.com/): its page set, layout regions, navigation pattern, interactive features, color palette and typographic style. All names, copy, prices, people and addresses are invented, and all images are labeled placeholders. It is built as a clean **WCAG 2.2 AA baseline** for accessibility and usability research.

> Not a real business. Phone numbers use the 555 range, and email addresses use the reserved `.example` domain.

## Run it
You don't need a server, a build step or an internet connection. Unzip the folder and open `index.html` in a browser. Bootstrap and the fonts are stored locally. You can also serve the folder with any static server (for example `python3 -m http.server`) if a testing tool needs `http://` URLs.

## Stack
- HTML5, CSS3 and vanilla JavaScript (one IIFE in `js/main.js`, ES5-compatible, no modules).
- Bootstrap 5.3.3 (CSS and bundle JS), stored in `assets/vendor/bootstrap/`.
- Fonts: Space Grotesk (`@fontsource/space-grotesk`, SIL Open Font License), Open Sans (`@fontsource/open-sans`, SIL Open Font License). Stored in `assets/fonts/` with their licenses.
- jQuery 3.7.1, stored in `assets/vendor/jquery/` and loaded on every page before Bootstrap, so `jQuery` / `$` are available (for example to test tools or scripts). The site's own behavior in `js/main.js` is vanilla JavaScript and does not call it.
- **Not used:** PHP, React or any other framework, build tools, databases, APIs, cookies or analytics.
- **Shared header and footer:** these are copied in full into every HTML file, so the raw source of each page matches what the browser renders. To change the navigation, find-and-replace the same block in all `*.html` files.

## Pages (28)
| File | Title |
|---|---|
| `404.html` | Page not found |
| `accessibility.html` | Accessibility |
| `blog-chili-oil-how.html` | How we make our chili oil |
| `blog-dumbo-open.html` | Lantern Hand-Pulled opens in DUMBO |
| `blog-spice-levels.html` | A guide to our spice levels |
| `blog-twenty-years.html` | Twenty years since the first stall |
| `blog.html` | Blog |
| `careers.html` | Jobs |
| `catering.html` | Catering |
| `contact.html` | Contact |
| `faq.html` | FAQ |
| `gift-cards.html` | Gift Cards |
| `index.html` | Red Lantern Noodle Co. |
| `location-chinatown.html` | Red Lantern Chinatown |
| `location-flushing.html` | Red Lantern Flushing |
| `location-hand-pulled-dumbo.html` | Lantern Hand-Pulled, DUMBO |
| `location-hand-pulled-ev.html` | Lantern Hand-Pulled, East Village |
| `location-midtown.html` | Red Lantern Midtown |
| `location-williamsburg.html` | Red Lantern Williamsburg |
| `locations.html` | Locations |
| `menu.html` | Menu |
| `order.html` | Pickup & Delivery |
| `our-story.html` | Our Story |
| `press.html` | Press |
| `privacy.html` | Privacy |
| `rewards.html` | Rewards |
| `search.html` | Search |
| `shop.html` | Shop |

Assets: `css/styles.css` (shared structure, then this site's palette, fonts and flourishes), `js/main.js` (site data: hours, demo values, search index; then all behavior), `assets/img/*.svg` (labeled placeholders), `assets/media/` (an 8-second placeholder video, WebVTT captions and a poster image).

## Annotation conventions
- `data-section="…"` marks every layout region (header, utility bar, hero, page header, body bands, sidebar, footer).
- `data-component="…"` marks every interactive or repeated component. There are 67 types; see `component-inventory.json` for descriptions, counts and the pages each appears on.
- `data-form="…"` names each form's simulated handler (`booking`, `order`, `checkout`, `gift-card`, `gift-balance`, `newsletter`, `generic`).
- `data-filter-item`, `data-filter`, `data-filter-btn` and `data-sort` drive the shared client-side filtering engine.

## Simulated backend behavior
| Feature | What happens |
|---|---|
| Menu | Dish codes (N1, B2 and so on) are searchable. Filter by spice level (a select) and by dietary tags. |
| Locations | Two brands. Filter by brand (buttons), borough (select) and text or ZIP search (a ZIP sorts by distance). Six location pages. |
| Order | Pickup or delivery ($4.99); the bag lives in `sessionStorage`. |
| Catering trays and shop | Trays go into the order bag; shop items go into the cart (`shop.html#checkout`). |
| Video | A local MP4 with a WebVTT captions track, native controls and a full transcript. |

## Testing aids
- **`?demo-time=YYYY-MM-DDTHH:MM`** on any page forces the restaurant's local time (America/New_York), so you can test the open/closed badges.
- **Reset state:** close the tab, or run `sessionStorage.clear()` in the console. The cart, order bag and dismissed banners all live in `sessionStorage`.
- **Search by dish code:** on the menu, type `N1` to find the cumin lamb noodles.
- **Ticker:** honors `prefers-reduced-motion` and has a pause button.
- **Captions:** the caption track is embedded in the page as a `data:` URL, because Chrome refuses to load a separate `.vtt` file from `file://`. A copy is kept at `assets/media/story.vtt` for use on a web server.

## Accessibility baseline (WCAG 2.2 AA)
- **Structure:** skip link; labeled landmarks; one `h1` per page.
- **Focus:** a visible 3px focus outline. `scroll-padding-top` follows the sticky header's height so focused items are never hidden behind it (2.4.11).
- **Targets and contrast:** targets are at least 24×24px (2.5.8). Text contrast is at least 4.5:1, and form borders and focus indicators at least 3:1.
- **Forms:** visible labels and `autocomplete` tokens. Errors appear inline, linked by `aria-describedby` and marked `aria-invalid`. An error summary takes focus on submit. Required and optional fields are stated.
- **Live updates:** filter result counts are announced through polite live regions.
- **Moving content:** carousels and tickers have pause buttons, and don't autoplay when the user prefers reduced motion (2.2.2).
- **Status badges:** use text, not color alone.
- **Help:** contact help is in the same place on every page (3.2.6).
- **Video:** captions (WebVTT), a full text transcript, native controls and no autoplay.
Automated results at delivery:
- **axe-core 4.14.0** (tags `wcag2a/aa, wcag21a/aa, wcag22aa, best-practice`): **0 violations across 28 pages at 1280px and 375px.**
- **html-validate:** only style-preference findings remain (lowercase doctype, Bootstrap `role="presentation"` on tab items, checkboxes sharing one `name`, which is valid HTML).
- **30/30 scripted functional checks pass** (skip link, open/closed logic, empty-submit error summaries on 7 forms, filter engines on 7 pages, newsletter, site search, mobile nav, no horizontal scroll at 375px and no content overlapping the footer on every page, plus site-specific flows). JavaScript errors: 0.

Not done: manual screen reader testing and user testing. Treat the automated results as a baseline, not a conformance claim.

## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `blog-chili-oil-how.html` | How we make our chili oil | Article detail page (child of `blog.html`); article content is original |
| `blog-dumbo-open.html` | Lantern Hand-Pulled opens in DUMBO | Article detail page (child of `blog.html`); article content is original |
| `blog-spice-levels.html` | A guide to our spice levels | Article detail page (child of `blog.html`); article content is original |
| `blog-twenty-years.html` | Twenty years since the first stall | Article detail page (child of `blog.html`); article content is original |
| `blog.html` | Blog | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `careers.html` | Jobs | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `catering.html` | Catering | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Red Lantern Noodle Co. | Xi'an Famous Foods home page |
| `location-chinatown.html` | Red Lantern Chinatown | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-flushing.html` | Red Lantern Flushing | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-hand-pulled-dumbo.html` | Lantern Hand-Pulled, DUMBO | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-hand-pulled-ev.html` | Lantern Hand-Pulled, East Village | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-midtown.html` | Red Lantern Midtown | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-williamsburg.html` | Red Lantern Williamsburg | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `locations.html` | Locations | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `menu.html` | Menu | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `order.html` | Pickup & Delivery | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `our-story.html` | Our Story | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `press.html` | Press | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `rewards.html` | Rewards | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `shop.html` | Shop | Mirrors a Xi'an Famous Foods page or section from the approved source inventory; added features are listed in fidelity-notes.md |
