<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-07 | Category: restaurant (Fast-casual chain) | Source: Sweetgreen https://www.sweetgreen.com/ -->
# Fidelity notes: Fieldbowl ↔ sweetgreen

**Original:** https://www.sweetgreen.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Fieldbowl. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured) | Replica |
|---|---|---|
| Background | Cream `#F4F3E7`; sage `#D8E5D6` and tan `#E8DCC6` bands | Same cream, sage and tan |
| Text and brand | Ink `#0E150E`; deep green `#00473C` (wordmark, button text) | Same ink and deep green |
| Buttons | Lime `#E6FF55` pills (radius 1000px) with deep green text (9.6:1) | Same lime pills and deep green text |
| Type | SweetSans / SweetSansText (proprietary), Grenette | **DM Sans** (OFL), a clean geometric sans with similar proportions |
| Header | Sticky cream bar: hamburger left, lowercase wordmark center, "ORDER →" right; top "Enable Accessibility" link | Same split layout (hamburger, centered lowercase "fieldbowl", Order →); a deep-green utility bar holds Our Menu / Our Mission / Fundraising |
| Menu carousel | Menu-item carousel with arrow images | Scroll-snap card slider with labeled previous/next buttons |
| Cookie dialog | "Manage Cookie Preferences" overlay with Accept all / Reject all / Manage | Non-modal banner with Accept all / Reject / Manage and a preferences dialog |

## Mirrored structure
- **Primary actions:** Our Menu, Order, Locations, Outpost (office delivery), Catering, Fundraising, Rewards, Our Mission.
- **Menu:** category tabs, allergen labels and a "high protein" label.
- **Location pages:** hours and pickup / delivery / dine-in services.
- **Request a location:** a two-step form ("Let us know").
- **Four-column footer:** About us, Services, Support, Legal/social.

## Adapted, added or left out
- **Added:** a bowl builder with a live price and nutrition total, a sortable nutrition and allergen table, ZIP-distance sorting for locations, a Journal with filters, site search and a 404 page.
- **The app download** is described in text instead of linked to app stores.
- **"Enable Accessibility" link not copied:** the site is accessible by default instead of offering an opt-in mode.

## Observations on the original that were not copied
1. The home page `h1` is the wordmark "sweetgreen" at 16px, the same size as body text.
2. The cookie dialog covers most of the first screen on a narrow window, and dismissing it is required to read the page.
3. An "Enable Accessibility" toggle suggests the default experience is not accessible.


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `build.html` | Build a Bowl | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `careers.html` | Careers | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `catering.html` | Catering | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `fundraising.html` | Fundraising | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `gift-cards.html` | Gift Cards | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Fieldbowl | Sweetgreen home page |
| `journal-harvest-bowl-returns.html` | The Harvest Bowl is back | Article detail page (child of `journal.html`); article content is original |
| `journal-our-farm-partners.html` | Meet our farm partners | Article detail page (child of `journal.html`); article content is original |
| `journal-protein-guide.html` | A guide to high-protein bowls | Article detail page (child of `journal.html`); article content is original |
| `journal-school-fundraising.html` | Raising $250,000 for school gardens | Article detail page (child of `journal.html`); article content is original |
| `journal.html` | Journal | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-crossroads.html` | Fieldbowl Crossroads | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-east-village.html` | Fieldbowl East Village | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-fulton.html` | Fieldbowl Fulton Market | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-loop.html` | Fieldbowl The Loop | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-north-loop.html` | Fieldbowl North Loop | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-st-paul.html` | Fieldbowl Lowertown | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-third-ward.html` | Fieldbowl Third Ward | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-uptown-mn.html` | Fieldbowl Uptown | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `locations.html` | Locations | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `menu.html` | Our Menu | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `mission.html` | Our Mission | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `nutrition.html` | Nutrition & Allergens | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `order.html` | Order | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `outpost.html` | Outpost | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `rewards.html` | Rewards | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
