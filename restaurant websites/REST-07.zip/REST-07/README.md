# REST-07: Fieldbowl

## Protocol record (WEB-REPLICA-V1.0)

| Field | Value |
|---|---|
| Replica ID | REST-07 |
| Category | restaurant: Fast-casual chain |
| Fictional branding | Fieldbowl (fictional business; 555 phone numbers, `.example` email) |
| Approved source | Sweetgreen, https://www.sweetgreen.com/ |
| Source verification | Live status verified 2026-11-06 by web search during Phase A; source approved by Isaac. Visual design (colors, fonts, spacing, header and button styles) measured from computed styles in a desktop browser, 2026-11-06/07. |
| Run locally | Open `index.html` in a browser. No server, build step or network is needed. |
| Layout | `*.html` pages, `css/styles.css`, `js/main.js`, `assets/` (images, fonts, vendor/bootstrap, vendor/jquery), `README.md`, `fidelity-notes.md`, `component-inventory.json` |
| Deviations | The protocol prohibits both libraries below. Both were included by Isaac's decision on 2026-11-07; see fidelity-notes.md. **Bootstrap 5.3.3**, stored locally, is used for layout and components. **jQuery 3.7.1**, stored locally, is loaded on every page, but the site's own code does not call it. |

### Sample data

| Data | Count |
|---|---|
| Locations with hours | 8 |
| Menu items (menu pages) | 18 |
| Blog / news / story articles | 4 |
| Site-search index entries | 56 |
| Demo gift card numbers | 2 |

### Quality-control gates

| Gate | Result |
|---|---|
| 13. Technology | **Fail (documented deviations):** Bootstrap 5.3.3 is used, and jQuery 3.7.1 is loaded on every page but not called by the site's code. **Pass:** no other framework or library, no PHP, no backend, no build step, and no remote runtime dependencies (automated scan of every page). |
| 14. Completeness | **Pass:** all 32 pages and the 3 required documents are present. Automated link audit of every `href`/`src` in the HTML, every `url()` in the CSS and every `.html` reference in the JS: 0 broken. |
| 15. Structure | **Pass (automated):** every page has `header`, a labeled `nav`, `main` and `footer` carrying `data-section`; there are 1148 `data-component` instances. The region hierarchy was compared with the source during the build (see fidelity-notes.md); there was no independent review. |
| 16. Interaction | **Pass:** 31/31 scripted Playwright checks (forms, filters, search, navigation and site-specific flows). Simulated flows say they are demos. `href="#"` placeholders: 0. |
| 17. Accessibility review | **Automated pass:** axe-core 4.14 found 0 violations on all 32 pages at 1280px and 375px. Also checked by script: no horizontal scroll at 375px and no content overlapping the footer. **Not tested:** manual keyboard walkthrough, screen readers, 200% text zoom, and reduced-motion behavior (implemented in CSS/JS but not exercised). |
| 18. Traceability | **Pass:** this README, fidelity-notes.md and component-inventory.json were generated from the delivered files. `component-inventory.json` records which components a script exercised and which were not tested. |
| 19. Scope | **Pass, with additions:** the intentional additions (FAQ, site search, 404 and others) are labeled in the page mapping and in fidelity-notes.md. |

Automated results support a WCAG 2.2 AA–oriented baseline. They do not prove conformance.

---

## About Fieldbowl

**Fieldbowl** is a fictional fast-casual salad and bowl chain. This static website mirrors the *structure and visual language* of a real restaurant website, [sweetgreen](https://www.sweetgreen.com/): its page set, layout regions, navigation pattern, interactive features, color palette and typographic style. All names, copy, prices, people and addresses are invented, and all images are labeled placeholders. It is built as a clean **WCAG 2.2 AA baseline** for accessibility and usability research.

> Not a real business. Phone numbers use the 555 range, and email addresses use the reserved `.example` domain.

## Run it
You don't need a server, a build step or an internet connection. Unzip the folder and open `index.html` in a browser. Bootstrap and the fonts are stored locally. You can also serve the folder with any static server (for example `python3 -m http.server`) if a testing tool needs `http://` URLs.

## Stack
- HTML5, CSS3 and vanilla JavaScript (one IIFE in `js/main.js`, ES5-compatible, no modules).
- Bootstrap 5.3.3 (CSS and bundle JS), stored in `assets/vendor/bootstrap/`.
- Fonts: DM Sans (`@fontsource/dm-sans`, SIL Open Font License). Stored in `assets/fonts/` with their licenses.
- jQuery 3.7.1, stored in `assets/vendor/jquery/` and loaded on every page before Bootstrap, so `jQuery` / `$` are available (for example to test tools or scripts). The site's own behavior in `js/main.js` is vanilla JavaScript and does not call it.
- **Not used:** PHP, React or any other framework, build tools, databases, APIs, cookies or analytics.
- **Shared header and footer:** these are copied in full into every HTML file, so the raw source of each page matches what the browser renders. To change the navigation, find-and-replace the same block in all `*.html` files.

## Pages (32)
| File | Title |
|---|---|
| `404.html` | Page not found |
| `accessibility.html` | Accessibility |
| `build.html` | Build a Bowl |
| `careers.html` | Careers |
| `catering.html` | Catering |
| `contact.html` | Contact |
| `faq.html` | FAQ |
| `fundraising.html` | Fundraising |
| `gift-cards.html` | Gift Cards |
| `index.html` | Fieldbowl |
| `journal-harvest-bowl-returns.html` | The Harvest Bowl is back |
| `journal-our-farm-partners.html` | Meet our farm partners |
| `journal-protein-guide.html` | A guide to high-protein bowls |
| `journal-school-fundraising.html` | Raising $250,000 for school gardens |
| `journal.html` | Journal |
| `location-crossroads.html` | Fieldbowl Crossroads |
| `location-east-village.html` | Fieldbowl East Village |
| `location-fulton.html` | Fieldbowl Fulton Market |
| `location-loop.html` | Fieldbowl The Loop |
| `location-north-loop.html` | Fieldbowl North Loop |
| `location-st-paul.html` | Fieldbowl Lowertown |
| `location-third-ward.html` | Fieldbowl Third Ward |
| `location-uptown-mn.html` | Fieldbowl Uptown |
| `locations.html` | Locations |
| `menu.html` | Our Menu |
| `mission.html` | Our Mission |
| `nutrition.html` | Nutrition & Allergens |
| `order.html` | Order |
| `outpost.html` | Outpost |
| `privacy.html` | Privacy |
| `rewards.html` | Rewards |
| `search.html` | Search |

Assets: `css/styles.css` (shared structure, then this site's palette, fonts and flourishes), `js/main.js` (site data: hours, demo values, search index; then all behavior), `assets/img/*.svg` (labeled placeholders).

## Annotation conventions
- `data-section="…"` marks every layout region (header, utility bar, hero, page header, body bands, sidebar, footer).
- `data-component="…"` marks every interactive or repeated component. There are 67 types; see `component-inventory.json` for descriptions, counts and the pages each appears on.
- `data-form="…"` names each form's simulated handler (`booking`, `order`, `checkout`, `gift-card`, `gift-balance`, `newsletter`, `generic`).
- `data-filter-item`, `data-filter`, `data-filter-btn` and `data-sort` drive the shared client-side filtering engine.

## Simulated backend behavior
| Feature | What happens |
|---|---|
| Menu | Eight category tabs; allergen exclusion filters (nuts, dairy, gluten, soy, fish) plus a High protein filter and search. |
| Build a Bowl | Choose a base, up to four toppings, a premium protein and a dressing. The live total shows price, calories and protein; the bowl goes into the order bag. |
| Order | Location, pickup or delivery ($3.99), time from the store's hours, bag with steppers; success shows an order number. |
| Locations | Search by name, city or ZIP (a 5-digit ZIP sorts stores by ZIP distance), filter by state and service. Eight store pages. |
| Fundraising, Outpost, catering, contact | Validated forms; fundraising is a 2-step form. |
| Cookie consent | Accept all / Reject / Manage dialog; choice kept in `sessionStorage`. |

## Testing aids
- **`?demo-time=YYYY-MM-DDTHH:MM`** on any page forces the restaurant's local time (America/Chicago), so you can test the open/closed badges.
- **Reset state:** close the tab, or run `sessionStorage.clear()` in the console. The cart, order bag and dismissed banners all live in `sessionStorage`.
- **ZIP sorting:** `locations.html?q=60606` lists the Chicago stores first.

## Accessibility baseline (WCAG 2.2 AA)
- **Structure:** skip link; labeled landmarks; one `h1` per page.
- **Focus:** a visible 3px focus outline. `scroll-padding-top` follows the sticky header's height so focused items are never hidden behind it (2.4.11).
- **Targets and contrast:** targets are at least 24×24px (2.5.8). Text contrast is at least 4.5:1, and form borders and focus indicators at least 3:1.
- **Forms:** visible labels and `autocomplete` tokens. Errors appear inline, linked by `aria-describedby` and marked `aria-invalid`. An error summary takes focus on submit. Required and optional fields are stated.
- **Live updates:** filter result counts are announced through polite live regions.
- **Moving content:** carousels and tickers have pause buttons, and don't autoplay when the user prefers reduced motion (2.2.2).
- **Status badges:** use text, not color alone.
- **Help:** contact help is in the same place on every page (3.2.6).

Automated results at delivery:
- **axe-core 4.14.0** (tags `wcag2a/aa, wcag21a/aa, wcag22aa, best-practice`): **0 violations across 32 pages at 1280px and 375px.**
- **html-validate:** only style-preference findings remain (lowercase doctype, Bootstrap `role="presentation"` on tab items, checkboxes sharing one `name`, which is valid HTML).
- **31/31 scripted functional checks pass** (skip link, open/closed logic, empty-submit error summaries on 9 forms, filter engines on 5 pages, newsletter, site search, mobile nav, no horizontal scroll at 375px and no content overlapping the footer on every page, plus site-specific flows). JavaScript errors: 0.

Not done: manual screen reader testing and user testing. Treat the automated results as a baseline, not a conformance claim.

## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `build.html` | Build a Bowl | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `careers.html` | Careers | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `catering.html` | Catering | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `fundraising.html` | Fundraising | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `gift-cards.html` | Gift Cards | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Fieldbowl | Sweetgreen home page |
| `journal-harvest-bowl-returns.html` | The Harvest Bowl is back | Article detail page (child of `journal.html`); article content is original |
| `journal-our-farm-partners.html` | Meet our farm partners | Article detail page (child of `journal.html`); article content is original |
| `journal-protein-guide.html` | A guide to high-protein bowls | Article detail page (child of `journal.html`); article content is original |
| `journal-school-fundraising.html` | Raising $250,000 for school gardens | Article detail page (child of `journal.html`); article content is original |
| `journal.html` | Journal | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-crossroads.html` | Fieldbowl Crossroads | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-east-village.html` | Fieldbowl East Village | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-fulton.html` | Fieldbowl Fulton Market | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-loop.html` | Fieldbowl The Loop | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-north-loop.html` | Fieldbowl North Loop | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-st-paul.html` | Fieldbowl Lowertown | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-third-ward.html` | Fieldbowl Third Ward | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-uptown-mn.html` | Fieldbowl Uptown | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `locations.html` | Locations | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `menu.html` | Our Menu | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `mission.html` | Our Mission | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `nutrition.html` | Nutrition & Allergens | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `order.html` | Order | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `outpost.html` | Outpost | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `rewards.html` | Rewards | Mirrors a Sweetgreen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
