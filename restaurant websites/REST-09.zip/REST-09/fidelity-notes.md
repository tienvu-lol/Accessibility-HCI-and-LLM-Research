<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-09 | Category: restaurant (Brewery / brewpub (age gate)) | Source: Russian River Brewing Company https://www.russianriverbrewing.com/ -->
# Fidelity notes: Alder Creek Brewing ↔ Russian River Brewing Company

**Original:** https://www.russianriverbrewing.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Alder Creek Brewing. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured) | Replica |
|---|---|---|
| Background and text | White; body Poppins 18px `#333` | Same: white, Poppins (OFL) at 17px, `#333` (12.6:1) |
| Navigation bar | Slate blue `#335B6D` with white uppercase Poppins links | Same slate bar and white uppercase links (7.4:1) |
| Buttons | Gold `#FFBC13`, square, black text ("Find Beer", "Shop Online") | Same gold, square, black text (12.5:1) |
| Bands | Light grey `#EEEEEE` | Same grey alternating bands |
| Accent type | "Talk to the hand" handwritten script | **Caveat** (OFL) for the small "Thirsty?" accent |
| Hero | Swiper image slider | Bootstrap carousel with a pause button |
| Age gate | Present; "No" redirects to an external video site | Accessible modal dialog; "No" shows an in-page refusal message |

## Mirrored structure
- **Navigation:** the two locations as menus (Visit, To-Go, Pub Menu, Tours, Private Events), Our Brews, Find Our Beer, Store, and About (Our Story, Events, Careers, Blog/News).
- **Home page:** hero slider and "Get Some" cards with Find Beer / Shop Online buttons.
- **Group rules:** reservations for larger parties, Private Events for the largest.
- **Hillside:** tours and nearby lodging.
- **Footer:** newsletter, about/shop columns and an accessibility statement link.

## Adapted, added or left out
- **Added:** tap-list filters (pub, style, ABV range, format) and ABV sort, beer detail dialogs, a ZIP-sorted store finder, tour booking that rejects weekdays, a to-go bag with a 21+ confirmation, an events filter, News with categories, FAQ, site search and a 404 page.
- **The original's "screen-reader mode" toggle is not copied;** the site works with screen readers by default.

## Observations on the original that were not copied
1. Answering "No" on the age gate sends the visitor to an external video site instead of explaining why access is refused.
2. The home page has no `h1`; the first heading is an `h2` ("Get Some") at 16px.
3. A separate "screen-reader mode" link implies the default page is not fully accessible.


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | Our Story | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `blog-barrel-room.html` | Inside the barrel room | Article detail page (child of `blog.html`); article content is original |
| `blog-find-beer-update.html` | Where to find Alder Creek beer | Article detail page (child of `blog.html`); article content is original |
| `blog-hillside-patio.html` | The Hillside patio is open year-round | Article detail page (child of `blog.html`); article content is original |
| `blog-triple-redwood-release.html` | Triple Redwood release dates | Article detail page (child of `blog.html`); article content is original |
| `blog.html` | News | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `careers.html` | Careers | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `events.html` | Events | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `find-our-beer.html` | Find Our Beer | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `gift-cards.html` | Gift Certificates | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Alder Creek Brewing | Russian River Brewing Company home page |
| `on-tap.html` | On Tap | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `our-brews.html` | Our Brews | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `private-events.html` | Private Events | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `pub-menu.html` | Pub Menu | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `reservations.html` | Large-Party Reservations | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `store.html` | Store | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `to-go.html` | To-Go Order | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `tours.html` | Brewery Tours | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `visit-hillside.html` | Hillside Brewery & Pub | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `visit-old-town.html` | Old Town Brewpub | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
