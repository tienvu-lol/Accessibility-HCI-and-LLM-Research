# REST-09: Alder Creek Brewing

## Protocol record (WEB-REPLICA-V1.0)

| Field | Value |
|---|---|
| Replica ID | REST-09 |
| Category | restaurant: Brewery / brewpub (age gate) |
| Fictional branding | Alder Creek Brewing (fictional business; 555 phone numbers, `.example` email) |
| Approved source | Russian River Brewing Company, https://www.russianriverbrewing.com/ |
| Source verification | Live status verified 2026-11-06 by web search during Phase A; source approved by Isaac. Visual design (colors, fonts, spacing, header and button styles) measured from computed styles in a desktop browser, 2026-11-06/07. |
| Run locally | Open `index.html` in a browser. No server, build step or network is needed. |
| Layout | `*.html` pages, `css/styles.css`, `js/main.js`, `assets/` (images, fonts, vendor/bootstrap, vendor/jquery), `README.md`, `fidelity-notes.md`, `component-inventory.json` |
| Deviations | The protocol prohibits both libraries below. Both were included by Isaac's decision on 2026-11-07; see fidelity-notes.md. **Bootstrap 5.3.3**, stored locally, is used for layout and components. **jQuery 3.7.1**, stored locally, is loaded on every page, but the site's own code does not call it. |

### Sample data

| Data | Count |
|---|---|
| Locations with hours | 2 |
| Menu items (menu pages) | 11 |
| Blog / news / story articles | 4 |
| Products | 4 |
| Site-search index entries | 56 |
| Demo gift card numbers | 2 |

### Quality-control gates

| Gate | Result |
|---|---|
| 13. Technology | **Fail (documented deviations):** Bootstrap 5.3.3 is used, and jQuery 3.7.1 is loaded on every page but not called by the site's code. **Pass:** no other framework or library, no PHP, no backend, no build step, and no remote runtime dependencies (automated scan of every page). |
| 14. Completeness | **Pass:** all 27 pages and the 3 required documents are present. Automated link audit of every `href`/`src` in the HTML, every `url()` in the CSS and every `.html` reference in the JS: 0 broken. |
| 15. Structure | **Pass (automated):** every page has `header`, a labeled `nav`, `main` and `footer` carrying `data-section`; there are 1048 `data-component` instances. The region hierarchy was compared with the source during the build (see fidelity-notes.md); there was no independent review. |
| 16. Interaction | **Pass:** 37/37 scripted Playwright checks (forms, filters, search, navigation and site-specific flows). Simulated flows say they are demos. `href="#"` placeholders: 0. |
| 17. Accessibility review | **Automated pass:** axe-core 4.14 found 0 violations on all 27 pages at 1280px and 375px. Also checked by script: no horizontal scroll at 375px and no content overlapping the footer. **Not tested:** manual keyboard walkthrough, screen readers, 200% text zoom, and reduced-motion behavior (implemented in CSS/JS but not exercised). |
| 18. Traceability | **Pass:** this README, fidelity-notes.md and component-inventory.json were generated from the delivered files. `component-inventory.json` records which components a script exercised and which were not tested. |
| 19. Scope | **Pass, with additions:** the intentional additions (FAQ, site search, 404 and others) are labeled in the page mapping and in fidelity-notes.md. |

Automated results support a WCAG 2.2 AA–oriented baseline. They do not prove conformance.

---

## About Alder Creek Brewing

**Alder Creek Brewing** is a fictional craft brewery with two brewpubs. This static website mirrors the *structure and visual language* of a real restaurant website, [Russian River Brewing Company](https://www.russianriverbrewing.com/): its page set, layout regions, navigation pattern, interactive features, color palette and typographic style. All names, copy, prices, people and addresses are invented, and all images are labeled placeholders. It is built as a clean **WCAG 2.2 AA baseline** for accessibility and usability research.

> Not a real business. Phone numbers use the 555 range, and email addresses use the reserved `.example` domain.

## Run it
You don't need a server, a build step or an internet connection. Unzip the folder and open `index.html` in a browser. Bootstrap and the fonts are stored locally. You can also serve the folder with any static server (for example `python3 -m http.server`) if a testing tool needs `http://` URLs.

## Stack
- HTML5, CSS3 and vanilla JavaScript (one IIFE in `js/main.js`, ES5-compatible, no modules).
- Bootstrap 5.3.3 (CSS and bundle JS), stored in `assets/vendor/bootstrap/`.
- Fonts: Poppins (`@fontsource/poppins`, SIL Open Font License), Caveat (`@fontsource/caveat`, SIL Open Font License). Stored in `assets/fonts/` with their licenses.
- jQuery 3.7.1, stored in `assets/vendor/jquery/` and loaded on every page before Bootstrap, so `jQuery` / `$` are available (for example to test tools or scripts). The site's own behavior in `js/main.js` is vanilla JavaScript and does not call it.
- **Not used:** PHP, React or any other framework, build tools, databases, APIs, cookies or analytics.
- **Shared header and footer:** these are copied in full into every HTML file, so the raw source of each page matches what the browser renders. To change the navigation, find-and-replace the same block in all `*.html` files.

## Pages (27)
| File | Title |
|---|---|
| `404.html` | Page not found |
| `about.html` | Our Story |
| `accessibility.html` | Accessibility |
| `blog-barrel-room.html` | Inside the barrel room |
| `blog-find-beer-update.html` | Where to find Alder Creek beer |
| `blog-hillside-patio.html` | The Hillside patio is open year-round |
| `blog-triple-redwood-release.html` | Triple Redwood release dates |
| `blog.html` | News |
| `careers.html` | Careers |
| `contact.html` | Contact |
| `events.html` | Events |
| `faq.html` | FAQ |
| `find-our-beer.html` | Find Our Beer |
| `gift-cards.html` | Gift Certificates |
| `index.html` | Alder Creek Brewing |
| `on-tap.html` | On Tap |
| `our-brews.html` | Our Brews |
| `privacy.html` | Privacy |
| `private-events.html` | Private Events |
| `pub-menu.html` | Pub Menu |
| `reservations.html` | Large-Party Reservations |
| `search.html` | Search |
| `store.html` | Store |
| `to-go.html` | To-Go Order |
| `tours.html` | Brewery Tours |
| `visit-hillside.html` | Hillside Brewery & Pub |
| `visit-old-town.html` | Old Town Brewpub |

Assets: `css/styles.css` (shared structure, then this site's palette, fonts and flourishes), `js/main.js` (site data: hours, demo values, search index; then all behavior), `assets/img/*.svg` (labeled placeholders).

## Annotation conventions
- `data-section="…"` marks every layout region (header, utility bar, hero, page header, body bands, sidebar, footer).
- `data-component="…"` marks every interactive or repeated component. There are 72 types; see `component-inventory.json` for descriptions, counts and the pages each appears on.
- `data-form="…"` names each form's simulated handler (`booking`, `order`, `checkout`, `gift-card`, `gift-balance`, `newsletter`, `generic`).
- `data-filter-item`, `data-filter`, `data-filter-btn` and `data-sort` drive the shared client-side filtering engine.

## Simulated backend behavior
| Feature | What happens |
|---|---|
| Age gate | A modal dialog appears on the first visit. Yes stores the answer in `sessionStorage`; No shows a refusal message and keeps the site blocked. |
| On Tap | Filter by pub, style, ABV range and format (draft, bottle, can), and sort by ABV. |
| Our Brews | Catalog with search and style filter; each beer has a detail dialog. |
| Find Our Beer | Search eight fictional retailers by city or ZIP (a ZIP sorts by distance). |
| Tours | Saturday and Sunday hourly slots (weekdays rejected), up to 10 guests. Confirmation dialog and `.ics` file. |
| Large-party reservations | Parties of up to 16; larger groups are sent to Private Events. |
| To-Go and Store | Food and beer bag (to-go requires 21+ confirmation) and a merchandise cart with checkout. |

## Testing aids
- **`?demo-time=YYYY-MM-DDTHH:MM`** on any page forces the restaurant's local time (America/Los_Angeles), so you can test the open/closed badges.
- **Reset state:** close the tab, or run `sessionStorage.clear()` in the console. The cart, order bag and dismissed banners all live in `sessionStorage`.
- **Age gate:** add `?age-gate=show` to any URL to show the dialog again, or clear `sessionStorage`.

## Accessibility baseline (WCAG 2.2 AA)
- **Structure:** skip link; labeled landmarks; one `h1` per page.
- **Focus:** a visible 3px focus outline. `scroll-padding-top` follows the sticky header's height so focused items are never hidden behind it (2.4.11).
- **Targets and contrast:** targets are at least 24×24px (2.5.8). Text contrast is at least 4.5:1, and form borders and focus indicators at least 3:1.
- **Forms:** visible labels and `autocomplete` tokens. Errors appear inline, linked by `aria-describedby` and marked `aria-invalid`. An error summary takes focus on submit. Required and optional fields are stated.
- **Live updates:** filter result counts are announced through polite live regions.
- **Moving content:** carousels and tickers have pause buttons, and don't autoplay when the user prefers reduced motion (2.2.2).
- **Status badges:** use text, not color alone.
- **Help:** contact help is in the same place on every page (3.2.6).
- **Age gate:** a labeled modal dialog. Focus stays inside it, Escape doesn't dismiss it, and "No" shows a refusal message instead of redirecting to another site.
Automated results at delivery:
- **axe-core 4.14.0** (tags `wcag2a/aa, wcag21a/aa, wcag22aa, best-practice`): **0 violations across 27 pages at 1280px and 375px.**
- **html-validate:** only style-preference findings remain (lowercase doctype, Bootstrap `role="presentation"` on tab items, checkboxes sharing one `name`, which is valid HTML).
- **37/37 scripted functional checks pass** (skip link, open/closed logic, empty-submit error summaries on 8 forms, filter engines on 9 pages, newsletter, site search, mobile nav, no horizontal scroll at 375px and no content overlapping the footer on every page, plus site-specific flows). JavaScript errors: 0.

Not done: manual screen reader testing and user testing. Treat the automated results as a baseline, not a conformance claim.

## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | Our Story | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `blog-barrel-room.html` | Inside the barrel room | Article detail page (child of `blog.html`); article content is original |
| `blog-find-beer-update.html` | Where to find Alder Creek beer | Article detail page (child of `blog.html`); article content is original |
| `blog-hillside-patio.html` | The Hillside patio is open year-round | Article detail page (child of `blog.html`); article content is original |
| `blog-triple-redwood-release.html` | Triple Redwood release dates | Article detail page (child of `blog.html`); article content is original |
| `blog.html` | News | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `careers.html` | Careers | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `events.html` | Events | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `find-our-beer.html` | Find Our Beer | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `gift-cards.html` | Gift Certificates | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Alder Creek Brewing | Russian River Brewing Company home page |
| `on-tap.html` | On Tap | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `our-brews.html` | Our Brews | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `private-events.html` | Private Events | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `pub-menu.html` | Pub Menu | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `reservations.html` | Large-Party Reservations | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `store.html` | Store | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `to-go.html` | To-Go Order | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `tours.html` | Brewery Tours | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `visit-hillside.html` | Hillside Brewery & Pub | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `visit-old-town.html` | Old Town Brewpub | Mirrors a Russian River Brewing Company page or section from the approved source inventory; added features are listed in fidelity-notes.md |
