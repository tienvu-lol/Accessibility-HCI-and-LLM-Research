<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-06 | Category: restaurant (Pizzeria) | Source: Pizzeria Bianco https://www.pizzeriabianco.com/ -->
# Fidelity notes: Fornace Rossa ↔ Pizzeria Bianco

**Original:** https://pizzeriabianco.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Fornace Rossa. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured) | Replica |
|---|---|---|
| Page | Off-white `#EEEEE7`, black text | Same off-white, near-black text |
| Header | Fixed charcoal `#2A2829` at 90% opacity, letter-spaced wordmark "BIANCO", hamburger | Sticky charcoal header (97% opacity), letter-spaced wordmark "FORNACE", hamburger opening a full-screen charcoal menu grouped by city |
| Announcement bar | Dismissable bar above the header (Halloween closing notice) | Same pattern, with a labeled dismiss button that is remembered for the session |
| Headings | Futura PT bold, uppercase, 0.04em spacing | **Jost** (OFL, geometric like Futura) bold, uppercase, same spacing |
| Buttons | Square orange `#D35F13`, white text (3.9:1), "Hours & Menu →" | Square orange `#B84F0C` (white 5.1:1) with an offset black shadow; same wording |
| Restaurant list | Grouped by city: name, address // phone, orange button per location | Same layout and the same "//" separator, plus a live open/closed badge |

## Mirrored structure
- **Navigation:** restaurants grouped by city (Phoenix: the pizzeria, a second pizzeria and the bar; Los Angeles), About (the founder, Collaborations, Press, Events), Shop (Shop, Ship pizzas, Gift Cards).
- **Home page:** announcement bar; storefront hero; "Our Restaurants" list with per-location "Hours & Menu" or "Hours, Menu & Reservations" buttons; "Ship pizzas" promo.
- **Reservations only at some locations;** others are walk-in only.
- **Gift card balance** link in the footer.

## Adapted, added or left out
- **Added:** menu tabs with dietary filters, a reservation form limited to the bookable locations, location pages with live badges in each city's time zone, an event filter and ticket form, a News blog, FAQ, site search and a 404 page.
- **Left out:** external shop and reservation platforms, replaced by on-site simulations.

## Observations on the original that were not copied
1. White text on the orange `#D35F13` buttons: 3.9:1, below 4.5:1.
2. The home page has no `h1`; the first heading is "Our Restaurants" (`h2`).
3. Six location buttons share the same few labels ("Hours & Menu →") without saying which restaurant they belong to.


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | Luca Ferraro | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `blog-halloween-hours.html` | Halloween hours in Los Angeles | Article detail page (child of `blog.html`); article content is original |
| `blog-heritage-wheat.html` | Growing heritage wheat in the desert | Article detail page (child of `blog.html`); article content is original |
| `blog-la-anniversary.html` | Three years in Los Angeles | Article detail page (child of `blog.html`); article content is original |
| `blog-tomato-season.html` | Tomato season | Article detail page (child of `blog.html`); article content is original |
| `blog.html` | News | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `collaborations.html` | Collaborations | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `events.html` | Events | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Fornace Rossa | Pizzeria Bianco home page |
| `location-bar.html` | Bar Fornace | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-biltmore.html` | Fornace Rossa Biltmore Commons | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-downtown.html` | Fornace Rossa Heritage Square | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-la.html` | Fornace Rossa Los Angeles | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `menu.html` | Menu | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `press.html` | Press | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `reservations.html` | Reservations | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurants.html` | All Restaurants | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `ship-pizzas.html` | Ship Pizzas | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `shop.html` | Shop | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
