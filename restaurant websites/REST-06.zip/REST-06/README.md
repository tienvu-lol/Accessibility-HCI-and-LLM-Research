# REST-06: Fornace Rossa

## Protocol record (WEB-REPLICA-V1.0)

| Field | Value |
|---|---|
| Replica ID | REST-06 |
| Category | restaurant: Pizzeria |
| Fictional branding | Fornace Rossa (fictional business; 555 phone numbers, `.example` email) |
| Approved source | Pizzeria Bianco, https://www.pizzeriabianco.com/ |
| Source verification | Live status verified 2026-11-06 by web search during Phase A; source approved by Isaac. Visual design (colors, fonts, spacing, header and button styles) measured from computed styles in a desktop browser, 2026-11-06/07. |
| Run locally | Open `index.html` in a browser. No server, build step or network is needed. |
| Layout | `*.html` pages, `css/styles.css`, `js/main.js`, `assets/` (images, fonts, vendor/bootstrap, vendor/jquery), `README.md`, `fidelity-notes.md`, `component-inventory.json` |
| Deviations | The protocol prohibits both libraries below. Both were included by Isaac's decision on 2026-11-07; see fidelity-notes.md. **Bootstrap 5.3.3**, stored locally, is used for layout and components. **jQuery 3.7.1**, stored locally, is loaded on every page, but the site's own code does not call it. |

### Sample data

| Data | Count |
|---|---|
| Locations with hours | 4 |
| Menu items (menu pages) | 16 |
| Blog / news / story articles | 4 |
| Products | 6 |
| Site-search index entries | 51 |
| Demo gift card numbers | 2 |

### Quality-control gates

| Gate | Result |
|---|---|
| 13. Technology | **Fail (documented deviations):** Bootstrap 5.3.3 is used, and jQuery 3.7.1 is loaded on every page but not called by the site's code. **Pass:** no other framework or library, no PHP, no backend, no build step, and no remote runtime dependencies (automated scan of every page). |
| 14. Completeness | **Pass:** all 26 pages and the 3 required documents are present. Automated link audit of every `href`/`src` in the HTML, every `url()` in the CSS and every `.html` reference in the JS: 0 broken. |
| 15. Structure | **Pass (automated):** every page has `header`, a labeled `nav`, `main` and `footer` carrying `data-section`; there are 902 `data-component` instances. The region hierarchy was compared with the source during the build (see fidelity-notes.md); there was no independent review. |
| 16. Interaction | **Partial:** 26/27 scripted Playwright checks (forms, filters, search, navigation and site-specific flows). Simulated flows say they are demos. `href="#"` placeholders: 0. The 1 failing check ('dismissal remembered across pages') tests sessionStorage across page loads. It fails intermittently under headless Chromium on `file://` (the harness quirk described in the testing notes). Run over `http://localhost`, the same checks passed 3 of 3 times with 0 failures. |
| 17. Accessibility review | **Automated pass:** axe-core 4.14 found 0 violations on all 26 pages at 1280px and 375px. Also checked by script: no horizontal scroll at 375px and no content overlapping the footer. **Not tested:** manual keyboard walkthrough, screen readers, 200% text zoom, and reduced-motion behavior (implemented in CSS/JS but not exercised). |
| 18. Traceability | **Pass:** this README, fidelity-notes.md and component-inventory.json were generated from the delivered files. `component-inventory.json` records which components a script exercised and which were not tested. |
| 19. Scope | **Pass, with additions:** the intentional additions (FAQ, site search, 404 and others) are labeled in the page mapping and in fidelity-notes.md. |

Automated results support a WCAG 2.2 AA–oriented baseline. They do not prove conformance.

---

## About Fornace Rossa

**Fornace Rossa** is a fictional wood-fired pizzeria with locations in Phoenix and Los Angeles. This static website mirrors the *structure and visual language* of a real restaurant website, [Pizzeria Bianco](https://pizzeriabianco.com/): its page set, layout regions, navigation pattern, interactive features, color palette and typographic style. All names, copy, prices, people and addresses are invented, and all images are labeled placeholders. It is built as a clean **WCAG 2.2 AA baseline** for accessibility and usability research.

> Not a real business. Phone numbers use the 555 range, and email addresses use the reserved `.example` domain.

## Run it
You don't need a server, a build step or an internet connection. Unzip the folder and open `index.html` in a browser. Bootstrap and the fonts are stored locally. You can also serve the folder with any static server (for example `python3 -m http.server`) if a testing tool needs `http://` URLs.

## Stack
- HTML5, CSS3 and vanilla JavaScript (one IIFE in `js/main.js`, ES5-compatible, no modules).
- Bootstrap 5.3.3 (CSS and bundle JS), stored in `assets/vendor/bootstrap/`.
- Fonts: Jost (`@fontsource/jost`, SIL Open Font License). Stored in `assets/fonts/` with their licenses.
- jQuery 3.7.1, stored in `assets/vendor/jquery/` and loaded on every page before Bootstrap, so `jQuery` / `$` are available (for example to test tools or scripts). The site's own behavior in `js/main.js` is vanilla JavaScript and does not call it.
- **Not used:** PHP, React or any other framework, build tools, databases, APIs, cookies or analytics.
- **Shared header and footer:** these are copied in full into every HTML file, so the raw source of each page matches what the browser renders. To change the navigation, find-and-replace the same block in all `*.html` files.

## Pages (26)
| File | Title |
|---|---|
| `404.html` | Page not found |
| `about.html` | Luca Ferraro |
| `accessibility.html` | Accessibility |
| `blog-halloween-hours.html` | Halloween hours in Los Angeles |
| `blog-heritage-wheat.html` | Growing heritage wheat in the desert |
| `blog-la-anniversary.html` | Three years in Los Angeles |
| `blog-tomato-season.html` | Tomato season |
| `blog.html` | News |
| `collaborations.html` | Collaborations |
| `contact.html` | Contact |
| `events.html` | Events |
| `faq.html` | FAQ |
| `gift-cards.html` | Gift Cards |
| `index.html` | Fornace Rossa |
| `location-bar.html` | Bar Fornace |
| `location-biltmore.html` | Fornace Rossa Biltmore Commons |
| `location-downtown.html` | Fornace Rossa Heritage Square |
| `location-la.html` | Fornace Rossa Los Angeles |
| `menu.html` | Menu |
| `press.html` | Press |
| `privacy.html` | Privacy |
| `reservations.html` | Reservations |
| `restaurants.html` | All Restaurants |
| `search.html` | Search |
| `ship-pizzas.html` | Ship Pizzas |
| `shop.html` | Shop |

Assets: `css/styles.css` (shared structure, then this site's palette, fonts and flourishes), `js/main.js` (site data: hours, demo values, search index; then all behavior), `assets/img/*.svg` (labeled placeholders).

## Annotation conventions
- `data-section="…"` marks every layout region (header, utility bar, hero, page header, body bands, sidebar, footer).
- `data-component="…"` marks every interactive or repeated component. There are 63 types; see `component-inventory.json` for descriptions, counts and the pages each appears on.
- `data-form="…"` names each form's simulated handler (`booking`, `order`, `checkout`, `gift-card`, `gift-balance`, `newsletter`, `generic`).
- `data-filter-item`, `data-filter`, `data-filter-btn` and `data-sort` drive the shared client-side filtering engine.

## Simulated backend behavior
| Feature | What happens |
|---|---|
| Announcement bar | Dismissable; the choice is remembered for the session. |
| Reservations | Only Biltmore Commons and Los Angeles take bookings; the form says so and lists only those two. |
| Shop and Ship Pizzas | Shared cart and checkout on `shop.html#checkout`. |
| Gift cards | Balance demo: `1234 5678 9012` → $60. |
| Hours | Each location keeps its own time zone (Phoenix doesn't observe daylight saving time; Los Angeles does), so badges are correct for both cities at once. |

## Testing aids
- **`?demo-time=YYYY-MM-DDTHH:MM`** on any page forces the restaurant's local time (America/Phoenix), so you can test the open/closed badges.
- **Reset state:** close the tab, or run `sessionStorage.clear()` in the console. The cart, order bag and dismissed banners all live in `sessionStorage`.
- **Per-location time zones:** at `?demo-time=2026-11-10T20:30`, Phoenix shows closed while Los Angeles (closes 10 PM) shows open. Demo time is read as each location's local time.
- **Announcement bar:** reset its dismissal with `sessionStorage.clear()`.

## Accessibility baseline (WCAG 2.2 AA)
- **Structure:** skip link; labeled landmarks; one `h1` per page.
- **Focus:** a visible 3px focus outline. `scroll-padding-top` follows the sticky header's height so focused items are never hidden behind it (2.4.11).
- **Targets and contrast:** targets are at least 24×24px (2.5.8). Text contrast is at least 4.5:1, and form borders and focus indicators at least 3:1.
- **Forms:** visible labels and `autocomplete` tokens. Errors appear inline, linked by `aria-describedby` and marked `aria-invalid`. An error summary takes focus on submit. Required and optional fields are stated.
- **Live updates:** filter result counts are announced through polite live regions.
- **Moving content:** carousels and tickers have pause buttons, and don't autoplay when the user prefers reduced motion (2.2.2).
- **Status badges:** use text, not color alone.
- **Help:** contact help is in the same place on every page (3.2.6).

Automated results at delivery:
- **axe-core 4.14.0** (tags `wcag2a/aa, wcag21a/aa, wcag22aa, best-practice`): **0 violations across 26 pages at 1280px and 375px.**
- **html-validate:** only style-preference findings remain (lowercase doctype, Bootstrap `role="presentation"` on tab items, checkboxes sharing one `name`, which is valid HTML).
- **26/27 scripted functional checks pass** (the failing check is explained under QC gate 16) (skip link, open/closed logic, empty-submit error summaries on 5 forms, filter engines on 7 pages, newsletter, site search, mobile nav, no horizontal scroll at 375px and no content overlapping the footer on every page, plus site-specific flows). JavaScript errors: 0.

Not done: manual screen reader testing and user testing. Treat the automated results as a baseline, not a conformance claim.

## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | Luca Ferraro | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `blog-halloween-hours.html` | Halloween hours in Los Angeles | Article detail page (child of `blog.html`); article content is original |
| `blog-heritage-wheat.html` | Growing heritage wheat in the desert | Article detail page (child of `blog.html`); article content is original |
| `blog-la-anniversary.html` | Three years in Los Angeles | Article detail page (child of `blog.html`); article content is original |
| `blog-tomato-season.html` | Tomato season | Article detail page (child of `blog.html`); article content is original |
| `blog.html` | News | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `collaborations.html` | Collaborations | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Contact | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `events.html` | Events | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Fornace Rossa | Pizzeria Bianco home page |
| `location-bar.html` | Bar Fornace | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-biltmore.html` | Fornace Rossa Biltmore Commons | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-downtown.html` | Fornace Rossa Heritage Square | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `location-la.html` | Fornace Rossa Los Angeles | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `menu.html` | Menu | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `press.html` | Press | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `reservations.html` | Reservations | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `restaurants.html` | All Restaurants | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `ship-pizzas.html` | Ship Pizzas | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `shop.html` | Shop | Mirrors a Pizzeria Bianco page or section from the approved source inventory; added features are listed in fidelity-notes.md |
