<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-02 | Category: restaurant (BBQ / smokehouse) | Source: Franklin Barbecue https://franklinbbq.com/ -->
# Fidelity notes: Ironline Smokehouse ↔ Franklin Barbecue

**Original:** https://franklinbbq.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Ironline Smokehouse. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured) | Replica |
|---|---|---|
| Page background | `#EFEEDE` cream | Same `#EFEEDE` |
| Headings | Bright orange `#E67437`, condensed display face ("cheap-pine-sans", 50px H1) | Burnt orange `#A8461B` in **Bebas Neue** (OFL). The original orange reaches only 2.6:1 on cream, so it is used only on black (footer headings, 6.2:1) and the footer button. |
| Accent band | Teal `#5DC3BC` band with **white** H3 text (2.1:1) | Same teal band with dark ink `#0F2E2B` text (6.9:1) |
| Script accent | "voltage" script ("Open for lunch 6 days a week") | **Pacifico** (OFL), dark teal on cream |
| Body text | Georgia serif, `#4E4B4E` | Same: Georgia, `#4E4B4E` (7.4:1) |
| Buttons | Orange fill, white text, 20px radius | Burnt-orange fill (white text 5.4:1), same 20px radius |
| Header | Absolute and transparent over the hero tray photo | Fixed transparent overlay on the home page, solid cream once scrolled; solid sticky on inner pages |
| Hero | Full-width tray photo, H1 is a magazine quote | Placeholder tray image as a background, H1 is a fictional magazine quote on a dark panel |
| Cookie consent | Banner with Accept all / Decline all / Manage cookies | Non-modal banner with the same three choices plus a preferences dialog |

## Mirrored structure
- **Navigation:** About, Menu, Private Events, Sauces & Rubs, a "Ship" dropdown (Nationwide Shipping, Merchandise, Sauces & Rubs, Gift Cards), Visit Us, an "Order in Advance" call to action, and the cart.
- **Home page section order:** hero quote; sourcing statement band; location with map; hours "until sold out"; upcoming events and announcements; "Planning to visit?" with a patio photo; photo gallery; sister restaurant; e-gift card block with "Buy Now"; newsletter; footer.
- **Footer blocks:** Restaurant (address and hours), Private Dining Space, Links, phone number, and Facebook, Instagram and YouTube links.
- **Hours model:** "11 AM until sold out", closed Mondays. The live badge says so instead of giving a fixed closing time.

## Adapted, added or left out
- **Added for research coverage:** dietary filters and search on the menu, the advance-order flow with bag and date rules, the checkout, the gift card balance checker, the FAQ, the News & Events blog with filters and pagination, catering, site search, the accessibility statement and the 404 page.
- **Left out:** the embedded Google Map, which is replaced by a placeholder image with a text alternative and directions in text, and external ordering integrations.
- **Duplicate gallery:** the original's gallery markup appears twice in the source. The replica has one gallery, with a pause button.

## Observations on the original that were not copied
1. The newsletter block shows a site-builder setup message ("enter a storage location via the Storage tab"), so signup isn't configured.
2. The H1 and H2 text use orange `#E67437` on cream `#EFEEDE`: 2.6:1, below the 3:1 minimum even for large text.
3. White text on the teal `#5DC3BC` band: 2.1:1.
4. The gallery markup is duplicated in the page source.


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | About | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `blog-holiday-hours-2026.html` | Holiday hours for Thanksgiving and December | Article detail page (child of `blog.html`); article content is original |
| `blog-line-guide.html` | A first-timer's guide to the line | Article detail page (child of `blog.html`); article content is original |
| `blog-new-venue-the-lumberyard.html` | Introducing The Lumberyard, our new event space | Article detail page (child of `blog.html`); article content is original |
| `blog-pitmaster-classes.html` | Pitmaster classes return this spring | Article detail page (child of `blog.html`); article content is original |
| `blog-why-post-oak.html` | Why we only burn post oak | Article detail page (child of `blog.html`); article content is original |
| `blog.html` | News &amp; Events | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `catering.html` | Catering | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `checkout.html` | Checkout | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Visit Us | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Ironline Smokehouse | Franklin Barbecue home page |
| `menu.html` | Menu | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `merchandise.html` | Merchandise | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `order.html` | Order in Advance | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `private-events.html` | Private Events | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `shipping.html` | Nationwide Shipping | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `shop.html` | Sauces & Rubs | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
