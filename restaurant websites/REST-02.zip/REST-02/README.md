# REST-02: Ironline Smokehouse

## Protocol record (WEB-REPLICA-V1.0)

| Field | Value |
|---|---|
| Replica ID | REST-02 |
| Category | restaurant: BBQ / smokehouse |
| Fictional branding | Ironline Smokehouse (fictional business; 555 phone numbers, `.example` email) |
| Approved source | Franklin Barbecue, https://franklinbbq.com/ |
| Source verification | Live status verified 2026-11-06 by web search during Phase A; source approved by Isaac. Visual design (colors, fonts, spacing, header and button styles) measured from computed styles in a desktop browser, 2026-11-06/07. |
| Run locally | Open `index.html` in a browser. No server, build step or network is needed. |
| Layout | `*.html` pages, `css/styles.css`, `js/main.js`, `assets/` (images, fonts, vendor/bootstrap, vendor/jquery), `README.md`, `fidelity-notes.md`, `component-inventory.json` |
| Deviations | The protocol prohibits both libraries below. Both were included by Isaac's decision on 2026-11-07; see fidelity-notes.md. **Bootstrap 5.3.3**, stored locally, is used for layout and components. **jQuery 3.7.1**, stored locally, is loaded on every page, but the site's own code does not call it. |

### Sample data

| Data | Count |
|---|---|
| Locations with hours | 2 |
| Menu items (menu pages) | 17 |
| Blog / news / story articles | 5 |
| Products | 14 |
| Site-search index entries | 60 |
| Demo gift card numbers | 2 |

### Quality-control gates

| Gate | Result |
|---|---|
| 13. Technology | **Fail (documented deviations):** Bootstrap 5.3.3 is used, and jQuery 3.7.1 is loaded on every page but not called by the site's code. **Pass:** no other framework or library, no PHP, no backend, no build step, and no remote runtime dependencies (automated scan of every page). |
| 14. Completeness | **Pass:** all 23 pages and the 3 required documents are present. Automated link audit of every `href`/`src` in the HTML, every `url()` in the CSS and every `.html` reference in the JS: 0 broken. |
| 15. Structure | **Pass (automated):** every page has `header`, a labeled `nav`, `main` and `footer` carrying `data-section`; there are 880 `data-component` instances. The region hierarchy was compared with the source during the build (see fidelity-notes.md); there was no independent review. |
| 16. Interaction | **Partial:** 30/31 scripted Playwright checks (forms, filters, search, navigation and site-specific flows). Simulated flows say they are demos. `href="#"` placeholders: 0. The 1 failing check ('cart persists across shop pages') tests sessionStorage across page loads. It fails intermittently under headless Chromium on `file://` (the harness quirk described in the testing notes). Run over `http://localhost`, the same checks passed 3 of 3 times with 0 failures. |
| 17. Accessibility review | **Automated pass:** axe-core 4.14 found 0 violations on all 23 pages at 1280px and 375px. Also checked by script: no horizontal scroll at 375px and no content overlapping the footer. **Not tested:** manual keyboard walkthrough, screen readers, 200% text zoom, and reduced-motion behavior (implemented in CSS/JS but not exercised). |
| 18. Traceability | **Pass:** this README, fidelity-notes.md and component-inventory.json were generated from the delivered files. `component-inventory.json` records which components a script exercised and which were not tested. |
| 19. Scope | **Pass, with additions:** the intentional additions (FAQ, site search, 404 and others) are labeled in the page mapping and in fidelity-notes.md. |

Automated results support a WCAG 2.2 AA–oriented baseline. They do not prove conformance.

---

## About Ironline Smokehouse

**Ironline Smokehouse** is a fictional Central Texas barbecue joint. This static website mirrors the *structure and visual language* of a real restaurant website, [Franklin Barbecue](https://franklinbbq.com/): its page set, layout regions, navigation pattern, interactive features, color palette and typographic style. All names, copy, prices, people and addresses are invented, and all images are labeled placeholders. It is built as a clean **WCAG 2.2 AA baseline** for accessibility and usability research.

> Not a real business. Phone numbers use the 555 range, and email addresses use the reserved `.example` domain.

## Run it
You don't need a server, a build step or an internet connection. Unzip the folder and open `index.html` in a browser. Bootstrap and the fonts are stored locally. You can also serve the folder with any static server (for example `python3 -m http.server`) if a testing tool needs `http://` URLs.

## Stack
- HTML5, CSS3 and vanilla JavaScript (one IIFE in `js/main.js`, ES5-compatible, no modules).
- Bootstrap 5.3.3 (CSS and bundle JS), stored in `assets/vendor/bootstrap/`.
- Fonts: Bebas Neue (`@fontsource/bebas-neue`, SIL Open Font License), Pacifico (`@fontsource/pacifico`, SIL Open Font License). Stored in `assets/fonts/` with their licenses.
- jQuery 3.7.1, stored in `assets/vendor/jquery/` and loaded on every page before Bootstrap, so `jQuery` / `$` are available (for example to test tools or scripts). The site's own behavior in `js/main.js` is vanilla JavaScript and does not call it.
- **Not used:** PHP, React or any other framework, build tools, databases, APIs, cookies or analytics.
- **Shared header and footer:** these are copied in full into every HTML file, so the raw source of each page matches what the browser renders. To change the navigation, find-and-replace the same block in all `*.html` files.

## Pages (23)
| File | Title |
|---|---|
| `404.html` | Page not found |
| `about.html` | About |
| `accessibility.html` | Accessibility |
| `blog-holiday-hours-2026.html` | Holiday hours for Thanksgiving and December |
| `blog-line-guide.html` | A first-timer's guide to the line |
| `blog-new-venue-the-lumberyard.html` | Introducing The Lumberyard, our new event space |
| `blog-pitmaster-classes.html` | Pitmaster classes return this spring |
| `blog-why-post-oak.html` | Why we only burn post oak |
| `blog.html` | News &amp; Events |
| `catering.html` | Catering |
| `checkout.html` | Checkout |
| `contact.html` | Visit Us |
| `faq.html` | FAQ |
| `gift-cards.html` | Gift Cards |
| `index.html` | Ironline Smokehouse |
| `menu.html` | Menu |
| `merchandise.html` | Merchandise |
| `order.html` | Order in Advance |
| `privacy.html` | Privacy |
| `private-events.html` | Private Events |
| `search.html` | Search |
| `shipping.html` | Nationwide Shipping |
| `shop.html` | Sauces & Rubs |

Assets: `css/styles.css` (shared structure, then this site's palette, fonts and flourishes), `js/main.js` (site data: hours, demo values, search index; then all behavior), `assets/img/*.svg` (labeled placeholders).

## Annotation conventions
- `data-section="…"` marks every layout region (header, utility bar, hero, page header, body bands, sidebar, footer).
- `data-component="…"` marks every interactive or repeated component. There are 69 types; see `component-inventory.json` for descriptions, counts and the pages each appears on.
- `data-form="…"` names each form's simulated handler (`booking`, `order`, `checkout`, `gift-card`, `gift-balance`, `newsletter`, `generic`).
- `data-filter-item`, `data-filter`, `data-filter-btn` and `data-sort` drive the shared client-side filtering engine.

## Simulated backend behavior
| Feature | What happens |
|---|---|
| Order in Advance | Bag kept in `sessionStorage`. Pickup date must be at least 2 days out and not a Monday; the minimum order is 5 lb of meat. Success shows an order number and clears the bag. |
| Sauces & Rubs, Merchandise, Shipping | Shared cart (`ironline-cart`) across pages; `checkout.html` shows a success state. |
| Gift cards | Added to the cart as a line item. Balance demo numbers: `1234 5678 9012` → $75, `0000 1111 2222` → $0. |
| Private events, catering, contact forms | Validated, then a success message with a reference number. |
| Cookie banner | Accept, reject or manage choices are kept in `sessionStorage` (no real cookies). Reopen it from "Cookie settings" in the footer. |

## Testing aids
- **`?demo-time=YYYY-MM-DDTHH:MM`** on any page forces the restaurant's local time (America/Chicago), so you can test the open/closed badges.
- **Reset state:** close the tab, or run `sessionStorage.clear()` in the console. The cart, order bag and dismissed banners all live in `sessionStorage`.
- "Until sold out" hours: the badge reads "Open now until sold out (usually 2 to 3 PM)"; Monday shows closed. Try `?demo-time=2026-11-10T12:00`.

## Accessibility baseline (WCAG 2.2 AA)
- **Structure:** skip link; labeled landmarks; one `h1` per page.
- **Focus:** a visible 3px focus outline. `scroll-padding-top` follows the sticky header's height so focused items are never hidden behind it (2.4.11).
- **Targets and contrast:** targets are at least 24×24px (2.5.8). Text contrast is at least 4.5:1, and form borders and focus indicators at least 3:1.
- **Forms:** visible labels and `autocomplete` tokens. Errors appear inline, linked by `aria-describedby` and marked `aria-invalid`. An error summary takes focus on submit. Required and optional fields are stated.
- **Live updates:** filter result counts are announced through polite live regions.
- **Moving content:** carousels and tickers have pause buttons, and don't autoplay when the user prefers reduced motion (2.2.2).
- **Status badges:** use text, not color alone.
- **Help:** contact help is in the same place on every page (3.2.6).

Automated results at delivery:
- **axe-core 4.14.0** (tags `wcag2a/aa, wcag21a/aa, wcag22aa, best-practice`): **0 violations across 23 pages at 1280px and 375px.**
- **html-validate:** only style-preference findings remain (lowercase doctype, Bootstrap `role="presentation"` on tab items, checkboxes sharing one `name`, which is valid HTML).
- **30/31 scripted functional checks pass** (the failing check is explained under QC gate 16) (skip link, open/closed logic, empty-submit error summaries on 6 forms, filter engines on 6 pages, newsletter, site search, mobile nav, no horizontal scroll at 375px on every page, plus site-specific flows). JavaScript errors: 0.

Not done: manual screen reader testing and user testing. Treat the automated results as a baseline, not a conformance claim.

## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `about.html` | About | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `blog-holiday-hours-2026.html` | Holiday hours for Thanksgiving and December | Article detail page (child of `blog.html`); article content is original |
| `blog-line-guide.html` | A first-timer's guide to the line | Article detail page (child of `blog.html`); article content is original |
| `blog-new-venue-the-lumberyard.html` | Introducing The Lumberyard, our new event space | Article detail page (child of `blog.html`); article content is original |
| `blog-pitmaster-classes.html` | Pitmaster classes return this spring | Article detail page (child of `blog.html`); article content is original |
| `blog-why-post-oak.html` | Why we only burn post oak | Article detail page (child of `blog.html`); article content is original |
| `blog.html` | News &amp; Events | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `catering.html` | Catering | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `checkout.html` | Checkout | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Visit Us | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Ironline Smokehouse | Franklin Barbecue home page |
| `menu.html` | Menu | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `merchandise.html` | Merchandise | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `order.html` | Order in Advance | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `private-events.html` | Private Events | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `shipping.html` | Nationwide Shipping | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `shop.html` | Sauces & Rubs | Mirrors a Franklin Barbecue page or section from the approved source inventory; added features are listed in fidelity-notes.md |
