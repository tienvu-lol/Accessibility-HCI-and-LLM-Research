<!-- Protocol: WEB-REPLICA-V1.0 | Replica: REST-04 | Category: restaurant (Vegan / health) | Source: Crossroads Kitchen https://www.crossroadskitchen.com/ -->
# Fidelity notes: Fernway Kitchen ↔ Crossroads Kitchen

**Original:** https://crossroadskitchen.com/ (structure checked on November 6, 2026; visual design measured on November 7, 2026 from the live site's computed styles in a browser).
**Replica:** Fernway Kitchen. It copies structure and visual language only. No brand names, copy, images, logos, fonts or code from the original are reused.

## Visual design: measured on the original and how the replica maps it
| Element | Original (measured) | Replica |
|---|---|---|
| Home page | "Choose your restaurant:" splash over a full-bleed dark food slider, Los Angeles / Las Vegas buttons | Same pattern: crossfading dark placeholder backgrounds, a translucent slate panel, two red buttons, plus a pause control |
| Logo bar | White bar with a grey stencil wordmark | White header, grey uppercase wordmark |
| Dark color | Slate `#20303C` | Same slate for the splash panel, headings and footer |
| Buttons | Red `#BF3F39`, 10px radius, **black** text (4.0:1) | Same red and radius with **white** text (5.3:1) |
| Type | Oswald (medium) for headings, nav and buttons; Avenir body | **Oswald** (OFL); body uses the Avenir Next / Avenir system stack with a system-ui fallback |
| Navigation | Long single-row nav that ends in "More…" | Priority+ navigation that moves links that don't fit into a **More** dropdown |
| Accessibility overlay | Third-party "Enable accessibility" widget | Not copied; the site is built accessible instead |

## Mirrored structure
- **Two city homes** reached from the home-page chooser, each with hours by meal period, a reserve button and an order-online button.
- **Navigation:** Restaurants, About (Our Story, Team, Cookbook), Hours & Location, All Menus, Reservations, Private Dining, Order Online, Gift Cards, Catering, More.
- **Six menus:** Dinner, Lunch, Brunch, Party Trays, Family Style, Drinks.
- **Order Online** offers third-party apps (fictional here) alongside ordering on the site.

## Adapted, added or left out
- **Added:** dietary filters for an all-vegan menu (gluten-free, nut-free, soy-free), on-site reservations with a restaurant chooser, the tray order flow, Journal with filters, FAQ, site search, privacy, accessibility and 404 pages.
- **Left out:** the third-party accessibility overlay, and Nationwide Shipping (not essential for coverage; noted here).

## Observations on the original that were not copied
1. Black text on the red location buttons: 4.0:1, below 4.5:1.
2. The body font size is 10px (computed on `body`), and the page relies on child elements to set readable sizes.
3. A third-party accessibility overlay adds its own buttons ("Enable accessibility", "Open the accessibility menu") to the tab order before the content.
4. The H1 on the home page is "CHOOSE YOUR RESTAURANT:" at 18px, smaller than the H2 hours text.


## Page-to-source mapping

| Replica page | Title | Source basis |
|---|---|---|
| `404.html` | Page not found | Intentional addition (required by the protocol) |
| `accessibility.html` | Accessibility | Intentional addition (accessibility statement for the test baseline) |
| `catering.html` | Catering | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `contact.html` | Hours & Location | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `cookbook.html` | Cookbook | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `faq.html` | FAQ | Intentional addition (FAQ with search and accordions) |
| `gift-cards.html` | Gift Cards | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `index.html` | Fernway Kitchen | Crossroads Kitchen home page |
| `journal-cookbook-launch.html` | Our second cookbook is here | Article detail page (child of `journal.html`); article content is original |
| `journal-nut-free-guide.html` | A guide to nut-free dining at Fernway | Article detail page (child of `journal.html`); article content is original |
| `journal-spring-menu.html` | What's new on the spring menu | Article detail page (child of `journal.html`); article content is original |
| `journal-vegas-anniversary.html` | Five years on the Strip | Article detail page (child of `journal.html`); article content is original |
| `journal.html` | Journal | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `las-vegas.html` | Las Vegas | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `los-angeles.html` | Los Angeles | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `menu.html` | All Menus | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `order.html` | Order Online | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `our-story.html` | Our Story | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `privacy.html` | Privacy | Utility page (privacy notice); not checked against a source equivalent |
| `private-dining.html` | Private Dining | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `reservations.html` | Reservations | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |
| `search.html` | Search | Intentional addition (client-side site search over local data) |
| `team.html` | Team | Mirrors a Crossroads Kitchen page or section from the approved source inventory; added features are listed in fidelity-notes.md |

## Protocol deviations

- **Bootstrap 5.3.3** (CSS and JS bundle) is used for layout utilities, the grid and the dialog, off-canvas, dropdown, collapse, tab and carousel behaviors. WEB-REPLICA-V1.0 prohibits Bootstrap. The site was built before the protocol was adopted, and on 2026-11-07 the decision was to keep Bootstrap and record it as a deviation rather than rewrite the components. Bootstrap is stored locally and needs no network.
- **jQuery 3.7.1** is stored in `assets/vendor/jquery/` and loaded on every page, before Bootstrap. WEB-REPLICA-V1.0 also prohibits jQuery. Isaac allowed it on 2026-11-07 ("You can use jQuery as well just no PHP") and chose to include it while keeping the existing vanilla JavaScript. `jQuery` and `$` are therefore available on every page, but nothing in `js/main.js` calls them. While jQuery is present, Bootstrap 5 also registers its jQuery plugin interface (for example `$('#id').modal('show')`).
