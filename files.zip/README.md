# Web Content Accessibility Guidelines (WCAG) 2.2 — Markdown Edition

This is a Markdown conversion of the **WCAG 2.2 W3C Recommendation** (12 December 2024), split into per-section files for easier reference and research use.

- **Canonical version:** <https://www.w3.org/TR/2024/REC-WCAG22-20241212/>
- **Latest version:** <https://www.w3.org/TR/WCAG22/>
- **Source used for this conversion:** the official [w3c/wcag GitHub repository](https://github.com/w3c/wcag) (the normative source from which the W3C's published page is built), assembled from its component files and converted to Markdown.
- **License:** © 2020–2024 [World Wide Web Consortium](https://www.w3.org/). Reproduced under the [W3C Document License](https://www.w3.org/copyright/document-license/), which permits copying and redistribution of W3C specifications.

## ⚠️ Notes on this conversion

- Two things are generated dynamically by the W3C's build tooling (ReSpec) and are **not present in the raw source**, so they've been reconstructed here from the published Table of Contents: the section/success-criterion **numbering** (e.g. "1.1.1") and the "Guideline" / "Success Criterion" heading prefixes, plus the "(Level A/AA/AAA)" conformance labels.
- The **References / Bibliography appendix (Section C)** is generated automatically from a separate bibliography database at build time and isn't included in the raw source files, so it is **not** included here. See the [live References section](https://www.w3.org/TR/2024/REC-WCAG22-20241212/#references) for the full citation list.
- This is provided for research/reference convenience. For anything requiring an authoritative citation, defer to the official W3C page linked above, which is the canonical text.

## Files

| File | Contents |
|---|---|
| [00-front-matter.md](00-front-matter.md) | Abstract, Status of this Document, full Introduction (background, layers of guidance, supporting documents, requirements, comparison with 2.1) |
| [01-perceivable.md](01-perceivable.md) | Principle 1: Perceivable — Guidelines 1.1–1.4, all Success Criteria |
| [02-operable.md](02-operable.md) | Principle 2: Operable — Guidelines 2.1–2.5, all Success Criteria |
| [03-understandable.md](03-understandable.md) | Principle 3: Understandable — Guidelines 3.1–3.3, all Success Criteria |
| [04-robust.md](04-robust.md) | Principle 4: Robust — Guideline 4.1, all Success Criteria |
| [05-conformance.md](05-conformance.md) | Section 5: Conformance requirements, conformance claims, privacy & security considerations |
| [06-glossary.md](06-glossary.md) | Section 6: Full Glossary of defined terms |
| [07-input-purposes.md](07-input-purposes.md) | Section 7: Input Purposes for User Interface Components |
| [08-appendices.md](08-appendices.md) | Appendix A: Change Log, Appendix B: Acknowledgments |

## Quick facts about WCAG 2.2

- 4 principles (Perceivable, Operable, Understandable, Robust), 13 guidelines, 87 success criteria across 3 conformance levels (A, AA, AAA).
- 9 success criteria are new in 2.2 versus 2.1 (all in `01`–`03` files, marked "*New in WCAG 2.2*").
- 1 success criterion from 2.1 (4.1.1 Parsing) was formally removed in 2.2 — see `04-robust.md`.

## Verification status (18 July 2026)

- **Structural validation:** 4 principles, 13 guidelines, 87 success criteria (A=31, AA=24, AAA=31, plus removed 4.1.1), 9 new-in-2.2 criteria, 101 glossary terms, 53 input purposes — all match official published counts.
- **Word-coverage validation:** every word of all 87 success criteria and all 101 glossary terms in the source files is present in these Markdown files. Key numeric values (4.5:1, 7:1, 3:1, 24×24, 44×44, 320 CSS px, 200%) confirmed present.
- **Errata status:** these files include three editorial errata dated 2025-06-27 (per the [official errata page](https://www.w3.org/WAI/WCAG22/errata/)): "breakpoint" harmonized in SC 3.2.6, an updated supplemental-guidance link in the Introduction, and stray periods removed from the "perimeter" and "single pointer" definitions. They therefore reflect the current corrected text, which differs in these three editorial respects from the literal 12 Dec 2024 snapshot.
- **Known limitations:** math formulas flattened to plain text (e.g. the 𝜋 glyph and superscripts in glossary formulas); numbering/level labels reconstructed from the published TOC (validated against official counts); References appendix not included. Word coverage was verified, word order was not machine-verified — visually compare against the canonical page before quoting verbatim in publication.
