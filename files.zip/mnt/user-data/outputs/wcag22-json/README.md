# Web Content Accessibility Guidelines (WCAG) 2.2 — JSON Edition

Structured JSON conversion of the **WCAG 2.2 W3C Recommendation** (12 December 2024), built for research and programmatic use.

- **Canonical version:** <https://www.w3.org/TR/2024/REC-WCAG22-20241212/>
- **Source used:** the official [w3c/wcag GitHub repository](https://github.com/w3c/wcag) (the normative source the published page is built from), assembled from its 192 component files and parsed into structured JSON.
- **License:** © 2020–2024 [World Wide Web Consortium](https://www.w3.org/). Reproduced under the [W3C Document License](https://www.w3.org/copyright/document-license/).

## Files

| File | Contents |
|---|---|
| `wcag22-full.json` | Everything below combined into one document, plus metadata |
| `guidelines.json` | The core hierarchy: 4 principles → 13 guidelines → 87 success criteria |
| `success-criteria-index.json` | Flat list of all 87 SCs (num, title, level, new/removed flags, parent principle/guideline, URL) — handy for lookups, filtering, and joins |
| `glossary.json` | 101 defined terms with definitions, notes, and supplementary text |
| `conformance.json` | Section 5: conformance requirements, claims, privacy & security considerations |
| `input-purposes.json` | Section 7: the 53 input purpose tokens with descriptions |
| `front-matter.json` | Abstract, Status of this Document, Introduction |
| `appendices.json` | Appendix A (Change Log) and Appendix B (Acknowledgments) |

## Success criterion schema (`guidelines.json`)

```json
{
  "id": "target-size-minimum",          // anchor id on w3.org
  "num": "2.5.8",                        // SC number
  "title": "Target Size (Minimum)",
  "level": "AA",                         // "A" | "AA" | "AAA" | null (only 4.1.1, removed)
  "new_in_wcag22": true,
  "removed": false,                      // true only for 4.1.1 Parsing
  "text": "The size of the target ...",  // main normative text
  "details": [                           // named cases/exceptions (dt/dd pairs in the spec)
    { "term": "Spacing", "description": "..." }
  ],
  "items": [],                           // bullet-list requirements, where the SC uses them
  "notes": ["..."],                      // informative notes
  "url": "https://www.w3.org/TR/WCAG22/#target-size-minimum"
}
```

Guidelines wrap SCs: `{ id, num, title, text, url, success_criteria: [...] }`.
Principles wrap guidelines: `{ id, num, title, text, url, guidelines: [...] }`.

## Glossary term schema (`glossary.json`)

```json
{
  "id": "dfn-contrast-ratio",
  "term": "contrast ratio",
  "definition": "...",       // first paragraph of the definition
  "notes": ["..."],          // informative notes
  "additional": ["..."],     // continuation text, examples, sub-lists
  "url": "https://www.w3.org/TR/WCAG22/#dfn-contrast-ratio"
}
```

## Generic section schema (`conformance.json`, `front-matter.json`, `appendices.json`)

Nested sections of the form:
```json
{
  "id": "...", "title": "...", "url": "...",
  "content": [
    { "type": "paragraph", "text": "..." },
    { "type": "note", "text": "..." },
    { "type": "list", "ordered": false, "items": ["..."] },
    { "type": "definition_list", "entries": [{ "term": "...", "description": "..." }] }
  ],
  "subsections": [ ...same shape... ]
}
```

## ⚠️ Notes on this conversion

- Section/SC **numbering**, "(Level …)" labels, and New-in-2.2 flags are added dynamically by the W3C's build tooling (ReSpec) and are not present in the raw source; they were reconstructed here from the published Table of Contents and the source `class` attributes, and validated against the official counts (4 / 13 / 87; levels A=31, AA=24, AAA=31 plus the removed 4.1.1; 9 new SCs).
- The **References appendix (Section C)** is generated from a separate bibliography database at build time and is not included. Inline citation keys appear as plain text (e.g. `[RFC2119]`).
- Mathematical formulas (e.g. relative luminance in the glossary) are flattened to plain text; consult the live page for exact formula presentation.
- For anything requiring an authoritative citation, defer to the canonical W3C page. This conversion is for research/programmatic convenience.

## Quick usage examples

```python
import json

data = json.load(open("guidelines.json"))

# All Level AA success criteria
aa = [sc for p in data["principles"] for g in p["guidelines"]
      for sc in g["success_criteria"] if sc["level"] == "AA"]

# The nine new-in-2.2 criteria
new = [sc["num"] + " " + sc["title"]
       for p in data["principles"] for g in p["guidelines"]
       for sc in g["success_criteria"] if sc["new_in_wcag22"]]
```

## Verification status (18 July 2026)

- **Structural validation:** all official counts match (4/13/87 with A=31, AA=24, AAA=31 + removed 4.1.1; 9 new SCs; 101 glossary terms; 53 input purposes).
- **Word-coverage validation:** a word-level comparison of all 87 success criteria and all 101 glossary terms against the raw source files passes with zero missing words.
- **Fixes applied during verification:** (1) six glossary definitions previously captured the "New in 2.2" marker instead of the definition text — corrected, and glossary terms now carry a `new_in_wcag22` flag plus an `examples` field; (2) SC 3.3.8 was missing its second note (marked up as a `div` in the source) — restored.
- **Errata status:** reflects the GitHub main-branch source, which includes three editorial errata dated 2025-06-27 (see the [official errata page](https://www.w3.org/WAI/WCAG22/errata/)): "breakpoint" in SC 3.2.6, an updated Introduction link, and punctuation fixes in the "perimeter" and "single pointer" definitions. This is the current corrected text, not the literal 12 Dec 2024 snapshot.
- **Known limitations:** math formulas flattened; word coverage verified but word order not machine-verified — for verbatim quotation in publication, compare against the canonical page. W3C also announced official machine-readable JSON files for WCAG 2 (late 2025), which can serve as an independent diff baseline.
