# 3. Understandable

Information and the operation of the user interface must be understandable.

## Guideline 3.1 Readable

Make text content readable and understandable.

### Success Criterion 3.1.1 Language of Page

**(Level A)**

The default human language of each web page can be programmatically determined.

### Success Criterion 3.1.2 Language of Parts

**(Level AA)**

The human language of each passage or phrase in the content can be programmatically determined except for proper names, technical terms, words of indeterminate language, and words or phrases that have become part of the vernacular of the immediately surrounding text.

### Success Criterion 3.1.3 Unusual Words

**(Level AAA)**

A mechanism is available for identifying specific definitions of words or phrases used in an unusual or restricted way, including idioms and jargon.

### Success Criterion 3.1.4 Abbreviations

**(Level AAA)**

A mechanism for identifying the expanded form or meaning of abbreviations is available.

### Success Criterion 3.1.5 Reading Level

**(Level AAA)**

When text requires reading ability more advanced than the lower secondary education level after removal of proper names and titles, supplemental content, or a version that does not require reading ability more advanced than the lower secondary education level, is available.

### Success Criterion 3.1.6 Pronunciation

**(Level AAA)**

A mechanism is available for identifying specific pronunciation of words where meaning of the words, in context, is ambiguous without knowing the pronunciation.

## Guideline 3.2 Predictable

Make web pages appear and operate in predictable ways.

### Success Criterion 3.2.1 On Focus

**(Level A)**

When any user interface component receives focus, it does not initiate a change of context.

### Success Criterion 3.2.2 On Input

**(Level A)**

Changing the setting of any user interface component does not automatically cause a change of context unless the user has been advised of the behavior before using the component.

### Success Criterion 3.2.3 Consistent Navigation

**(Level AA)**

Navigational mechanisms that are repeated on multiple web pages within a set of web pages occur in the same relative order each time they are repeated, unless a change is initiated by the user.

### Success Criterion 3.2.4 Consistent Identification

**(Level AA)**

Components that have the same functionality within a set of web pages are identified consistently.

### Success Criterion 3.2.5 Change on Request

**(Level AAA)**

Changes of context are initiated only by user request or a mechanism is available to turn off such changes.

### Success Criterion 3.2.6 Consistent Help

**(Level A)**

*New in WCAG 2.2*

If a web page contains any of the following help mechanisms, and those mechanisms are repeated on multiple web pages within a set of web pages, they occur in the same order relative to other page content, unless a change is initiated by the user:

- Human contact details;
- Human contact mechanism;
- Self-help option;
- A fully automated contact mechanism.

Note 1: Help mechanisms may be provided directly on the page, or may be provided via a direct link to a different page containing the information.

Note 2: For this success criterion, "the same order relative to other page content" can be thought of as how the content is ordered when the page is serialized. The visual position of a help mechanism is likely to be consistent across pages for the same page variation (e.g., CSS breakpoint). The user can initiate a change, such as changing the page's zoom or orientation, which may trigger a different page variation. This criterion is concerned with relative order across pages displayed in the same page variation (e.g., same zoom level and orientation).

## Guideline 3.3 Input Assistance

Help users avoid and correct mistakes.

### Success Criterion 3.3.1 Error Identification

**(Level A)**

If an input error is automatically detected, the item that is in error is identified and the error is described to the user in text.

### Success Criterion 3.3.2 Labels or Instructions

**(Level A)**

Labels or instructions are provided when content requires user input.

### Success Criterion 3.3.3 Error Suggestion

**(Level AA)**

If an input error is automatically detected and suggestions for correction are known, then the suggestions are provided to the user, unless it would jeopardize the security or purpose of the content.

### Success Criterion 3.3.4 Error Prevention (Legal, Financial, Data)

**(Level AA)**

For web pages that cause legal commitments or financial transactions for the user to occur, that modify or delete user-controllable data in data storage systems, or that submit user test responses, at least one of the following is true:

Reversible  
Submissions are reversible.

Checked  
Data entered by the user is checked for input errors and the user is provided an opportunity to correct them.

Confirmed  
A mechanism is available for reviewing, confirming, and correcting information before finalizing the submission.

### Success Criterion 3.3.5 Help

**(Level AAA)**

Context-sensitive help is available.

### Success Criterion 3.3.6 Error Prevention (All)

**(Level AAA)**

For web pages that require the user to submit information, at least one of the following is true:

Reversible  
Submissions are reversible.

Checked  
Data entered by the user is checked for input errors and the user is provided an opportunity to correct them.

Confirmed  
A mechanism is available for reviewing, confirming, and correcting information before finalizing the submission.

### Success Criterion 3.3.7 Redundant Entry

**(Level A)**

*New in WCAG 2.2*

Information previously entered by or provided to the user that is required to be entered again in the same process is either:

- auto-populated, or
- available for the user to select.

Except when:

- re-entering the information is essential,
- the information is required to ensure the security of the content, or
- previously entered information is no longer valid.

### Success Criterion 3.3.8 Accessible Authentication (Minimum)

**(Level AA)**

*New in WCAG 2.2*

A cognitive function test (such as remembering a password or solving a puzzle) is not required for any step in an authentication process unless that step provides at least one of the following:

Alternative  
Another authentication method that does not rely on a cognitive function test.

Mechanism  
A mechanism is available to assist the user in completing the cognitive function test.

Object Recognition  
The cognitive function test is to recognize objects.

Personal Content  
The cognitive function test is to identify non-text content the user provided to the website.

Note: "Object recognition" and "Personal content" may be represented by images, video, or audio.

Examples of mechanisms that satisfy this criterion include:

- support for password entry by password managers to reduce memory need, and
- copy and paste to reduce the cognitive burden of re-typing.

### Success Criterion 3.3.9 Accessible Authentication (Enhanced)

**(Level AAA)**

*New in WCAG 2.2*

A cognitive function test (such as remembering a password or solving a puzzle) is not required for any step in an authentication process unless that step provides at least one of the following:

Alternative  
Another authentication method that does not rely on a cognitive function test.

Mechanism  
A mechanism is available to assist the user in completing the cognitive function test.
