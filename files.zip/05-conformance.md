# 5. Conformance

This section lists requirements for conformance to WCAG 2.2. It also gives information about how to make conformance claims, which are optional. Finally, it describes what it means to be accessibility supported, since only accessibility-supported ways of using technologies can be relied upon for conformance. [Understanding Conformance](https://www.w3.org/WAI/WCAG22/Understanding/conformance) includes further explanation of the accessibility-supported concept.

## 5.1 Interpreting Normative Requirements

The main content of WCAG 2.2 is normative and defines requirements that impact conformance claims. Introductory material, appendices, sections marked as "non-normative", diagrams, examples, and notes are informative (non-normative). Non-normative material provides advisory information to help interpret the guidelines but does not create requirements that impact a conformance claim.

The key words MAY, MUST, MUST NOT, NOT RECOMMENDED, RECOMMENDED, SHOULD, and SHOULD NOT are to be interpreted as described in [RFC2119].

## 5.2 Conformance Requirements

In order for a web page to conform to WCAG 2.2, all of the following conformance requirements must be satisfied:

### 5.2.1 Conformance Level

One of the following levels of conformance is met in full.

- For Level A conformance (the minimum level of conformance), the web page satisfies all the Level A success criteria, or a conforming alternate version is provided.
- For Level AA conformance, the web page satisfies all the Level A and Level AA success criteria, or a Level AA conforming alternate version is provided.
- For Level AAA conformance, the web page satisfies all the Level A, Level AA and Level AAA success criteria, or a Level AAA conforming alternate version is provided.

Note 1: Although conformance can only be achieved at the stated levels, authors are encouraged to report (in their claim) any progress toward meeting success criteria from all levels beyond the achieved level of conformance.

Note 2: It is not recommended that Level AAA conformance be required as a general policy for entire sites because it is not possible to satisfy all Level AAA success criteria for some content.

### 5.2.2 Full pages

Conformance (and conformance level) is for full web page(s) only, and cannot be achieved if part of a web page is excluded.

Note 1: For the purpose of determining conformance, alternatives to part of a page's content are considered part of the page when the alternatives can be obtained directly from the page, e.g., a long description or an alternative presentation of a video.

Note 2: Authors of web pages that cannot conform due to content outside of the author's control may consider a [Statement of Partial Conformance](#conformance-partial).

Note 3: A full page includes each variation of the page that is automatically presented by the page for various screen sizes (e.g. variations in a responsive web page). Each of these variations needs to conform (or needs to have a conforming alternate version) in order for the entire page to conform.

### 5.2.3 Complete processes

When a web page is one of a series of web pages presenting a process (i.e., a sequence of steps that need to be completed in order to accomplish an activity), all web pages in the process conform at the specified level or better. (Conformance is not possible at a particular level if any page in the process does not conform at that level or better.)

An online store has a series of pages that are used to select and purchase products. All pages in the series from start to finish (checkout) conform in order for any page that is part of the process to conform.

### 5.2.4 Only Accessibility-Supported Ways of Using Technologies

Only accessibility-supported ways of using technologies are relied upon to satisfy the success criteria. Any information or functionality that is provided in a way that is not accessibility supported is also available in a way that is accessibility supported. (See [Understanding accessibility support](https://www.w3.org/WAI/WCAG22/Understanding/conformance#accessibility-support).)

### 5.2.5 Non-Interference

If technologies are used in a way that is not accessibility supported, or if they are used in a non-conforming way, then they do not block the ability of users to access the rest of the page. In addition, the web page as a whole continues to meet the conformance requirements under each of the following conditions:

1.  when any technology that is not relied upon is turned on in a user agent,
2.  when any technology that is not relied upon is turned off in a user agent, and
3.  when any technology that is not relied upon is not supported by a user agent

In addition, the following success criteria apply to all content on the page, including content that is not otherwise relied upon to meet conformance, because failure to meet them could interfere with any use of the page:

- **1.4.2 - Audio Control**,
- **2.1.2 - No Keyboard Trap**,
- **2.3.1 - Three Flashes or Below Threshold**, and
- **2.2.2 - Pause, Stop, Hide**.

Note: If a page cannot conform (for example, a conformance test page or an example page), it cannot be included in the scope of conformance or in a conformance claim.

For more information, including examples, see [Understanding Conformance Requirements](https://www.w3.org/WAI/WCAG22/Understanding/conformance#conformance-requirements).

## 5.3 Conformance Claims (Optional)

Conformance is defined only for web pages. However, a conformance claim may be made to cover one page, a series of pages, or multiple related web pages.

### 5.3.1 Required Components of a Conformance Claim

Conformance claims are **not required**. Authors can conform to WCAG 2.2 without making a claim. However, if a conformance claim is made, then the conformance claim **must** include the following information:

1.  **Date** of the claim

2.  **Guidelines title, version and URI** "Web Content Accessibility Guidelines 2.2 at <https://www.w3.org/TR/WCAG22/>"

3.  **Conformance level** satisfied: (Level A, AA or AAA)

4.  **A concise description of the web pages**, such as a list of URIs for which the claim is made, including whether subdomains are included in the claim.

    The web pages may be described by list or by an expression that describes all of the URIs included in the claim.

    Web-based products that do not have a URI prior to installation on the customer's website may have a statement that the product would conform when installed.

5.  A list of the **web content technologies relied upon**.

Note: If a conformance logo is used, it would constitute a claim and must be accompanied by the required components of a conformance claim listed above.

### 5.3.2 Optional Components of a Conformance Claim

In addition to the required components of a conformance claim above, consider providing additional information to assist users. Recommended additional information includes:

- A list of success criteria beyond the level of conformance claimed that have been met. This information should be provided in a form that users can use, preferably machine-readable metadata.
- A list of the specific technologies that are "*used but not relied upon*."
- A list of user agents, including assistive technologies that were used to test the content.
- A list of specific accessibility characteristics of the content, provided in machine-readable metadata.
- Information about any additional steps taken that go beyond the success criteria to enhance accessibility.
- A machine-readable metadata version of the list of specific technologies that are relied upon.
- A machine-readable metadata version of the conformance claim.

Note 1: Refer to [Understanding Conformance Claims](https://www.w3.org/WAI/WCAG22/Understanding/conformance#conformance-claims) for more information and example conformance claims.

Note 2: Refer to [Understanding Metadata](https://www.w3.org/WAI/WCAG22/Understanding/understanding-metadata) for more information about the use of metadata in conformance claims.

## 5.4 Statement of Partial Conformance - Third Party Content

Web pages that will later have additional content added can use a 'statement of partial conformance'. For example, an email program, a blog, an article that allows users to add comments, or applications supporting user-contributed content. Another example would be a page, such as a portal or news site, composed of content aggregated from multiple contributors, or sites that automatically insert content from other sources over time, such as when advertisements are inserted dynamically.

In these cases, it is not possible to know at the time of original posting what the uncontrolled content of the pages will be. It is important to note that the uncontrolled content can affect the accessibility of the controlled content as well. Two options are available:

1.  A determination of conformance can be made based on best knowledge. If a page of this type is monitored and repaired (non-conforming content is removed or brought into conformance) within two business days, then a determination or claim of conformance can be made since, except for errors in externally contributed content which are corrected or removed when encountered, the page conforms. No conformance claim can be made if it is not possible to monitor or correct non-conforming content;

    **OR**

2.  A "statement of partial conformance" may be made that the page does not conform, but could conform if certain parts were removed. The form of that statement would be, "This page does not conform, but would conform to WCAG 2.2 at level X if the following parts from uncontrolled sources were removed." In addition, the following would also be true of uncontrolled content that is described in the statement of partial conformance:

    1.  It is not content that is under the author's control.
    2.  It is described in a way that users can identify (e.g., they cannot be described as "all parts that we do not control" unless they are clearly marked as such.)

## 5.5 Statement of Partial Conformance - Language

A "statement of partial conformance due to language" may be made when the page does not conform, but would conform if accessibility support existed for (all of) the language(s) used on the page. The form of that statement would be, "This page does not conform, but would conform to WCAG 2.2 at level X if accessibility support existed for the following language(s):"

## 5.6 Privacy Considerations

Success criteria within this specification which the Working Group has identified possible implications for privacy, either by providing protections for end users or which are important for website providers to take in to consideration when implementing features designed to protect user privacy, are listed below. This list reflects the current understanding of the Working Group but other success criteria may have privacy implications that the Working Group is not aware of at the time of publishing.

Success criteria within this specification that may relate to privacy are:

- [2.2.6 Timeouts (AAA)](#timeouts)
- [3.3.7 Redundant Entry (A)](#redundant-entry)

## 5.7 Security Considerations

Success criteria within this specification which the Working Group has identified possible implications for security, either by providing protections for end users or which are important for website providers to take in to consideration when implementing features designed to protect user security, are listed below. This list reflects the current understanding of the Working Group but other success criteria may have security implications that the Working Group is not aware of at the time of publishing.

Success criteria within this specification that may relate to security are:

- [1.1.1 Non-text Content (A)](#non-text-content)
- [1.3.5 Identify Input Purpose (AA)](#identify-input-purpose)
- [1.4.7 Low or No Background Audio (AAA)](#low-or-no-background-audio)
- [2.2.1 Timing Adjustable (A)](#timing-adjustable)
- [2.2.5 Re-authenticating (AAA)](#re-authenticating)
- [2.2.6 Timeouts (AAA)](#timeouts)
- [2.5.6 Concurrent Input Mechanisms (AAA)](#concurrent-input-mechanisms)
- [3.3.3 Error Suggestion (AA)](#error-suggestion)
- [3.3.7 Redundant Entry (A)](#redundant-entry)
- [3.3.8 Accessible Authentication (Minimum) (AA)](#accessible-authentication-minimum)
- [3.3.9 Accessible Authentication (Enhanced) (AAA)](#accessible-authentication-enhanced)
