# 7. Input Purposes for User Interface Components

This section contains a listing of common user interface component input purposes. The terms below are not keywords that must be used, but instead represent purposes that can be captured in the taxonomy adopted by a webpage. Where applicable, authors mark up controls with the chosen taxonomy to indicate the semantic purpose. This provides the potential for user agents and assistive technologies to apply personalized presentations that can enable more people to understand and use the content.

Note: The list of input type purposes is based on the control purposes defined in the [HTML specification's Autofill section](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill), but it is important to understand that a different technology may have some or all of the same concepts defined in its specification and only the concepts that are mapped to the meanings below are required.

The following input control purposes are intended to relate to the user of the content and pertain only to information related to that individual.

- `name` - Full name
- `honorific-prefix` - Prefix or title (e.g., "Mr.", "Ms.", "Dr.", "M<sup>lle</sup>")
- `given-name` - Given name (in some Western cultures, also known as the *first name*)
- `additional-name` - Additional names (in some Western cultures, also known as *middle names*, forenames other than the first name)
- `family-name` - Family name (in some Western cultures, also known as the *last name* or *surname*)
- `honorific-suffix` - Suffix (e.g., "Jr.", "B.Sc.", "MBASW", "II")
- `nickname` - Nickname, screen name, handle: a typically short name used instead of the full name
- `organization-title` - Job title (e.g., "Software Engineer", "Senior Vice President", "Deputy Managing Director")
- `username` - A username
- `new-password` - A new password (e.g., when creating an account or changing a password)
- `current-password` - The current password for the account identified by the `username` field (e.g., when logging in)
- `organization` - Company name corresponding to the person, address, or contact information in the other fields associated with this field
- `street-address` - Street address (multiple lines, newlines preserved)
- `address-line1` - Street address (one line per field, line 1)
- `address-line2` - Street address (one line per field, line 2)
- `address-line3` - Street address (one line per field, line 3)
- `address-level4` - The most fine-grained administrative level, in addresses with four administrative levels
- `address-level3` - The third administrative level, in addresses with three or more administrative levels
- `address-level2` - The second administrative level, in addresses with two or more administrative levels; in the countries with two administrative levels, this would typically be the city, town, village, or other locality within which the relevant street address is found
- `address-level1` - The broadest administrative level in the address, i.e., the province within which the locality is found; for example, in the US, this would be the state; in Switzerland it would be the canton; in the UK, the post town
- `country` - Country code
- `country-name` - Country name
- `postal-code` - Postal code, post code, ZIP code, CEDEX code (if CEDEX, append "CEDEX", and the *arrondissement*, if relevant, to the `address-level2` field)
- `cc-name` - Full name as given on the payment instrument
- `cc-given-name` - Given name as given on the payment instrument (in some Western cultures, also known as the *first name*)
- `cc-additional-name` - Additional names given on the payment instrument (in some Western cultures, also known as *middle names*, forenames other than the first name)
- `cc-family-name` - Family name given on the payment instrument (in some Western cultures, also known as the *last name* or *surname*)
- `cc-number` - Code identifying the payment instrument (e.g., the credit card number)
- `cc-exp` - Expiration date of the payment instrument
- `cc-exp-month` - Month component of the expiration date of the payment instrument
- `cc-exp-year` - Year component of the expiration date of the payment instrument
- `cc-csc` - Security code for the payment instrument (also known as the card security code (CSC), card validation code (CVC), card verification value (CVV), signature panel code (SPC), credit card ID (CCID), etc)
- `cc-type` - Type of payment instrument
- `transaction-currency` - The currency that the user would prefer the transaction to use
- `transaction-amount` - The amount that the user would like for the transaction (e.g., when entering a bid or sale price)
- `language` - Preferred language
- `bday` - Birthday
- `bday-day` - Day component of birthday
- `bday-month` - Month component of birthday
- `bday-year` - Year component of birthday
- `sex` - Gender identity (e.g., Female, Fa’afafine)
- `url` - Home page or other web page corresponding to the company, person, address, or contact information in the other fields associated with this field
- `photo` - Photograph, icon, or other image corresponding to the company, person, address, or contact information in the other fields associated with this field
- `tel` - Full telephone number, including country code
- `tel-country-code` - Country code component of the telephone number
- `tel-national` - Telephone number without the country code component, with a country-internal prefix applied if applicable
- `tel-area-code` - Area code component of the telephone number, with a country-internal prefix applied if applicable
- `tel-local` - Telephone number without the country code and area code components
- `tel-local-prefix` - First part of the component of the telephone number that follows the area code, when that component is split into two components
- `tel-local-suffix` - Second part of the component of the telephone number that follows the area code, when that component is split into two components
- `tel-extension` - Telephone number internal extension code
- `email` - Email address
- `impp` - URL representing an instant messaging protocol endpoint (for example, "`aim:goim?screenname=example`" or "`xmpp:fred@example.net`")
