# Appendices: Change Log & Acknowledgments

# A. Change Log

This section shows substantive changes incorporated into WCAG 2.2 since WCAG 2.1, as well as changes made to 2.2 since its original publication on 05 October 2023. [Errata fixes to WCAG 2.1](https://www.w3.org/WAI/WCAG21/errata/) have also been incorporated into WCAG 2.2.

The full [commit history to WCAG 2.2](https://github.com/w3c/wcag/commits/main/guidelines) is available.

- 2020-03-30: Added [Accessible Authentication (Minimum)](#accessible-authentication-minimum).
- 2020-05-27: Added “Dragging” (later renamed [Dragging Movements](#dragging-movements)).
- 2020-07-19: Added “Findable Help” (later renamed to [Consistent Help](#consistent-help)), “Pointer Target Spacing” (later renamed [Target Size (Minimum)](#target-size-minimum)), and [Redundant Entry](#redundant-entry).
- 2020-08-04: Added “Focus Appearance (Minimum)” (later renamed to [Focus Appearance](#focus-appearance)).
- 2021-09-21: Added “Accessible Authentication (No Exception)” (later renamed [Accessible Authentication (Enhanced))](#accessible-authentication-enhanced).
- 2022-03-22: Added [Focus Not Obscured (Minimum)](#focus-not-obscured-minimum).
- 2022-05-30: Added [Focus Not Obscured (Enhanced)](#focus-not-obscured-enhanced).
- 2023-01-25: 4.1.1 Parsing marked as obsolete and removed.
- 2023-06-05: Added privacy and security sections within conformance.
- 2024-12-12: Republished WCAG 2.2, incorporating the following errata:
  - modified the definitions of single pointer, used in an unusual or restricted way, motion animation, and programmatically determined
  - modified the formatting of definitions for changes of context, general flash and red flash thresholds, cognitive function test, and structure
  - removed the defunct “encloses” definition
  - corrected typo in [input purposes](#input-purposes) list
  - modified the formatting of Target Size (Minimum) and Accessible Authentication (Minimum)
  - modified the visual presentation for content identified as New
  - modified the language covering devices in the [Abstract](#abstract)
  - made editorial changes to improve consistent use of definitions in the success criteria
  - made editorial changes to improve consistent use of the terms “success criteria/criterion”, “web”, “website”, and “web page”

## B. Acknowledgments

Additional information about participation in the Accessibility Guidelines Working Group (AG WG) can be found on the [Working Group home page](https://www.w3.org/WAI/GL/).

## B.1 Participants of the AG WG active in the development of this document:

- Jake Abma (Invited Expert)
- Shadi Abou-Zahra (Amazon)
- Chuck Adams (Oracle Corporation)
- Amani Ali (Nomensa)
- Jim Allan (Invited Expert)
- Jon Avila (Level Access)
- Bruce Bailey (U.S. Access Board)
- Renaldo Bernard (University of Southampton)
- Dan Bjorge (Deque Systems, Inc.)
- Peter Bossley (Thomson Reuters)
- Rachael Bradley Montgomery (Library of Congress)
- Judy Brewer (W3C)
- Shari Butler (Pearson plc)
- Thaddeus Cambron (Invited Expert)
- Alastair Campbell (Nomensa)
- Laura Carlson (Invited Expert)
- Sukriti Chadha (Invited Expert)
- Rafal Charlampowicz (AccessibilityOZ)
- Michael Cooper (W3C)
- Jennifer Delisi (Invited Expert)
- Wayne Dick (Knowbility, Inc)
- Kim Dirks (Thomson Reuters)
- E.A. Draffan (University of Southampton)
- Eric Eggert (W3C)
- Michael Elledge (Invited Expert)
- Steve Faulkner (TPGi)
- David Fazio (Invited Expert)
- Wilco Fiers (Deque Systems, Inc.)
- Detlev Fischer (Invited Expert)
- John Foliot (Invited Expert)
- Matt Garrish (DAISY Consortium)
- Alistair Garrison (Level Access)
- Jaunita George (Navy Federal Credit Union)
- Michael Gower (IBM Corporation)
- Markku Hakkinen (Educational Testing Service)
- Charles Hall (Invited Expert)
- Katie Haritos-Shea (Knowbility, Inc)
- Dan Harper-Wain (HM Government)
- Shawn Henry (W3C)
- Sarah Horton (Invited Expert)
- Abi James (University of Southampton)
- Marc Johlic (IBM Corporation)
- Oliver Keim (SAP SE)
- Andrew Kirkpatrick (Adobe)
- John Kirkwood (Invited Expert)
- JaEun Jemma Ku (University of Illinois Chicago)
- Patrick H. Lauke (TetraLogical)
- Shawn Lauriat (Google, Inc.)
- Steve Lee (Invited Expert)
- Chris Loiselle (Invited Expert)
- David MacDonald (Invited Expert)
- Jan McSorley (Pearson plc)
- Rain Breaw Michaels (Google LLC)
- Neil Milliken (Unify Software and Solutions)
- Mary Jo Mueller (IBM Corporation)
- Jay Mullen (College Board)
- Brooks Newton (Thomson Reuters)
- Gundula Niemann (SAP SE)
- James Nurthen (Oracle Corporation)
- Lori Oakley (Oracle Corporation)
- Joshue O Connor (Invited Expert)
- Scott O'Hara (Microsoft)
- Sailesh Panchang (Deque Systems, Inc.)
- Kim Patch (Invited Expert)
- Melanie Philipp (Deque Systems, Inc.)
- Mike Pluke (Invited Expert)
- Ian Pouncey (TetraLogical)
- Ruoxi Ran (W3C)
- Stephen Repsher (Invited Expert)
- John Rochford (Invited Expert)
- Stefan Schnabel (SAP SE)
- Ayelet Seeman (Invited Expert)
- Lisa Seeman-Kestenbaum (Invited Expert)
- Glenda Sims (Deque Systems, Inc.)
- Avneesh Singh (DAISY Consortium)
- David Sloan (TPGi)
- Andrew Somers (Invited Expert)
- Jeanne Spellman (TetraLogical)
- Francis Storr (Intel)
- Poornima Badhan Subramanian (Invited Expert)
- Ben Tillyer (Invited Expert)
- Makoto Ueki (Invited Expert)
- Gregg Vanderheiden (Raising the Floor)
- Kathleen Wahlbin (Invited Expert)
- Léonie Watson (TetraLogical)
- Jason White (Educational Testing Service)
- White, Kevin (W3C Staff)
- Mark Wilcock (Unify Software and Solutions)
- Todd Libby (Invited Expert)

## B.2 Other previously active WCAG WG participants and other contributors to WCAG 2.0, WCAG 2.1, or supporting resources

Paul Adam, Jenae Andershonis, Wilhelm Joys Andersen, Andrew Arch, Avi Arditti, Aries Arditi, Tom Babinszki, Mark Barratt, Mike Barta, Sandy Bartell, Kynn Bartlett, Chris Beer, Charles Belov, Marco Bertoni, Harvey Bingham, Chris Blouch, Paul Bohman, Frederick Boland, Denis Boudreau, Patrice Bourlon, Andy Brown, Dick Brown, Doyle Burnett, Raven Calais, Ben Caldwell, Tomas Caspers, Roberto Castaldo, Sofia Celic-Li, Sambhavi Chandrashekar, Mike Cherim, Jonathan Chetwynd, Wendy Chisholm, Alan Chuter, David M Clark, Joe Clark, Darcy Clarke, James Coltham, Earl Cousins, James Craig, Tom Croucher, Pierce Crowell, Nir Dagan, Daniel Dardailler, Geoff Deering, Sébastien Delorme, Pete DeVasto, Iyad Abu Doush, Sylvie Duchateau, Cherie Eckholm, Roberto Ellero, Don Evans, Gavin Evans, Neal Ewers, Steve Faulkner, Bengt Farre, Lainey Feingold, Wilco Fiers, Michel Fitos, Alan J. Flavell, Nikolaos Floratos, Kentarou Fukuda, Miguel Garcia, P.J. Gardner, Alistair Garrison, Greg Gay, Becky Gibson, Al Gilman, Kerstin Goldsmith, Michael Grade, Karl Groves, Loretta Guarino Reid, Jon Gunderson, Emmanuelle Gutiérrez y Restrepo, Brian Hardy, Eric Hansen, Benjamin Hawkes-Lewis, Sean Hayes, Shawn Henry, Hans Hillen, Donovan Hipke, Bjoern Hoehrmann, Allen Hoffman, Chris Hofstader, Yvette Hoitink, Martijn Houtepen, Carlos Iglesias, Richard Ishida, Jonas Jacek, Ian Jacobs, Phill Jenkins, Barry Johnson, Duff Johnson, Jyotsna Kaki, Shilpi Kapoor, Leonard R. Kasday, Kazuhito Kidachi, Ken Kipness, Johannes Koch, Marja-Riitta Koivunen, Maureen Kraft, Preety Kumar, Kristjan Kure, Andrew LaHart, Gez Lemon, Chuck Letourneau, Aurélien Levy, Harry Loots, Scott Luebking, Tim Lacy, Jim Ley, Alex Li, William Loughborough, N Maffeo, Mark Magennis, Erich Manser, Kapsi Maria, Luca Mascaro, Matt May, Sheena McCullagh, Liam McGee, Jens Oliver Meiert, Niqui Merret, Jonathan Metz, Alessandro Miele, Steven Miller, Mathew J Mirabella, Matt May, Marti McCuller, Sorcha Moore, Charles F. Munat, Robert Neff, Charles Nevile, Liddy Nevile, Dylan Nicholson, Bruno von Niman, Tim Noonan, Sebastiano Nutarelli, Graham Oliver, Sean B. Palmer, Charu Pandhi, evarshi Pant, Nigel Peck, Anne Pemberton, David Poehlman, Ian Pouncey, Charles Pritchard, Kerstin Probiesch, W Reagan, Adam Victor Reed, Chris Reeve, Chris Ridpath, Lee Roberts, Mark Rogers, Raph de Rooij, Gregory J. Rosmaita, Matthew Ross, Sharron Rush, Joel Sanda, Janina Sajka, Roberto Scano, Gordon Schantz, Tim van Schie, Wolf Schmidt, Stefan Schnabel, Cynthia Shelly, Glenda Sims, John Slatin, Becky Smith, Jared Smith, Andi Snow-Weaver, Neil Soiffer, Mike Squillace, Michael Stenitzer, Diane Stottlemyer, Christophe Strobbe, Sarah J Swierenga, Jim Thatcher, Terry Thompson, Justin Thorp, David Todd, Mary Utt, Jean Vanderdonckt, Carlos A Velasco, Eric Velleman, Gijs Veyfeyken, Dena Wainwright, Paul Walsch, Daman Wandke, Richard Warren, Elle Waters, Takayuki Watanabe, Gian Wild, David Wooley, Wu Wei, Kenny Zhang, Leona Zumbo.

## B.3 Enabling funders

This publication has been funded in part with U.S. Federal funds from the Health and Human Services, National Institute on Disability, Independent Living, and Rehabilitation Research (NIDILRR), initially under contract number ED-OSE-10-C-0067, then under contract number HHSP23301500054C, and now under HHS75P00120P00168. The content of this publication does not necessarily reflect the views or policies of the U.S. Department of Health and Human Services or the U.S. Department of Education, nor does mention of trade names, commercial products, or organizations imply endorsement by the U.S. Government.
